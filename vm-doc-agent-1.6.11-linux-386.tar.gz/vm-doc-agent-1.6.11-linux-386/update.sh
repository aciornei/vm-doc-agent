#!/bin/sh
set -eu

NAME=vm-doc-agent
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -r "$SCRIPT_DIR/config.json" ] || [ -d "$SCRIPT_DIR/bin" ]; then BASE_DIR="$SCRIPT_DIR"; else BASE_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd); fi
SYSTEMD_SOURCE="$BASE_DIR/packaging/systemd/vm-doc-agent.service"
SYSV_SOURCE="$BASE_DIR/packaging/sysv/vm-doc-agent"
LOGROTATE_SOURCE="$BASE_DIR/packaging/logrotate/vm-doc-agent"
CONFIG=/etc/$NAME/config.json
CONFIG_BACKUP=${CONFIG}.previous

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./update.sh"; exit 1; }

detect_arch() {
    MACHINE=$(uname -m 2>/dev/null || echo unknown)
    case "$MACHINE" in
        x86_64|amd64) echo amd64 ;;
        i?86|x86) echo 386 ;;
        *) echo unsupported ;;
    esac
}
HOST_ARCH=$(detect_arch)
[ "$HOST_ARCH" != unsupported ] || { echo "Unsupported CPU architecture: $(uname -m 2>/dev/null || echo unknown). Supported: amd64, 386." >&2; exit 1; }

if [ -x "$BASE_DIR/bin/$HOST_ARCH/vm-doc-agent" ]; then
    BINARY="$BASE_DIR/bin/$HOST_ARCH/vm-doc-agent"
    UPDATER="$BASE_DIR/bin/$HOST_ARCH/vm-doc-updater"
elif [ -x "$BASE_DIR/vm-doc-agent" ]; then
    BINARY="$BASE_DIR/vm-doc-agent"
    UPDATER="$BASE_DIR/vm-doc-updater"
    if [ -r "$BASE_DIR/ARCHITECTURE" ]; then
        PACKAGE_ARCH=$(sed -n '1p' "$BASE_DIR/ARCHITECTURE" | tr -d '[:space:]')
        [ "$PACKAGE_ARCH" = "$HOST_ARCH" ] || {
            echo "Wrong package architecture: package=$PACKAGE_ARCH host=$HOST_ARCH ($(uname -m))." >&2
            echo "Use vm-doc-agent-*-linux-$HOST_ARCH.tar.gz or the multiarch package." >&2
            exit 1
        }
    fi
else
    echo "Missing agent binary for host architecture $HOST_ARCH under $BASE_DIR." >&2
    exit 1
fi
[ -x "$UPDATER" ] || { echo "Missing updater executable: $UPDATER"; exit 1; }
[ -x /usr/local/sbin/$NAME ] || { echo "$NAME is not installed; use install.sh"; exit 1; }
[ -r "$CONFIG" ] || { echo "Missing configuration: $CONFIG"; exit 1; }

# Preflight before stopping the running service or replacing files.
if ! "$BINARY" -version >/dev/null 2>&1; then
    echo "The packaged vm-doc-agent cannot execute on this host ($HOST_ARCH / $(uname -m))." >&2
    command -v file >/dev/null 2>&1 && file "$BINARY" >&2 || true
    exit 1
fi
if ! "$UPDATER" -version >/dev/null 2>&1; then
    echo "The packaged vm-doc-updater cannot execute on this host ($HOST_ARCH / $(uname -m))." >&2
    command -v file >/dev/null 2>&1 && file "$UPDATER" >&2 || true
    exit 1
fi

stop_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then systemctl stop $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then /etc/init.d/$NAME stop; fi
}
start_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then systemctl start $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then /etc/init.d/$NAME start; fi
}
restore_previous() {
    if [ -r /usr/local/sbin/${NAME}.previous ]; then
        cp /usr/local/sbin/${NAME}.previous /usr/local/sbin/$NAME
        chmod 0755 /usr/local/sbin/$NAME
    fi
    if [ -r "$CONFIG_BACKUP" ]; then
        cp "$CONFIG_BACKUP" "$CONFIG"
        chmod --reference="$CONFIG_BACKUP" "$CONFIG" 2>/dev/null || chmod 0640 "$CONFIG"
    fi
}

stop_service
cp /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous
cp "$CONFIG" "$CONFIG_BACKUP"
chmod --reference="$CONFIG" "$CONFIG_BACKUP" 2>/dev/null || chmod 0640 "$CONFIG_BACKUP"
cp "$BINARY" /usr/local/sbin/$NAME
chmod 0755 /usr/local/sbin/$NAME
cp "$UPDATER" /usr/local/sbin/vm-doc-updater
chmod 0755 /usr/local/sbin/vm-doc-updater

if ! /usr/local/sbin/$NAME -config "$CONFIG" -migrate-config; then
    echo "Configuration migration failed; restoring previous agent and configuration." >&2
    restore_previous
    start_service || true
    exit 1
fi
if ! /usr/local/sbin/$NAME -config "$CONFIG" -check-config >/dev/null; then
    echo "Migrated configuration is invalid; restoring previous agent and configuration." >&2
    restore_previous
    start_service || true
    exit 1
fi

if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    cp "$SYSTEMD_SOURCE" /etc/systemd/system/$NAME.service
    chmod 0644 /etc/systemd/system/$NAME.service
    systemctl daemon-reload
elif [ -x /etc/init.d/$NAME ]; then
    cp "$SYSV_SOURCE" /etc/init.d/$NAME
    chmod 0755 /etc/init.d/$NAME
fi
if [ -d /etc/logrotate.d ] && [ -r "$LOGROTATE_SOURCE" ]; then cp "$LOGROTATE_SOURCE" /etc/logrotate.d/$NAME; chmod 0644 /etc/logrotate.d/$NAME; fi

if ! start_service; then
    echo "Update failed; restoring previous binary and configuration."
    restore_previous
    start_service || true
    exit 1
fi
sleep 1
[ -r /etc/$NAME/central-registration-token ] && chmod 0600 /etc/$NAME/central-registration-token || true
/usr/local/sbin/$NAME -version
/usr/local/sbin/$NAME -config "$CONFIG" -check-config >/dev/null
echo "Updated $NAME ($HOST_ARCH); existing configuration values were preserved and new schema keys were added automatically."
