#!/bin/sh
set -u
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
echo "Host: $(uname -a 2>/dev/null || true)"
echo "Machine: $(uname -m 2>/dev/null || true)"
if command -v file >/dev/null 2>&1; then
  file "$DIR/vm-doc-agent"
fi
echo "Agent runtime test:"
"$DIR/vm-doc-agent" -version
RC=$?
if [ "$RC" -ne 0 ]; then
  echo "FAILED: vm-doc-agent did not execute (rc=$RC)" >&2
  exit "$RC"
fi
echo "OK: binary starts on this kernel."
echo "Next optional test: ./vm-doc-agent -config ./config.json -print-inventory"
