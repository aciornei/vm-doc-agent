VM-DOC AGENT LEGACY - SLES 9 SP4 / kernel 2.6.5 / x86_64
=========================================================

1. Test the binary before installation:

   ./vm-doc-agent -version

Expected:
   vm-doc-agent 1.0.0-legacy-sles9 schema=2.9 ...

2. Optional inventory test (does not start the service):

   cp config.json /tmp/vm-doc-agent-config.json
   # Ensure central token settings are valid, or temporarily disable central in the test config.
   ./vm-doc-agent -config /tmp/vm-doc-agent-config.json -print-inventory >/tmp/inventory.json

3. Install as root:

   ./install.sh

For central registration, either place the registration token in:
   /etc/vm-doc-agent/central-registration-token

or run install with:
   VM_DOC_CENTRAL_REGISTRATION_TOKEN='TOKEN' ./install.sh

Service on SLES 9:
   /etc/init.d/vm-doc-agent status
   /etc/init.d/vm-doc-agent restart

Log:
   /var/log/vm-doc-agent.log

Health:
   curl http://127.0.0.1:9078/health

IMPORTANT: auto-update is disabled in this legacy build. Upgrade it only with another SLES9-compatible legacy package.
