# vm-doc-agent 1.6.7

## Versiunea 1.6.7

Versiunea 1.6.7 clasifică serviciile observate ca `system`, `application` sau `unknown`. Clasificarea este conservatoare: produsele/middleware cunoscute și unitățile systemd locale sunt marcate ca aplicație, serviciile și pachetele OS cunoscute ca sistem, iar cazurile incerte rămân `unknown`. Inventarul brut păstrează toate serviciile; filtrarea este responsabilitatea serverului 0.19.12+.

## Versiunea 1.6.6

Versiunea 1.6.6 adaugă discovery MySQL/MariaDB fără parolă printr-un user OS dedicat. Dacă există `vm-doc-inventory`, agentul (care poate rula în continuare ca root) execută clientul `mysql`/`mariadb` prin `runuser -u vm-doc-inventory`, forțează protocolul socket și folosește userul DB cu același nume. Dacă userul dedicat nu există, comportamentul legacy rămâne disponibil pentru compatibilitate.

Configurația recomandată pe MariaDB este un user DB `vm-doc-inventory@localhost` autentificat prin `unix_socket` și cu privilegiul global minim `SHOW DATABASES`. Agentul nu stochează și nu transmite parole.

## Versiunea 1.6.5

Versiunea 1.6.5 adaugă un motiv structurat și secret-safe atunci când enumerarea locală a bazelor nu poate fi realizată. Pentru PostgreSQL, MySQL/MariaDB și MongoDB, `catalog_discovery_reason` poate indica `authentication_required`, `permission_denied`, `socket_unavailable`, `server_unavailable`, `client_not_found`, `timeout`, `os_user_unavailable`, `query_failed` sau `unsupported_engine`. Agentul nu transmite stderr brut, parole sau connection strings.

## Versiunea 1.6.4

Versiunea 1.6.4 îmbunătățește inventarul Web pentru Apache HTTP Server. Agentul pornește din configurația principală detectată din proces sau din `httpd/apache2 -V` și urmărește recursiv directivele `Include` și `IncludeOptional`. Astfel sunt găsite automat VirtualHost-urile din directoare precum `/etc/httpd/vhosts.d`, `/etc/httpd/conf.d`, `/etc/apache2/sites-enabled` sau orice altă cale inclusă din configurația Apache.

## Versiunea 1.6.3


Versiunea 1.6.3 adaugă colectorul `hosts`, care parsează `/etc/hosts` și raportează numai mapările utile `IP -> nume/aliasuri`. Este destinat în special serverelor Prometheus, astfel încât vm-doc-server să poată corela targeturile definite prin aliasuri locale cu VM-urile reale după IP. Sunt ignorate adresele loopback, comentariile, liniile invalide și duplicatele.

Exemplu: dacă `hostname` este `kestra`, iar DNS are `kestra.xxx.ro CNAME nginx.xxx.ro`, inventarul va conține `hostname=kestra`, `fqdn=kestra.xxx.ro` și `canonical_dns_name=nginx.xxx.ro`.

## Versiunea 1.6.1

Versiunea 1.6.1 îmbunătățește collectorul Web pentru instalări Nginx non-standard. Agentul pornește de la executabilul procesului, citește `-p` / `-c`, folosește `nginx -V` pentru `--prefix` și `--conf-path` și urmărește recursiv directivele `include`, inclusiv atunci când Nginx este instalat sub `/opt`.

## Versiunea 1.6.0

Versiunea 1.6.0 adaugă inventarul host-level pentru Nginx, Apache HTTP Server și HAProxy. Agentul detectează serverele instalate/rulate și extrage metadate sigure despre site-uri, virtual hosts și frontends: nume publice, bind-uri/porturi, document root, backend-uri și ținte proxy, fără a trimite conținutul brut al configurațiilor, credențiale, chei private sau valori de headere. Tot în 1.6.0 este corectată starea PostgreSQL: un proces `postgres` care rulează nu mai poate fi marcat `inactive` doar pentru că unitatea generică `postgresql.service` este inactivă; este preferată unitatea activă a clusterului, de exemplu `postgresql@16-main.service`.

## Versiunea 1.5.0

Versiunea 1.5.0 adaugă collectorul `databases` pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle Database, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB. Sunt colectate numai metadate de inventar (engine, versiune, instanță, endpoint, directoare/config cunoscute și, best-effort, numele bazelor logice). Nu sunt colectate parole, connection strings, query-uri sau date din baze. Pe hosturile DB partajate, serverul poate asocia separat fiecare instanță sau bază logică unui alt serviciu intern.

## Versiunea 1.4.1

Versiunea 1.4.1 repară actualizarea configurației la upgrade. Valorile existente din `/etc/vm-doc-agent/config.json` sunt păstrate, iar cheile introduse de versiunea nouă sunt adăugate automat. Auto-updaterul păstrează și `/etc/vm-doc-agent/config.json.previous` și face rollback atât la binar, cât și la configurație dacă migrarea sau health-check-ul eșuează.

Comanda poate fi rulată și manual:

```bash
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -migrate-config
```

## Versiunea 1.4.0

Versiunea 1.4.0 adaugă inventarierea Docker structurată: engine, containere, Docker Compose, imagini, rețele și volume. Colectorul nu salvează valorile variabilelor de mediu, secrete, loguri sau conținutul fișierelor montate. Pentru asociere automată cu servicii, serverul poate folosi labels `vm-doc.service`, `vm-doc.services`, `vm-doc.component` și `vm-doc.role`.


Agentul și updaterul scriu acum propriul log persistent în `/var/log/vm-doc-agent.log`, independent de systemd/journald sau syslog. Pe sistemele cu systemd logarea rămâne și în journal. Pe instalările SysV existente este detectată redirecționarea către același fișier pentru a evita dublarea liniilor. Configurația logrotate existentă continuă să fie folosită.

## Ce aduce versiunea 1.3.4

- repară auto-update-ul pe CentOS 7 / systemd 219;
- detectează capabilitățile reale ale `systemd-run` înainte de a folosi `--collect` și `--no-block`;
- nu mai forțează `Type=exec`, incompatibil cu unele versiuni systemd vechi;
- păstrează helperul de update într-o unitate systemd separată și păstrează mecanismul existent de backup/rollback.

## Ce aduce versiunea 1.3.3

- detecție robustă de versiune pentru serviciile cunoscute, inclusiv Postfix și Dovecot;
- fallback la versiunea pachetului;
- auto-update 1.3.0+ păstrat neschimbat.

## Ce aduce versiunea 1.3.1

- serviciile colectate pot raporta acum numele software, versiunea produsului și versiunea pachetului atunci când acestea pot fi determinate sigur;
- Linux detectează explicit versiuni pentru Postfix, Dovecot, Nginx, Apache, Redis, MariaDB/MySQL, PostgreSQL, HAProxy, Prometheus, Node Exporter, Filebeat, Auditbeat, SSSD, rsyslog, chrony, Docker, containerd, RabbitMQ, SOGo și PHP-FPM;
- Windows încearcă să citească ProductName/ProductVersion/FileVersion din executabilul serviciilor active;
- schema rămâne backward-compatible: câmpurile de versiune sunt opționale.


Agent Linux universal pentru colectarea inventarului local necesar fișei VM.
Versiunea 1.3.0 adaugă auto-update controlat de `vm-doc-server`, păstrând
colectarea inventarului o dată la 24 de ore și heartbeat-ul la 5 minute.

## Ce aduce 1.3.0

- auto-update controlat de serverul central, fără acces direct la GitHub;
- canale `stable` și `testing`;
- verificare SHA-256 și dimensiune înainte de instalare;
- verificarea versiunii executabilului descărcat înainte de înlocuire;
- helper separat `vm-doc-updater`, cu backup și rollback automat dacă noul agent nu trece `/health`;
- verificare periodică implicită la `6h`, cu instalare automată activată;
- API local nou: `GET /v1/update` și `POST /v1/update/check`;
- download-urile de update sunt acceptate numai de la aceeași origine ca `central.url`;
- `refresh_interval` rămâne `24h`, heartbeat `5m`;
- schema inventarului rămâne `2.0`.

## Funcții principale

- identitate persistentă `agent.id` și corelare prin UUID VMware/DMI;
- inventar JSON local și API HTTP protejat cu token Bearer;
- autoînregistrare outbound la serverul central;
- heartbeat periodic pentru starea online/offline;
- push automat al inventarului după fiecare colectare reușită;
- auto-update cu helper separat, validare SHA-256 și rollback;
- retry automat dacă serverul central nu este disponibil;
- compatibilitate cu systemd și SysV Init;
- binar static universal `linux/amd64`, `GOAMD64=v1`.

## Instalare nouă

```bash
tar -xzf vm-doc-agent-1.6.7-linux-amd64.tar.gz
cd vm-doc-agent-1.6.7-linux-amd64
sudo ./install.sh
```

Pachetul intern poate conține fișierul `central-registration-token`, iar
installerul îl copiază automat în:

```text
/etc/vm-doc-agent/central-registration-token
```

cu permisiuni `0600`.

Dacă pachetul nu conține tokenul, acesta poate fi furnizat la instalare:

```bash
sudo VM_DOC_CENTRAL_REGISTRATION_TOKEN='TOKEN' ./install.sh
```

## Configurare centrală implicită

```json
"central": {
  "enabled": true,
  "url": "http://172.20.1.20:9080",
  "registration_token_file": "/etc/vm-doc-agent/central-registration-token",
  "heartbeat_interval": "5m",
  "retry_interval": "1m",
  "request_timeout": "60s",
  "advertise_url": "",
  "ca_file": "",
  "tls_server_name": "",
  "insecure_skip_verify": false,
  "allow_http": true
}
```

`advertise_url` poate rămâne gol. Agentul folosește IP-ul interfeței cu ruta
implicită și portul din `listen`.

## Update manual

```bash
tar -xzf vm-doc-agent-1.6.7-linux-amd64.tar.gz
cd vm-doc-agent-1.6.7-linux-amd64
sudo ./update.sh
```

Updaterul păstrează configurația existentă, tokenul API local, `agent-id` și
inventarele existente. Pentru un agent 1.1.0 deja instalat, dacă `central` era
dezactivat, configurația existentă trebuie activată explicit; `update.sh` nu
suprascrie `config.json`.


## Auto-update

Configurația implicită este:

```json
"updates": {
  "enabled": true,
  "channel": "stable",
  "check_interval": "6h",
  "auto_install": true,
  "endpoint": "/api/v1/agent-updates/latest",
  "download_dir": "",
  "health_timeout": "45s",
  "max_download_bytes": 67108864
}
```

Un agent mai vechi de 1.3.0 trebuie actualizat manual **o singură dată** la 1.3.0.
După aceea, versiunile publicate de server pe canalul agentului pot fi instalate automat.

Verificare manuală:

```bash
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update/check
```

## Verificare

```bash
/usr/local/sbin/vm-doc-agent -version
/usr/local/sbin/vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
sudo systemctl restart vm-doc-agent
sudo journalctl -u vm-doc-agent -n 100 --no-pager
```

În log trebuie să apară evenimentele:

```text
event=central_registered
event=central_inventory_pushed
```

## API local

```bash
curl http://127.0.0.1:9078/health
TOKEN=$(sudo cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/status
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/inventory
```

## Build

```bash
./scripts/build.sh
CENTRAL_REGISTRATION_TOKEN='TOKEN' ./scripts/package.sh
./scripts/package-source.sh
```

**Important:** un pachet binar creat cu `CENTRAL_REGISTRATION_TOKEN` conține
secretul comun de bootstrap. Nu trebuie publicat într-un repository public.

Documentația detaliată se află în `docs/`.
