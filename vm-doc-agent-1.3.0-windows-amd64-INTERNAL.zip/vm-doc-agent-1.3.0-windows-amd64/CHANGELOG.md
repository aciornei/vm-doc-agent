# Changelog

## 1.3.0

- auto-update controlat de `vm-doc-server`, cu canale `stable` și `testing`;
- helper separat `vm-doc-updater.exe`, rulat ca SYSTEM într-un Scheduled Task tranzitoriu;
- verificare SHA-256, dimensiune și versiune înainte de instalare;
- backup și rollback automat dacă noul agent nu trece `/health`;
- endpoint-uri locale `GET /v1/update` și `POST /v1/update/check`;
- verificare update implicită la `6h`, `auto_install=true`;
- inventar `24h` și heartbeat `5m` păstrate.

## 1.2.0

- first Windows amd64 build;
- Windows Server / Windows 10/11 inventory collectors using built-in CIM/PowerShell cmdlets;
- same schema 2.0 and central registration/push protocol as Linux;
- central enabled by default for `http://172.20.1.20:9080`, HTTP explicitly allowed;
- default inventory refresh changed to 24 hours, heartbeat remains 5 minutes;
- installer runs the agent as SYSTEM at startup and restricts the local API firewall rule to central server `172.20.1.20`;
- internal package can embed the common central registration token; public package omits it.
