[CmdletBinding()]
param([switch]$PurgeData)
$ErrorActionPreference = "Stop"
$TaskName = "vm-doc-agent"
$FirewallName = "vm-doc-agent API"
$InstallDir = Join-Path $env:ProgramFiles "vm-doc-agent"
$DataDir = Join-Path $env:ProgramData "vm-doc-agent"

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run PowerShell as Administrator." }

Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
Get-NetFirewallRule -DisplayName $FirewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
Remove-Item $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
if ($PurgeData) { Remove-Item $DataDir -Recurse -Force -ErrorAction SilentlyContinue }
Write-Host "vm-doc-agent removed. Data preserved: $(-not $PurgeData)"
