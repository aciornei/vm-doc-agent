$DataDir = Join-Path $env:ProgramData "vm-doc-agent"
$Token = (Get-Content (Join-Path $DataDir "token") -Raw).Trim()
$Headers = @{ Authorization = "Bearer $Token" }
Invoke-RestMethod -Method Post -Uri "http://127.0.0.1:9078/v1/inventory/refresh" -Headers $Headers -TimeoutSec 120
