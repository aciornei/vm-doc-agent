$TaskName = "vm-doc-agent"
$DataDir = Join-Path $env:ProgramData "vm-doc-agent"
Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue | Get-ScheduledTaskInfo | Format-List *
try { Invoke-RestMethod -Uri "http://127.0.0.1:9078/health" -TimeoutSec 5 | ConvertTo-Json -Depth 5 } catch { Write-Warning $_ }
if (Test-Path "$DataDir\vm-doc-agent.log") { Get-Content "$DataDir\vm-doc-agent.log" -Tail 30 }
