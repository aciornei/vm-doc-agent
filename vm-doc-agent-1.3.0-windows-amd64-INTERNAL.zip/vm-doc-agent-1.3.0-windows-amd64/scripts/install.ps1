[CmdletBinding()]
param(
    [string]$RegistrationToken = "",
    [switch]$NoFirewall
)

$ErrorActionPreference = "Stop"
$TaskName = "vm-doc-agent"
$FirewallName = "vm-doc-agent API"
$InstallDir = Join-Path $env:ProgramFiles "vm-doc-agent"
$DataDir = Join-Path $env:ProgramData "vm-doc-agent"
$ExePath = Join-Path $InstallDir "vm-doc-agent.exe"
$UpdaterPath = Join-Path $InstallDir "vm-doc-updater.exe"
$ConfigPath = Join-Path $DataDir "config.json"
$CentralTokenPath = Join-Path $DataDir "central-registration-token"
$PackageRoot = Split-Path -Parent $PSScriptRoot

function Require-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw "Run PowerShell as Administrator."
    }
}

Require-Administrator
if ($PSVersionTable.PSVersion.Major -lt 5) { throw "Windows PowerShell 5.x or newer is required." }
foreach ($cmd in @("Get-CimInstance", "Get-NetIPConfiguration", "Get-NetRoute", "Get-NetFirewallProfile", "Get-ScheduledTask")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "Required Windows cmdlet is missing: $cmd" }
}

Write-Host "Installing vm-doc-agent 1.3.0 for Windows..."
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null

$existing = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existing) {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

Copy-Item (Join-Path $PackageRoot "vm-doc-agent.exe") $ExePath -Force
Copy-Item (Join-Path $PackageRoot "vm-doc-updater.exe") $UpdaterPath -Force
if (-not (Test-Path $ConfigPath)) {
    Copy-Item (Join-Path $PackageRoot "config.json") $ConfigPath -Force
} else {
    Write-Host "Existing config.json preserved: $ConfigPath"
}

if ($RegistrationToken.Trim()) {
    [IO.File]::WriteAllText($CentralTokenPath, $RegistrationToken.Trim(), [Text.UTF8Encoding]::new($false))
} elseif (Test-Path (Join-Path $PackageRoot "central-registration-token")) {
    Copy-Item (Join-Path $PackageRoot "central-registration-token") $CentralTokenPath -Force
} elseif (-not (Test-Path $CentralTokenPath)) {
    throw "No central registration token. Use -RegistrationToken or use the INTERNAL package."
}

# Keep agent state, API token, inventory and bootstrap token readable only by SYSTEM/local Administrators.
& icacls.exe $DataDir /inheritance:r /grant:r "SYSTEM:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
& icacls.exe $CentralTokenPath /inheritance:r /grant:r "SYSTEM:F" "*S-1-5-32-544:F" | Out-Null

$Runner = Join-Path $InstallDir "run-agent.cmd"
@"
@echo off
:restart
"$ExePath" -config "$ConfigPath" >> "$DataDir\vm-doc-agent.log" 2>&1
if errorlevel 1 (
  timeout /t 10 /nobreak >nul
  goto restart
)
"@ | Set-Content -Path $Runner -Encoding ASCII

$action = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument "/d /c `"`"$Runner`"`""
$trigger = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -StartWhenAvailable -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description "vm-doc-agent 1.3.0 - Windows VM inventory agent" | Out-Null

if (-not $NoFirewall) {
    Get-NetFirewallRule -DisplayName $FirewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName $FirewallName -Direction Inbound -Action Allow -Protocol TCP -LocalPort 9078 -RemoteAddress "172.20.1.20" -Profile Any | Out-Null
}

Start-ScheduledTask -TaskName $TaskName
Start-Sleep -Seconds 4

Write-Host ""
Write-Host "Installed."
Write-Host "Executable : $ExePath"
Write-Host "Config     : $ConfigPath"
Write-Host "Inventory  : $DataDir\inventory.json"
Write-Host "Log        : $DataDir\vm-doc-agent.log"
Write-Host "Task       : $TaskName (SYSTEM, at startup)"
try {
    $health = Invoke-RestMethod -Uri "http://127.0.0.1:9078/health" -TimeoutSec 5
    Write-Host ("Health     : " + ($health | ConvertTo-Json -Compress))
} catch {
    Write-Warning "Agent did not answer /health yet. Check $DataDir\vm-doc-agent.log"
}
