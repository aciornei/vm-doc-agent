[CmdletBinding()]
param()
$ErrorActionPreference = "Stop"
$TaskName = "vm-doc-agent"
$InstallDir = Join-Path $env:ProgramFiles "vm-doc-agent"
$ExePath = Join-Path $InstallDir "vm-doc-agent.exe"
$UpdaterPath = Join-Path $InstallDir "vm-doc-updater.exe"
$PackageRoot = Split-Path -Parent $PSScriptRoot

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw "Run PowerShell as Administrator." }

Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
Copy-Item (Join-Path $PackageRoot "vm-doc-agent.exe") $ExePath -Force
Copy-Item (Join-Path $PackageRoot "vm-doc-updater.exe") $UpdaterPath -Force
Start-ScheduledTask -TaskName $TaskName
Write-Host "vm-doc-agent executable updated. Existing config, agent-id and tokens were preserved."
