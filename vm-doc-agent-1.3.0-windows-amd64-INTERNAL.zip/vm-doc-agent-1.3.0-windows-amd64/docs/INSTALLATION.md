# Windows installation

Requirements: 64-bit Windows with Windows PowerShell 5.x and CIM/NetTCPIP/NetSecurity cmdlets (Windows Server 2016/2019/2022/2025 and Windows 10/11 are the intended targets).

Run `scripts\install.ps1` as Administrator. Configuration and state live in `C:\ProgramData\vm-doc-agent`; the executable lives in `C:\Program Files\vm-doc-agent`.

The installer registers an AtStartup task named `vm-doc-agent`, running under `SYSTEM`, and creates an inbound Windows Firewall rule for TCP/9078 restricted to `172.20.1.20`.
