# Operations

Status: `powershell -ExecutionPolicy Bypass -File .\scripts\status.ps1`

Manual refresh: `powershell -ExecutionPolicy Bypass -File .\scripts\collect-now.ps1`

Update executable while preserving configuration/tokens/state: `powershell -ExecutionPolicy Bypass -File .\scripts\update.ps1`

Uninstall and preserve data: `powershell -ExecutionPolicy Bypass -File .\scripts\uninstall.ps1`

Uninstall and purge data: `powershell -ExecutionPolicy Bypass -File .\scripts\uninstall.ps1 -PurgeData`
