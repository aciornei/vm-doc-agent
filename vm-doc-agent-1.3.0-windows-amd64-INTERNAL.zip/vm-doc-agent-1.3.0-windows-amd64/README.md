# vm-doc-agent 1.3.0 - Windows amd64

Build Windows al agentului, compatibil cu același protocol central și aceeași schemă de inventar `2.0` ca varianta Linux. Versiunea 1.3.0 introduce și auto-update controlat de `vm-doc-server`.

## Configurație implicită

- central: `http://172.20.1.20:9080`;
- `central.enabled=true` și `central.allow_http=true`;
- inventar complet: `24h`;
- heartbeat: `5m`;
- verificare update: `6h`;
- canal update: `stable`;
- instalare automată update: activă;
- API local: TCP `9078`;
- date/config: `C:\ProgramData\vm-doc-agent`;
- executabile: `C:\Program Files\vm-doc-agent\vm-doc-agent.exe` și `vm-doc-updater.exe`.

## Instalare

Deschide PowerShell **ca Administrator**:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\install.ps1
```

Pachetul INTERNAL conține tokenul comun de înregistrare. Pachetul public nu îl conține și se instalează astfel:

```powershell
.\scripts\install.ps1 -RegistrationToken '<token>'
```

Agentul rulează ca `SYSTEM` într-un Scheduled Task `vm-doc-agent`, pornit la startup. Windows Firewall permite implicit accesul inbound la 9078 numai de la `172.20.1.20`.

## Auto-update 1.3.0

Agentul întreabă serverul central la fiecare `6h` dacă există o versiune mai nouă pe canalul configurat. Serverul livrează separat binarele `vm-doc-agent.exe` și `vm-doc-updater.exe`, împreună cu SHA-256 și dimensiunea lor.

Înainte de instalare agentul:

1. descarcă numai de la aceeași origine ca `central.url`;
2. verifică dimensiunea și SHA-256;
3. rulează fiecare executabil cu `-version` pentru a confirma versiunea;
4. pornește helperul `vm-doc-updater.exe` într-un Scheduled Task separat, ca `SYSTEM`;
5. închide agentul curent;
6. helperul păstrează binarul vechi, instalează versiunea nouă și pornește agentul;
7. dacă `/health` nu confirmă versiunea nouă, helperul face rollback automat.

Statusul poate fi verificat local cu tokenul API al agentului:

```powershell
$token = (Get-Content 'C:\ProgramData\vm-doc-agent\token' -Raw).Trim()
Invoke-RestMethod -Headers @{Authorization="Bearer $token"} `
  -Uri 'http://127.0.0.1:9078/v1/update'
```

Forțare verificare/instalare:

```powershell
Invoke-RestMethod -Method Post -Headers @{Authorization="Bearer $token"} `
  -Uri 'http://127.0.0.1:9078/v1/update/check'
```

Un agent anterior versiunii 1.3.0 trebuie instalat/actualizat manual o singură dată. Auto-update-ul se aplică pentru versiunile ulterioare.

## Date Windows colectate

- host/SMBIOS UUID, manufacturer, model, BIOS serial, MachineGuid;
- Windows edition/version/build, boot time, timezone;
- fixed/network logical disks;
- interfaces, addresses, gateways, DNS and routes;
- machine/environment proxy settings;
- Windows services;
- listening TCP/UDP endpoints with owning process;
- Windows Firewall profiles, default policies and enabled rules;
- local accounts and `net accounts` password policy summary;
- GLPI Agent, Filebeat, Auditbeat, windows_exporter/node_exporter și NXLog;
- Scheduled Tasks relevante mapate la schema existentă `cron`;
- Windows Time (`W32Time`) source/configuration.

`SSSD`, `SELinux` și `AppArmor` rămân false/not applicable pe Windows pentru compatibilitate cu schema 2.0.
