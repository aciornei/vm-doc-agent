#!/bin/sh
set -eu

NAME=vm-doc-agent
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -x "$SCRIPT_DIR/vm-doc-agent" ]; then BASE_DIR="$SCRIPT_DIR"; else BASE_DIR=$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd); fi
BINARY="$BASE_DIR/vm-doc-agent"
UPDATER="$BASE_DIR/vm-doc-updater"
SYSTEMD_SOURCE="$BASE_DIR/packaging/systemd/vm-doc-agent.service"
SYSV_SOURCE="$BASE_DIR/packaging/sysv/vm-doc-agent"
LOGROTATE_SOURCE="$BASE_DIR/packaging/logrotate/vm-doc-agent"
CONFIG=/etc/$NAME/config.json
CONFIG_BACKUP=${CONFIG}.previous

[ "$(id -u)" -eq 0 ] || { echo "Run as root: sudo ./update.sh"; exit 1; }
[ -x "$BINARY" ] || { echo "Missing executable: $BINARY"; exit 1; }
[ -x "$UPDATER" ] || { echo "Missing executable: $UPDATER"; exit 1; }
[ -x /usr/local/sbin/$NAME ] || { echo "$NAME is not installed; use install.sh"; exit 1; }
[ -r "$CONFIG" ] || { echo "Missing configuration: $CONFIG"; exit 1; }

stop_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then systemctl stop $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then /etc/init.d/$NAME stop; fi
}
start_service() {
    if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then systemctl start $NAME.service
    elif [ -x /etc/init.d/$NAME ]; then /etc/init.d/$NAME start; fi
}
restore_previous() {
    if [ -r /usr/local/sbin/${NAME}.previous ]; then
        cp /usr/local/sbin/${NAME}.previous /usr/local/sbin/$NAME
        chmod 0755 /usr/local/sbin/$NAME
    fi
    if [ -r "$CONFIG_BACKUP" ]; then
        cp "$CONFIG_BACKUP" "$CONFIG"
        chmod --reference="$CONFIG_BACKUP" "$CONFIG" 2>/dev/null || chmod 0640 "$CONFIG"
    fi
}

stop_service
cp /usr/local/sbin/$NAME /usr/local/sbin/${NAME}.previous
cp "$CONFIG" "$CONFIG_BACKUP"
chmod --reference="$CONFIG" "$CONFIG_BACKUP" 2>/dev/null || chmod 0640 "$CONFIG_BACKUP"
cp "$BINARY" /usr/local/sbin/$NAME
chmod 0755 /usr/local/sbin/$NAME
cp "$UPDATER" /usr/local/sbin/vm-doc-updater
chmod 0755 /usr/local/sbin/vm-doc-updater

if ! /usr/local/sbin/$NAME -config "$CONFIG" -migrate-config; then
    echo "Configuration migration failed; restoring previous agent and configuration." >&2
    restore_previous
    start_service || true
    exit 1
fi
if ! /usr/local/sbin/$NAME -config "$CONFIG" -check-config >/dev/null; then
    echo "Migrated configuration is invalid; restoring previous agent and configuration." >&2
    restore_previous
    start_service || true
    exit 1
fi

if [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1; then
    cp "$SYSTEMD_SOURCE" /etc/systemd/system/$NAME.service
    chmod 0644 /etc/systemd/system/$NAME.service
    systemctl daemon-reload
elif [ -x /etc/init.d/$NAME ]; then
    cp "$SYSV_SOURCE" /etc/init.d/$NAME
    chmod 0755 /etc/init.d/$NAME
fi
if [ -d /etc/logrotate.d ] && [ -r "$LOGROTATE_SOURCE" ]; then cp "$LOGROTATE_SOURCE" /etc/logrotate.d/$NAME; chmod 0644 /etc/logrotate.d/$NAME; fi

if ! start_service; then
    echo "Update failed; restoring previous binary and configuration."
    restore_previous
    start_service || true
    exit 1
fi
sleep 1
[ -r /etc/$NAME/central-registration-token ] && chmod 0600 /etc/$NAME/central-registration-token || true
/usr/local/sbin/$NAME -version
/usr/local/sbin/$NAME -config "$CONFIG" -check-config >/dev/null
echo "Updated $NAME; existing configuration values were preserved and new schema keys were added automatically."
