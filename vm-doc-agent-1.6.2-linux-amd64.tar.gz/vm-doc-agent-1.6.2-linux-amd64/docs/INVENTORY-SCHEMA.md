# Schema inventarului

Versiunea schemei din 1.0.0 este:

```json
"schema_version": "2.0"
```

Versiunea schemei este separată de versiunea agentului.

## Structură principală

```text
schema_version
agent
collected_at
collection
host
os
system
storage
network
proxy
services
listening_ports
firewall
accounts
sssd
integrations
policies
cron
ntp
truncations
collection_warnings
```

## Statusul colectoarelor

```json
{
  "collection": {
    "status": "partial",
    "collectors": {
      "network": {
        "status": "success",
        "duration_ms": 4
      },
      "integrations": {
        "status": "partial",
        "warning_count": 1,
        "warnings": ["filebeat: output validation failed"]
      }
    }
  }
}
```

Valori posibile:

- `success`;
- `partial`;
- `timeout`;
- `error`;
- `disabled`.

## Truncare

Dacă o limită este atinsă:

```json
{
  "truncations": {
    "firewall.rules": {
      "detected": 14832,
      "returned": 10000,
      "limit": 10000,
      "reason": "configured item limit"
    }
  }
}
```

## Corelare

Câmpurile principale pentru vCenter și GLPI sunt:

```text
host.correlation.dmi_product_uuid
host.correlation.smbios_legacy_byte_order
host.correlation.machine_id
host.correlation.agent_id
```


## Metadate de versiune pentru servicii (1.3.1+)

Elementele din `services` pot include opțional:

```json
{
  "name": "postfix.service",
  "software_name": "Postfix",
  "version": "3.8.6",
  "package_name": "postfix",
  "package_version": "3.8.6-1ubuntu0.3",
  "version_source": "postconf -h mail_version"
}
```

Câmpurile sunt opționale pentru compatibilitate cu agenții anteriori. `version` reprezintă versiunea produsului când poate fi determinată, iar `package_version` versiunea pachetului instalat.

## Web inventory · schema 2.3

Câmpul `web` conține `servers` și `sites`. `servers` descrie Nginx/Apache/HAProxy instalat sau activ, iar `sites` descrie virtual hosts, blocuri Nginx `server` și frontend/listen HAProxy. Sunt păstrate numai metadate secret-safe; configurația brută și secretele nu sunt incluse.


## Identitate host · schema 2.4

Câmpurile de identitate DNS sunt separate pentru a evita confundarea VM-ului cu ținta unui CNAME de serviciu:

```json
{
  "host": {
    "hostname": "kestra",
    "fqdn": "kestra.xxx.ro",
    "canonical_dns_name": "nginx.xxx.ro",
    "fqdn_source": "dns-search"
  }
}
```

`host.fqdn` reprezintă numele VM-ului construit din hostname și domeniul de căutare care rezolvă. `host.canonical_dns_name` păstrează separat numele canonic raportat de resolver/`hostname -f` atunci când este diferit. Valorile posibile uzuale pentru `fqdn_source` sunt `hostname`, `dns-search`, `dns-search-from-canonical`, `dns-search-single` și `hostname-f-fallback`.
