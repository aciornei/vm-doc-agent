#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
VERSION=${VERSION:-1.3.2}
OUT="$ROOT/dist/source-release"
STAGE="$OUT/vm-doc-agent-$VERSION-source"
rm -rf "$OUT"
mkdir -p "$STAGE"
(
    cd "$ROOT"
    tar --exclude='./dist' --exclude='./.git' -cf - .
) | (cd "$STAGE" && tar -xf -)
(
    cd "$OUT"
    tar -czf "vm-doc-agent-$VERSION-source.tar.gz" "vm-doc-agent-$VERSION-source"
    sha256sum "vm-doc-agent-$VERSION-source.tar.gz" > "vm-doc-agent-$VERSION-source.sha256"
)
echo "Source package: $OUT/vm-doc-agent-$VERSION-source.tar.gz"
