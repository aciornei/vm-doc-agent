#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
VERSION=${VERSION:-1.3.3}
BINARY="$ROOT/dist/vm-doc-agent"
UPDATER="$ROOT/dist/vm-doc-updater"
OUT="$ROOT/dist/release"
STAGE="$OUT/vm-doc-agent-$VERSION-linux-amd64"

[ -x "$BINARY" ] && [ -x "$UPDATER" ] || { echo "Build first: ./scripts/build.sh"; exit 1; }
rm -rf "$OUT"
mkdir -p "$STAGE/packaging/systemd" "$STAGE/packaging/sysv" "$STAGE/packaging/logrotate" "$STAGE/docs"
cp "$BINARY" "$STAGE/vm-doc-agent"
cp "$UPDATER" "$STAGE/vm-doc-updater"
cp "$ROOT/configs/config.json" "$STAGE/config.json"
if [ -n "${CENTRAL_REGISTRATION_TOKEN:-}" ]; then
    ( umask 077; printf '%s' "$CENTRAL_REGISTRATION_TOKEN" > "$STAGE/central-registration-token" )
    chmod 0600 "$STAGE/central-registration-token"
fi
cp "$ROOT/packaging/systemd/vm-doc-agent.service" "$STAGE/packaging/systemd/"
cp "$ROOT/packaging/sysv/vm-doc-agent" "$STAGE/packaging/sysv/"
cp "$ROOT/packaging/logrotate/vm-doc-agent" "$STAGE/packaging/logrotate/"
cp "$ROOT/scripts/install.sh" "$STAGE/install.sh"
cp "$ROOT/scripts/update.sh" "$STAGE/update.sh"
cp "$ROOT/scripts/uninstall.sh" "$STAGE/uninstall.sh"
cp "$ROOT/README.md" "$STAGE/README.md"
cp "$ROOT/CHANGELOG.md" "$STAGE/CHANGELOG.md"
cp "$ROOT/docs/"*.md "$STAGE/docs/"
chmod 0755 "$STAGE/vm-doc-agent" "$STAGE/vm-doc-updater" "$STAGE/install.sh" "$STAGE/update.sh" "$STAGE/uninstall.sh" "$STAGE/packaging/sysv/vm-doc-agent"
(
    cd "$OUT"
    tar -czf "vm-doc-agent-$VERSION-linux-amd64.tar.gz" "vm-doc-agent-$VERSION-linux-amd64"
    sha256sum "vm-doc-agent-$VERSION-linux-amd64.tar.gz" > "vm-doc-agent-$VERSION-linux-amd64.sha256"
)
echo "Package: $OUT/vm-doc-agent-$VERSION-linux-amd64.tar.gz"
