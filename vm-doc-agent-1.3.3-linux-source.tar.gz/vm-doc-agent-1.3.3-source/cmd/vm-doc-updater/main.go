package main

import (
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/version"
)

func main() {
	showVersion := flag.Bool("version", false, "print updater version and exit")
	pid := flag.Int("pid", 0, "agent process id to wait for")
	source := flag.String("source", "", "downloaded replacement binary")
	target := flag.String("target", "", "installed agent binary")
	backup := flag.String("backup", "", "backup path")
	configPath := flag.String("config", "", "agent config path")
	healthURL := flag.String("health-url", "http://127.0.0.1:9078/health", "agent health URL")
	healthTimeout := flag.Duration("health-timeout", 45*time.Second, "health verification timeout")
	expectedVersion := flag.String("expected-version", "", "expected agent version")
	flag.Parse()

	if *showVersion {
		fmt.Printf("vm-doc-updater %s commit=%s build_date=%s\n", version.Version, version.Commit, version.BuildDate)
		return
	}
	if *pid <= 0 || strings.TrimSpace(*source) == "" || strings.TrimSpace(*target) == "" || strings.TrimSpace(*backup) == "" {
		fatal("missing required updater arguments")
	}
	_ = configPath // reserved for future migration hooks

	if err := waitForExit(*pid, 40*time.Second); err != nil {
		fatal(err.Error())
	}
	if err := install(*source, *target, *backup); err != nil {
		fatal("install replacement: " + err.Error())
	}
	if err := startAgent(); err != nil {
		_ = rollback(*target, *backup)
		_ = startAgent()
		fatal("start updated agent: " + err.Error())
	}
	healthErr := waitHealth(*healthURL, *healthTimeout, *expectedVersion)
	if healthErr != nil && runtime.GOOS == "windows" {
		// The original Scheduled Task can remain in Running state for a few seconds
		// after the agent process exits. Retry the task once before rolling back.
		time.Sleep(3 * time.Second)
		_ = startAgent()
		healthErr = waitHealth(*healthURL, 15*time.Second, *expectedVersion)
	}
	if healthErr != nil {
		_ = stopAgent()
		if rbErr := rollback(*target, *backup); rbErr != nil {
			fatal("health failed and rollback failed: " + healthErr.Error() + "; " + rbErr.Error())
		}
		if startErr := startAgent(); startErr != nil {
			fatal("health failed; previous binary restored but restart failed: " + startErr.Error())
		}
		fatal("updated agent failed health check; rollback completed: " + healthErr.Error())
	}
	fmt.Fprintf(os.Stdout, "vm-doc-agent update completed successfully: %s\n", *expectedVersion)
}

func install(source, target, backup string) error {
	if _, err := os.Stat(target); err != nil {
		return err
	}
	_ = os.Remove(backup)
	if err := copyFile(target, backup, 0755); err != nil {
		return err
	}
	staging := target + ".new"
	_ = os.Remove(staging)
	if err := copyFile(source, staging, 0755); err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		_ = os.Remove(target)
	}
	if err := os.Rename(staging, target); err != nil {
		return err
	}
	if runtime.GOOS != "windows" {
		_ = os.Chmod(target, 0755)
	}
	return nil
}

func rollback(target, backup string) error {
	if _, err := os.Stat(backup); err != nil {
		return err
	}
	staging := target + ".rollback"
	_ = os.Remove(staging)
	if err := copyFile(backup, staging, 0755); err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		_ = os.Remove(target)
	}
	if err := os.Rename(staging, target); err != nil {
		return err
	}
	if runtime.GOOS != "windows" {
		_ = os.Chmod(target, 0755)
	}
	return nil
}

func waitForExit(pid int, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if !processExists(pid) {
			return nil
		}
		time.Sleep(250 * time.Millisecond)
	}
	return fmt.Errorf("agent process %d did not exit within %s", pid, timeout)
}

func processExists(pid int) bool {
	if runtime.GOOS == "windows" {
		out, err := exec.Command("tasklist.exe", "/FI", "PID eq "+strconv.Itoa(pid), "/FO", "CSV", "/NH").CombinedOutput()
		return err == nil && strings.Contains(string(out), strconv.Itoa(pid)) && !strings.Contains(strings.ToLower(string(out)), "no tasks")
	}
	return exec.Command("kill", "-0", strconv.Itoa(pid)).Run() == nil
}

func startAgent() error {
	if runtime.GOOS == "windows" {
		time.Sleep(2 * time.Second)
		return exec.Command("schtasks.exe", "/Run", "/TN", "vm-doc-agent").Run()
	}
	if _, err := os.Stat("/run/systemd/system"); err == nil {
		if _, err := exec.LookPath("systemctl"); err == nil {
			return exec.Command("systemctl", "start", "vm-doc-agent.service").Run()
		}
	}
	if _, err := os.Stat("/etc/init.d/vm-doc-agent"); err == nil {
		return exec.Command("/etc/init.d/vm-doc-agent", "start").Run()
	}
	return errors.New("cannot detect service manager")
}

func stopAgent() error {
	if runtime.GOOS == "windows" {
		_ = exec.Command("schtasks.exe", "/End", "/TN", "vm-doc-agent").Run()
		return nil
	}
	if _, err := os.Stat("/run/systemd/system"); err == nil {
		if _, err := exec.LookPath("systemctl"); err == nil {
			return exec.Command("systemctl", "stop", "vm-doc-agent.service").Run()
		}
	}
	if _, err := os.Stat("/etc/init.d/vm-doc-agent"); err == nil {
		return exec.Command("/etc/init.d/vm-doc-agent", "stop").Run()
	}
	return nil
}

func waitHealth(rawURL string, timeout time.Duration, expectedVersion string) error {
	deadline := time.Now().Add(timeout)
	client := &http.Client{Timeout: 4 * time.Second}
	var last string
	for time.Now().Before(deadline) {
		resp, err := client.Get(rawURL)
		if err == nil {
			body, readErr := io.ReadAll(io.LimitReader(resp.Body, 64<<10))
			resp.Body.Close()
			if readErr == nil && resp.StatusCode == http.StatusOK {
				text := string(body)
				if expectedVersion == "" || strings.Contains(text, `"version":"`+expectedVersion+`"`) || strings.Contains(text, `"version": "`+expectedVersion+`"`) {
					return nil
				}
				last = "health responded but version did not match"
			} else {
				last = fmt.Sprintf("HTTP %d", resp.StatusCode)
			}
		} else {
			last = err.Error()
		}
		time.Sleep(2 * time.Second)
	}
	return fmt.Errorf("health check timed out after %s: %s", timeout, last)
}

func copyFile(source, destination string, mode os.FileMode) error {
	in, err := os.Open(source)
	if err != nil {
		return err
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(destination), 0755); err != nil {
		return err
	}
	out, err := os.OpenFile(destination, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	syncErr := out.Sync()
	closeErr := out.Close()
	if copyErr != nil {
		return copyErr
	}
	if syncErr != nil {
		return syncErr
	}
	return closeErr
}

func fatal(message string) { fmt.Fprintln(os.Stderr, "vm-doc-updater:", message); os.Exit(1) }
