package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"sync"
	"syscall"
	"time"

	"vm-doc-agent/internal/auth"
	"vm-doc-agent/internal/central"
	"vm-doc-agent/internal/collector"
	"vm-doc-agent/internal/config"
	"vm-doc-agent/internal/inventoryfile"
	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/server"
	"vm-doc-agent/internal/updater"
	"vm-doc-agent/internal/version"
)

func main() {
	log.SetFlags(log.LstdFlags | log.LUTC)
	configPath := flag.String("config", config.DefaultPath, "path to JSON configuration")
	showVersion := flag.Bool("version", false, "print version and exit")
	checkConfig := flag.Bool("check-config", false, "validate configuration and exit")
	collectOnce := flag.Bool("collect-once", false, "collect inventory, write JSON and exit")
	printInventory := flag.Bool("print-inventory", false, "collect inventory, print JSON to stdout and exit")
	diagnostics := flag.Bool("diagnostics", false, "run diagnostics and print a safe JSON report")
	flag.Parse()

	if *showVersion {
		fmt.Printf("%s %s schema=%s commit=%s build_date=%s\n", collector.AgentName, version.Version, collector.SchemaVersion, version.Commit, version.BuildDate)
		return
	}
	if countTrue(*checkConfig, *collectOnce, *printInventory, *diagnostics) > 1 {
		log.Fatal("choose only one of -check-config, -collect-once, -print-inventory or -diagnostics")
	}

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatal(err)
	}
	if *checkConfig {
		printJSON(map[string]any{"status": "valid", "config_path": *configPath, "configuration": cfg.SafeView()})
		return
	}
	if err := collector.ValidatePlatform(); err != nil {
		log.Fatal(err)
	}

	options := collectorOptions(cfg)
	if *collectOnce || *printInventory || *diagnostics {
		inventory, collectErr := collector.Collect(options)
		if collectErr != nil {
			log.Fatal(collectErr)
		}
		switch {
		case *printInventory:
			data, marshalErr := inventoryfile.Marshal(inventory)
			if marshalErr != nil {
				log.Fatal(marshalErr)
			}
			_, _ = os.Stdout.Write(data)
		case *diagnostics:
			printJSON(buildDiagnostics(*configPath, cfg, inventory))
		default:
			size, writeErr := inventoryfile.WriteAtomic(cfg.OutputFile, inventory, cfg.Limits.MaxInventoryBytes)
			if writeErr != nil {
				log.Fatal(writeErr)
			}
			fmt.Printf("inventory written: %s (%d bytes)\n", cfg.OutputFile, size)
		}
		return
	}

	token, err := auth.EnsureToken(cfg.AuthTokenFile)
	if err != nil {
		log.Fatalf("prepare authentication token: %v", err)
	}
	if err := os.Chmod(cfg.AuthTokenFile, 0600); err != nil {
		log.Printf("level=warning event=token_permissions error=%q", err)
	}

	startedAt := time.Now().UTC()
	store := server.NewStore(model.AgentRuntimeStatus{
		Status:                "starting",
		Agent:                 model.AgentInfo{Name: collector.AgentName, Version: version.Version, Commit: version.Commit, BuildDate: version.BuildDate},
		SchemaVersion:         collector.SchemaVersion,
		StartedAt:             startedAt,
		InventoryFile:         cfg.OutputFile,
		PreviousInventoryFile: cfg.OutputFile + ".previous",
		Collectors:            map[string]model.CollectorStatus{},
	})

	centralManager, err := central.New(cfg.Central, cfg.Listen, token)
	if err != nil {
		log.Fatalf("initialize central connection: %v", err)
	}

	updateManager, err := updater.New(cfg.Updates, cfg.Central, version.Version, *configPath, cfg.Listen, cfg.StateDir, os.Exit)
	if err != nil {
		log.Fatalf("initialize auto-update: %v", err)
	}

	var refreshMutex sync.Mutex
	refreshInventory := func() error {
		refreshMutex.Lock()
		defer refreshMutex.Unlock()
		collectionStarted := time.Now().UTC()
		store.UpdateStatus(func(status *model.AgentRuntimeStatus) {
			status.Status = "collecting"
			status.CollectionInProgress = true
			status.LastError = ""
		})
		log.Printf("level=info event=collection_started")

		inventory, collectErr := collector.Collect(options)
		if collectErr != nil {
			store.UpdateStatus(func(status *model.AgentRuntimeStatus) {
				status.Status = "error"
				status.CollectionInProgress = false
				status.LastCollectionSuccessful = false
				status.LastError = collectErr.Error()
				status.LastCollectionDurationMS = time.Since(collectionStarted).Milliseconds()
			})
			log.Printf("level=error event=collection_failed error=%q", collectErr)
			return collectErr
		}

		size, writeErr := inventoryfile.WriteAtomic(cfg.OutputFile, inventory, cfg.Limits.MaxInventoryBytes)
		if writeErr != nil {
			store.UpdateStatus(func(status *model.AgentRuntimeStatus) {
				status.Status = "error"
				status.CollectionInProgress = false
				status.LastCollectionSuccessful = false
				status.LastError = writeErr.Error()
				status.LastCollectionDurationMS = time.Since(collectionStarted).Milliseconds()
			})
			log.Printf("level=error event=inventory_write_failed error=%q", writeErr)
			return writeErr
		}

		store.Set(inventory)
		completed := time.Now().UTC()
		runtimeStatus := "ready"
		if inventory.Collection.Status != "success" {
			runtimeStatus = "degraded"
		}
		store.UpdateStatus(func(status *model.AgentRuntimeStatus) {
			status.Status = runtimeStatus
			status.Agent = inventory.Agent
			status.CollectionInProgress = false
			status.LastCollectionAt = &completed
			status.LastCollectionDurationMS = completed.Sub(collectionStarted).Milliseconds()
			status.LastCollectionSuccessful = true
			status.LastError = ""
			status.InventorySizeBytes = size
			status.Collectors = inventory.Collection.Collectors
		})
		log.Printf("level=info event=collection_completed status=%s duration_ms=%d inventory_bytes=%d warnings=%d", inventory.Collection.Status, completed.Sub(collectionStarted).Milliseconds(), size, len(inventory.CollectionWarnings))
		centralManager.NotifyInventory()
		return nil
	}

	if err := refreshInventory(); err != nil {
		log.Fatalf("initial inventory collection failed: %v", err)
	}

	api := server.API{
		Store: store, Token: token, Refresh: refreshInventory,
		UpdateStatus: updateManager.Status,
		UpdateCheck:  func(ctx context.Context) (updater.Status, error) { return updateManager.Check(ctx, true) },
	}
	httpServer := &http.Server{
		Addr: cfg.Listen, Handler: api.Handler(), ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout: 10 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 60 * time.Second,
		MaxHeaderBytes: 16 << 10,
	}
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	if centralManager != nil {
		go centralManager.Run(ctx, func() central.Snapshot {
			return central.Snapshot{Inventory: store.Get(), Status: store.GetStatus()}
		})
	}
	go updateManager.Run(ctx)
	go periodicRefresh(ctx, store, refreshInventory, cfg.Refresh)
	go func() {
		log.Printf("level=info event=agent_started version=%s schema=%s listen=%s output=%s", version.Version, collector.SchemaVersion, cfg.Listen, cfg.OutputFile)
		if err := httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("HTTP server failed: %v", err)
		}
	}()
	<-ctx.Done()
	log.Printf("level=info event=agent_stopping")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := httpServer.Shutdown(shutdownCtx); err != nil {
		log.Printf("level=error event=http_shutdown error=%q", err)
	}
	log.Printf("level=info event=agent_stopped")
}

func periodicRefresh(ctx context.Context, store *server.Store, refresh func() error, interval time.Duration) {
	timer := time.NewTimer(interval)
	defer timer.Stop()
	for {
		next := time.Now().UTC().Add(interval)
		store.UpdateStatus(func(status *model.AgentRuntimeStatus) { status.NextCollectionAt = &next })
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			if err := refresh(); err != nil {
				log.Printf("level=error event=periodic_refresh_failed error=%q", err)
			}
			timer.Reset(interval)
		}
	}
}

func collectorOptions(cfg config.Config) collector.Options {
	return collector.Options{
		StateDir: cfg.StateDir, PolicyPaths: cfg.PolicyPaths,
		CollectorTimeout: cfg.CollectorTimeout, OutputTestTimeout: cfg.OutputTestTimeout,
		EnabledConfigured: true,
		Enabled: collector.EnabledCollectors{
			System: cfg.Collectors.System, Storage: cfg.Collectors.Storage, Network: cfg.Collectors.Network,
			Proxy: cfg.Collectors.Proxy, Services: cfg.Collectors.Services, ListeningPorts: cfg.Collectors.ListeningPorts,
			Firewall: cfg.Collectors.Firewall, Accounts: cfg.Collectors.Accounts, SSSD: cfg.Collectors.SSSD,
			Integrations: cfg.Collectors.Integrations, Policies: cfg.Collectors.Policies, Cron: cfg.Collectors.Cron, NTP: cfg.Collectors.NTP,
		},
		Limits: collector.Limits{
			MaxPartitions: cfg.Limits.MaxPartitions, MaxRoutes: cfg.Limits.MaxRoutes,
			MaxServices: cfg.Limits.MaxServices, MaxPorts: cfg.Limits.MaxPorts,
			MaxFirewallRules: cfg.Limits.MaxFirewallRules, MaxFirewallZones: cfg.Limits.MaxFirewallZones,
			MaxAccounts: cfg.Limits.MaxAccounts, MaxCronEntries: cfg.Limits.MaxCronEntries,
			MaxCronScripts: cfg.Limits.MaxCronScripts, MaxPolicyFiles: cfg.Limits.MaxPolicyFiles,
			MaxInventoryBytes: cfg.Limits.MaxInventoryBytes,
		},
	}
}

func buildDiagnostics(configPath string, cfg config.Config, inventory model.Inventory) map[string]any {
	return map[string]any{
		"status":         inventory.Collection.Status,
		"agent":          inventory.Agent,
		"schema_version": inventory.SchemaVersion,
		"config_path":    configPath,
		"configuration":  cfg.SafeView(),
		"host":           map[string]any{"hostname": inventory.Host.Hostname, "fqdn": inventory.Host.FQDN, "correlation_uuid": inventory.Host.CorrelationUUID},
		"os":             inventory.OS,
		"collectors":     inventory.Collection.Collectors,
		"warning_count":  len(inventory.CollectionWarnings),
		"warnings":       inventory.CollectionWarnings,
		"paths": map[string]any{
			"output":          fileMetadata(cfg.OutputFile),
			"previous_output": fileMetadata(cfg.OutputFile + ".previous"),
			"state_directory": fileMetadata(cfg.StateDir),
			"token":           fileMetadata(cfg.AuthTokenFile),
		},
	}
}

func fileMetadata(path string) map[string]any {
	result := map[string]any{"path": path, "exists": false}
	info, err := os.Stat(path)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			result["error"] = err.Error()
		}
		parent := filepath.Dir(path)
		if parentInfo, parentErr := os.Stat(parent); parentErr == nil {
			result["parent_mode"] = parentInfo.Mode().Perm().String()
		}
		return result
	}
	result["exists"] = true
	result["mode"] = info.Mode().Perm().String()
	result["size"] = info.Size()
	result["is_directory"] = info.IsDir()
	result["modified_at"] = info.ModTime().UTC()
	return result
}

func printJSON(value any) {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(value); err != nil {
		log.Fatal(err)
	}
}

func countTrue(values ...bool) int {
	count := 0
	for _, value := range values {
		if value {
			count++
		}
	}
	return count
}
