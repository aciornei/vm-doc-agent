package platform

import (
	"runtime"

	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/platform/common"
	"vm-doc-agent/internal/platform/debian"
	"vm-doc-agent/internal/platform/redhat"
	"vm-doc-agent/internal/platform/suse"
)

func CollectOS(root string) model.OSInfo {
	values, source := readOSRelease(root)
	switch {
	case suse.Matches(root, values):
		return suse.Collect(root, values, source)
	case redhat.Matches(root, values):
		return redhat.Collect(root, values, source)
	case debian.Matches(root, values):
		return debian.Collect(root, values, source)
	default:
		info := common.BaseOSInfo(values, "unknown", source)
		if info.ID == "" {
			info.ID = "unknown"
		}
		if info.Name == "" {
			info.Name = "Unknown Linux"
		}
		if info.Architecture == "" {
			info.Architecture = runtime.GOARCH
		}
		info.InitSystem = common.DetectInitSystem(root)
		return info
	}
}

func readOSRelease(root string) (map[string]string, string) {
	if common.Exists(root, "/etc/os-release") {
		return common.ParseKeyValueFile(root, "/etc/os-release"), "/etc/os-release"
	}
	if common.Exists(root, "/usr/lib/os-release") {
		return common.ParseKeyValueFile(root, "/usr/lib/os-release"), "/usr/lib/os-release"
	}
	return map[string]string{}, ""
}
