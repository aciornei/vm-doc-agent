package debian

import (
	"strings"

	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/platform/common"
)

var IDs = map[string]bool{"debian": true, "ubuntu": true, "linuxmint": true, "raspbian": true}

func Matches(root string, values map[string]string) bool {
	id := strings.ToLower(values["ID"])
	if IDs[id] {
		return true
	}
	for _, parent := range common.SplitIDLike(values["ID_LIKE"]) {
		if parent == "debian" || parent == "ubuntu" {
			return true
		}
	}
	return common.Exists(root, "/etc/debian_version")
}

func Collect(root string, values map[string]string, source string) model.OSInfo {
	info := common.BaseOSInfo(values, "debian", source)
	if info.ID == "" {
		info.ID = "debian"
	}
	if info.Name == "" {
		info.Name = "Debian GNU/Linux"
	}
	if info.VersionID == "" {
		info.VersionID = common.ReadTrimmed(root, "/etc/debian_version")
	}
	if info.Version == "" {
		info.Version = info.VersionID
	}
	if info.PrettyName == "" {
		info.PrettyName = strings.TrimSpace(info.Name + " " + info.VersionID)
	}
	if info.DetectionSource == "" {
		info.DetectionSource = "/etc/debian_version"
	}
	info.InitSystem = common.DetectInitSystem(root)
	return info
}
