package redhat

import (
	"regexp"
	"strings"

	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/platform/common"
)

var IDs = map[string]bool{"rhel": true, "centos": true, "rocky": true, "almalinux": true, "fedora": true, "ol": true, "oracle": true}
var versionPattern = regexp.MustCompile(`(?i)(?:release\s+)?([0-9]+(?:\.[0-9]+)*)`)

func Matches(root string, values map[string]string) bool {
	id := strings.ToLower(values["ID"])
	if IDs[id] {
		return true
	}
	for _, parent := range common.SplitIDLike(values["ID_LIKE"]) {
		if parent == "rhel" || parent == "fedora" || parent == "centos" {
			return true
		}
	}
	return common.Exists(root, "/etc/redhat-release")
}

func Collect(root string, values map[string]string, source string) model.OSInfo {
	info := common.BaseOSInfo(values, "redhat", source)
	release := common.ReadTrimmed(root, "/etc/redhat-release")
	if info.ID == "" {
		lower := strings.ToLower(release)
		switch {
		case strings.Contains(lower, "centos"):
			info.ID = "centos"
		case strings.Contains(lower, "red hat"):
			info.ID = "rhel"
		case strings.Contains(lower, "oracle"):
			info.ID = "ol"
		default:
			info.ID = "redhat"
		}
	}
	if info.Name == "" {
		switch info.ID {
		case "centos":
			info.Name = "CentOS Linux"
		case "rhel":
			info.Name = "Red Hat Enterprise Linux"
		case "ol":
			info.Name = "Oracle Linux"
		default:
			info.Name = "Red Hat family Linux"
		}
	}
	if info.PrettyName == "" {
		info.PrettyName = release
	}
	if info.VersionID == "" {
		if match := versionPattern.FindStringSubmatch(release); len(match) > 1 {
			info.VersionID = match[1]
		}
	}
	if info.Version == "" {
		info.Version = info.VersionID
	}
	if info.DetectionSource == "" {
		info.DetectionSource = "/etc/redhat-release"
	}
	info.InitSystem = common.DetectInitSystem(root)
	return info
}
