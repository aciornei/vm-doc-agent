package common

import (
	"os"
	"runtime"
	"strings"
	"syscall"

	"vm-doc-agent/internal/model"
)

func BaseOSInfo(values map[string]string, family, source string) model.OSInfo {
	return model.OSInfo{
		Family:          family,
		Name:            values["NAME"],
		PrettyName:      values["PRETTY_NAME"],
		ID:              strings.ToLower(values["ID"]),
		IDLike:          SplitIDLike(values["ID_LIKE"]),
		Version:         values["VERSION"],
		VersionID:       values["VERSION_ID"],
		Kernel:          KernelRelease(),
		Architecture:    runtime.GOARCH,
		DetectionSource: source,
		InitSystem:      DetectInitSystem("/"),
	}
}

func KernelRelease() string {
	var value syscall.Utsname
	if err := syscall.Uname(&value); err != nil {
		return ""
	}
	return charsToString(value.Release[:])
}

func charsToString(value []int8) string {
	buffer := make([]byte, 0, len(value))
	for _, char := range value {
		if char == 0 {
			break
		}
		buffer = append(buffer, byte(char))
	}
	return string(buffer)
}

func DetectInitSystem(root string) string {
	if Exists(root, "/run/systemd/system") {
		return "systemd"
	}
	if root == "/" || root == "" {
		if data, err := os.ReadFile("/proc/1/comm"); err == nil && strings.TrimSpace(string(data)) == "systemd" {
			return "systemd"
		}
	}
	if Exists(root, "/etc/init.d") {
		return "sysv"
	}
	return "unknown"
}
