package common

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"
)

func Path(root, absolutePath string) string {
	if root == "" || root == "/" {
		return absolutePath
	}
	return filepath.Join(root, strings.TrimPrefix(absolutePath, "/"))
}

func Exists(root, absolutePath string) bool {
	_, err := os.Stat(Path(root, absolutePath))
	return err == nil
}

func ReadTrimmed(root, absolutePath string) string {
	data, err := os.ReadFile(Path(root, absolutePath))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}

func ParseKeyValueFile(root, absolutePath string) map[string]string {
	result := make(map[string]string)
	file, err := os.Open(Path(root, absolutePath))
	if err != nil {
		return result
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, value, ok := strings.Cut(line, "=")
		if !ok {
			continue
		}
		result[strings.TrimSpace(key)] = strings.Trim(strings.TrimSpace(value), `"'`)
	}
	return result
}

func SplitIDLike(value string) []string {
	if value == "" {
		return nil
	}
	return strings.Fields(strings.ToLower(value))
}
