package platform

import (
	"os"
	"path/filepath"
	"testing"
)

func TestCollectUbuntu20(t *testing.T) {
	root := t.TempDir()
	writeFixture(t, root, "/etc/os-release", `NAME="Ubuntu"
PRETTY_NAME="Ubuntu 20.04.6 LTS"
ID=ubuntu
ID_LIKE=debian
VERSION="20.04.6 LTS (Focal Fossa)"
VERSION_ID="20.04"
`)
	info := CollectOS(root)
	if info.Family != "debian" || info.ID != "ubuntu" || info.VersionID != "20.04" {
		t.Fatalf("unexpected Ubuntu detection: %+v", info)
	}
}

func TestCollectDebian12(t *testing.T) {
	root := t.TempDir()
	writeFixture(t, root, "/etc/os-release", `PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
NAME="Debian GNU/Linux"
VERSION_ID="12"
VERSION="12 (bookworm)"
ID=debian
`)
	info := CollectOS(root)
	if info.Family != "debian" || info.ID != "debian" || info.VersionID != "12" {
		t.Fatalf("unexpected Debian detection: %+v", info)
	}
}

func TestCollectCentOS7(t *testing.T) {
	root := t.TempDir()
	writeFixture(t, root, "/etc/redhat-release", "CentOS Linux release 7.9.2009 (Core)\n")
	info := CollectOS(root)
	if info.Family != "redhat" || info.ID != "centos" || info.VersionID != "7.9.2009" {
		t.Fatalf("unexpected CentOS detection: %+v", info)
	}
}

func TestCollectSUSE11(t *testing.T) {
	root := t.TempDir()
	writeFixture(t, root, "/etc/SuSE-release", `SUSE Linux Enterprise Server 11 (x86_64)
VERSION = 11
PATCHLEVEL = 4
`)
	info := CollectOS(root)
	if info.Family != "suse" || info.ID != "sles" || info.VersionID != "11.4" {
		t.Fatalf("unexpected SUSE detection: %+v", info)
	}
}

func writeFixture(t *testing.T, root, path, content string) {
	t.Helper()
	fullPath := filepath.Join(root, path[1:])
	if err := os.MkdirAll(filepath.Dir(fullPath), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(fullPath, []byte(content), 0644); err != nil {
		t.Fatal(err)
	}
}
