package suse

import (
	"fmt"
	"strings"

	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/platform/common"
)

var IDs = map[string]bool{"sles": true, "sled": true, "suse": true, "opensuse": true, "opensuse-leap": true, "opensuse-tumbleweed": true}

func Matches(root string, values map[string]string) bool {
	id := strings.ToLower(values["ID"])
	if IDs[id] {
		return true
	}
	for _, parent := range common.SplitIDLike(values["ID_LIKE"]) {
		if parent == "suse" || parent == "opensuse" || parent == "sles" {
			return true
		}
	}
	return common.Exists(root, "/etc/SuSE-release")
}

func Collect(root string, values map[string]string, source string) model.OSInfo {
	info := common.BaseOSInfo(values, "suse", source)
	legacy := common.ReadTrimmed(root, "/etc/SuSE-release")
	if legacy != "" && info.PrettyName == "" {
		lines := nonEmptyLines(legacy)
		if len(lines) > 0 {
			info.PrettyName = strings.TrimSpace(lines[0])
			info.Name = strings.TrimSpace(strings.Split(lines[0], "(")[0])
		}
		legacyValues := parseLegacyValues(lines)
		version := legacyValues["VERSION"]
		patch := legacyValues["PATCHLEVEL"]
		if version != "" {
			info.Version = version
			info.VersionID = version
			if patch != "" {
				info.Version = fmt.Sprintf("%s SP%s", version, patch)
				info.VersionID = version + "." + patch
				info.PrettyName = strings.TrimSpace(info.PrettyName + " SP" + patch)
			}
		}
	}
	if info.ID == "" {
		info.ID = "sles"
	}
	if info.Name == "" {
		info.Name = "SUSE Linux Enterprise Server"
	}
	if info.PrettyName == "" {
		info.PrettyName = strings.TrimSpace(info.Name + " " + info.Version)
	}
	if info.DetectionSource == "" {
		info.DetectionSource = "/etc/SuSE-release"
	}
	info.InitSystem = common.DetectInitSystem(root)
	return info
}

func nonEmptyLines(value string) []string {
	var result []string
	for _, line := range strings.Split(value, "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			result = append(result, line)
		}
	}
	return result
}

func parseLegacyValues(lines []string) map[string]string {
	result := make(map[string]string)
	for _, line := range lines {
		key, value, ok := strings.Cut(line, "=")
		if ok {
			result[strings.TrimSpace(key)] = strings.TrimSpace(value)
		}
	}
	return result
}
