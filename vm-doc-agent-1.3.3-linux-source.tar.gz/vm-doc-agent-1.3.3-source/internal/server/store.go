package server

import (
	"sync"
	"time"

	"vm-doc-agent/internal/model"
)

type Store struct {
	mu        sync.RWMutex
	inventory model.Inventory
	status    model.AgentRuntimeStatus
}

func NewStore(status model.AgentRuntimeStatus) *Store {
	return &Store{status: status}
}

func (s *Store) Set(inventory model.Inventory) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.inventory = inventory
}

func (s *Store) Get() model.Inventory {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.inventory
}

func (s *Store) SetStatus(status model.AgentRuntimeStatus) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.status = status
}

func (s *Store) UpdateStatus(update func(*model.AgentRuntimeStatus)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	update(&s.status)
}

func (s *Store) GetStatus() model.AgentRuntimeStatus {
	s.mu.RLock()
	defer s.mu.RUnlock()
	status := s.status
	if !status.StartedAt.IsZero() {
		status.UptimeSeconds = uint64(time.Since(status.StartedAt).Seconds())
	}
	return status
}
