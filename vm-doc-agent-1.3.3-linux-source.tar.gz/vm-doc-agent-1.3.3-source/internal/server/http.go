package server

import (
	"context"
	"encoding/json"
	"log"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/auth"
	"vm-doc-agent/internal/collector"
	"vm-doc-agent/internal/updater"
	"vm-doc-agent/internal/version"
)

type RefreshFunc func() error
type UpdateCheckFunc func(context.Context) (updater.Status, error)

type API struct {
	Store        *Store
	Token        string
	Refresh      RefreshFunc
	UpdateStatus func() updater.Status
	UpdateCheck  UpdateCheckFunc
}

func (a API) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/health", method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		status := a.Store.GetStatus()
		health := "ok"
		if status.Status == "error" {
			health = "error"
		}
		writeJSON(w, http.StatusOK, map[string]any{"status": health, "agent": collector.AgentName, "version": version.Version, "schema_version": collector.SchemaVersion})
	}))
	mux.HandleFunc("/v1/status", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		writeJSON(w, http.StatusOK, a.Store.GetStatus())
	})))
	mux.HandleFunc("/v1/version", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		writeJSON(w, http.StatusOK, map[string]string{"name": collector.AgentName, "version": version.Version, "schema_version": collector.SchemaVersion, "commit": version.Commit, "build_date": version.BuildDate})
	})))
	mux.HandleFunc("/v1/identity", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		inventory := a.Store.Get()
		writeJSON(w, http.StatusOK, map[string]any{"agent": inventory.Agent, "host": inventory.Host})
	})))
	mux.HandleFunc("/v1/storage", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Storage) })))
	mux.HandleFunc("/v1/network", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Network) })))
	mux.HandleFunc("/v1/system", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().System) })))
	mux.HandleFunc("/v1/proxy", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Proxy) })))
	mux.HandleFunc("/v1/services", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Services) })))
	mux.HandleFunc("/v1/listening-ports", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		writeJSON(w, http.StatusOK, a.Store.Get().ListeningPorts)
	})))
	mux.HandleFunc("/v1/firewall", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Firewall) })))
	mux.HandleFunc("/v1/accounts", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Accounts) })))
	mux.HandleFunc("/v1/sssd", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().SSSD) })))
	mux.HandleFunc("/v1/integrations", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Integrations) })))
	mux.HandleFunc("/v1/policies", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Policies) })))
	mux.HandleFunc("/v1/cron", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().Cron) })))
	mux.HandleFunc("/v1/ntp", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get().NTP) })))
	mux.HandleFunc("/v1/inventory", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) { writeJSON(w, http.StatusOK, a.Store.Get()) })))
	mux.HandleFunc("/v1/inventory/refresh", a.authorize(method(http.MethodPost, func(w http.ResponseWriter, _ *http.Request) {
		if err := a.Refresh(); err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, http.StatusOK, a.Store.Get())
	})))
	mux.HandleFunc("/v1/update", a.authorize(method(http.MethodGet, func(w http.ResponseWriter, _ *http.Request) {
		if a.UpdateStatus == nil {
			writeJSON(w, http.StatusOK, updater.Status{State: "disabled"})
			return
		}
		writeJSON(w, http.StatusOK, a.UpdateStatus())
	})))
	mux.HandleFunc("/v1/update/check", a.authorize(method(http.MethodPost, func(w http.ResponseWriter, r *http.Request) {
		if a.UpdateCheck == nil {
			writeJSON(w, http.StatusConflict, map[string]string{"error": "updates disabled"})
			return
		}
		status, err := a.UpdateCheck(r.Context())
		if err != nil {
			writeJSON(w, http.StatusBadGateway, map[string]any{"error": err.Error(), "update": status})
			return
		}
		writeJSON(w, http.StatusOK, status)
	})))
	return requestLogger(mux)
}

func (a API) authorize(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !auth.ValidBearer(r.Header.Get("Authorization"), a.Token) {
			log.Printf("level=warning event=unauthorized_request method=%s path=%s remote=%s", r.Method, r.URL.Path, remoteHost(r.RemoteAddr))
			w.Header().Set("WWW-Authenticate", `Bearer realm="vm-doc-agent"`)
			writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "unauthorized"})
			return
		}
		next(w, r)
	}
}

func method(expected string, next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.Method != expected {
			w.Header().Set("Allow", expected)
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method not allowed"})
			return
		}
		next(w, r)
	}
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(value); err != nil {
		log.Printf("level=error event=http_response_write error=%q", err)
	}
}

type statusRecorder struct {
	http.ResponseWriter
	status int
	bytes  int
}

func (recorder *statusRecorder) WriteHeader(status int) {
	recorder.status = status
	recorder.ResponseWriter.WriteHeader(status)
}

func (recorder *statusRecorder) Write(data []byte) (int, error) {
	if recorder.status == 0 {
		recorder.WriteHeader(http.StatusOK)
	}
	written, err := recorder.ResponseWriter.Write(data)
	recorder.bytes += written
	return written, err
}

func requestLogger(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		started := time.Now()
		recorder := &statusRecorder{ResponseWriter: w}
		next.ServeHTTP(recorder, r)
		status := recorder.status
		if status == 0 {
			status = http.StatusOK
		}
		log.Printf("level=info event=http_request method=%s path=%s status=%d bytes=%d remote=%s duration_ms=%d", r.Method, r.URL.Path, status, recorder.bytes, remoteHost(r.RemoteAddr), time.Since(started).Milliseconds())
	})
}

func remoteHost(address string) string {
	host, _, err := net.SplitHostPort(address)
	if err == nil {
		return host
	}
	return strings.Trim(address, "[]")
}

func parseContentLength(value string) int64 {
	parsed, _ := strconv.ParseInt(value, 10, 64)
	return parsed
}
