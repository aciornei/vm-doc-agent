package server

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"vm-doc-agent/internal/model"
)

func TestStatusEndpointRequiresTokenAndReturnsStatus(t *testing.T) {
	started := time.Now().UTC()
	store := NewStore(model.AgentRuntimeStatus{Status: "ready", StartedAt: started})
	api := API{Store: store, Token: "12345678901234567890123456789012", Refresh: func() error { return nil }}

	request := httptest.NewRequest(http.MethodGet, "/v1/status", nil)
	response := httptest.NewRecorder()
	api.Handler().ServeHTTP(response, request)
	if response.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401, got %d", response.Code)
	}

	request = httptest.NewRequest(http.MethodGet, "/v1/status", nil)
	request.Header.Set("Authorization", "Bearer 12345678901234567890123456789012")
	response = httptest.NewRecorder()
	api.Handler().ServeHTTP(response, request)
	if response.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", response.Code)
	}
}
