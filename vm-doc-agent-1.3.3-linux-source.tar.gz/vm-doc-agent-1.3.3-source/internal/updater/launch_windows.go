//go:build windows

package updater

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

func launchHelper(path string, args []string) error {
	taskName := fmt.Sprintf("vm-doc-agent-update-%d", os.Getpid())
	script := filepath.Join(os.TempDir(), taskName+".cmd")
	var line strings.Builder
	line.WriteString("@echo off\r\n")
	line.WriteString(cmdQuote(path))
	for _, arg := range args {
		line.WriteByte(' ')
		line.WriteString(cmdQuote(arg))
	}
	line.WriteString("\r\nset VM_DOC_UPDATE_RC=%ERRORLEVEL%\r\n")
	line.WriteString("schtasks.exe /Delete /TN ")
	line.WriteString(cmdQuote(taskName))
	line.WriteString(" /F >nul 2>&1\r\n")
	line.WriteString("del /q \"%~f0\" >nul 2>&1\r\n")
	line.WriteString("exit /b %VM_DOC_UPDATE_RC%\r\n")
	if err := os.WriteFile(script, []byte(line.String()), 0600); err != nil {
		return err
	}
	systemRoot := os.Getenv("SystemRoot")
	if systemRoot == "" {
		systemRoot = `C:\Windows`
	}
	taskRun := fmt.Sprintf(`"%s" /d /c "%s"`, filepath.Join(systemRoot, "System32", "cmd.exe"), script)
	create := exec.Command("schtasks.exe", "/Create", "/TN", taskName, "/SC", "ONSTART", "/TR", taskRun, "/RU", "SYSTEM", "/RL", "HIGHEST", "/F")
	if output, err := create.CombinedOutput(); err != nil {
		_ = os.Remove(script)
		return fmt.Errorf("create transient update task: %w (%s)", err, strings.TrimSpace(string(output)))
	}
	run := exec.Command("schtasks.exe", "/Run", "/TN", taskName)
	if output, err := run.CombinedOutput(); err != nil {
		_ = exec.Command("schtasks.exe", "/Delete", "/TN", taskName, "/F").Run()
		_ = os.Remove(script)
		return fmt.Errorf("start transient update task: %w (%s)", err, strings.TrimSpace(string(output)))
	}
	return nil
}

func cmdQuote(value string) string {
	return `"` + strings.ReplaceAll(value, `"`, `""`) + `"`
}
