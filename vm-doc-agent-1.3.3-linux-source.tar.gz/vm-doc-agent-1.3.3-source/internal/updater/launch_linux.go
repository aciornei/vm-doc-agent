//go:build !windows

package updater

import (
	"fmt"
	"os"
	"os/exec"
)

func launchHelper(path string, args []string) error {
	if _, err := os.Stat("/run/systemd/system"); err == nil {
		if systemdRun, lookErr := exec.LookPath("systemd-run"); lookErr == nil {
			unit := fmt.Sprintf("vm-doc-agent-update-%d", os.Getpid())
			runArgs := []string{"--unit", unit, "--collect", "--no-block", "--property=Type=exec", path}
			runArgs = append(runArgs, args...)
			cmd := exec.Command(systemdRun, runArgs...)
			cmd.Stdout = os.Stdout
			cmd.Stderr = os.Stderr
			return cmd.Run()
		}
	}
	cmd := exec.Command(path, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Start()
}
