package updater

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-agent/internal/config"
)

type Release struct {
	Available        bool   `json:"available"`
	Version          string `json:"version,omitempty"`
	Channel          string `json:"channel,omitempty"`
	OS               string `json:"os,omitempty"`
	Arch             string `json:"arch,omitempty"`
	AgentURL         string `json:"agent_url,omitempty"`
	AgentSHA256      string `json:"agent_sha256,omitempty"`
	AgentSizeBytes   int64  `json:"agent_size_bytes,omitempty"`
	UpdaterURL       string `json:"updater_url,omitempty"`
	UpdaterSHA256    string `json:"updater_sha256,omitempty"`
	UpdaterSizeBytes int64  `json:"updater_size_bytes,omitempty"`
	PublishedAt      string `json:"published_at,omitempty"`
	Notes            string `json:"notes,omitempty"`
}

type Status struct {
	Enabled          bool       `json:"enabled"`
	AutoInstall      bool       `json:"auto_install"`
	Channel          string     `json:"channel"`
	CurrentVersion   string     `json:"current_version"`
	State            string     `json:"state"`
	AvailableVersion string     `json:"available_version,omitempty"`
	LastCheckAt      *time.Time `json:"last_check_at,omitempty"`
	LastSuccessAt    *time.Time `json:"last_success_at,omitempty"`
	LastError        string     `json:"last_error,omitempty"`
	NextCheckAt      *time.Time `json:"next_check_at,omitempty"`
	DownloadedBytes  int64      `json:"downloaded_bytes,omitempty"`
	UpdatePreparedAt *time.Time `json:"update_prepared_at,omitempty"`
}

type Manager struct {
	cfg            config.UpdateConfig
	central        config.CentralConfig
	currentVersion string
	configPath     string
	listen         string
	stateDir       string
	token          string
	client         *http.Client
	mu             sync.RWMutex
	status         Status
	installMu      sync.Mutex
	exit           func(int)
}

func New(cfg config.UpdateConfig, central config.CentralConfig, currentVersion, configPath, listen, stateDir string, exit func(int)) (*Manager, error) {
	m := &Manager{
		cfg: cfg, central: central, currentVersion: strings.TrimSpace(currentVersion),
		configPath: configPath, listen: listen, stateDir: stateDir, exit: exit,
		status: Status{Enabled: cfg.Enabled, AutoInstall: cfg.AutoInstall, Channel: cfg.Channel, CurrentVersion: currentVersion, State: "disabled"},
	}
	if !cfg.Enabled {
		return m, nil
	}
	if !central.Enabled {
		return nil, errors.New("updates require central.enabled=true")
	}
	token, err := readSecret(central.RegistrationTokenFile)
	if err != nil {
		return nil, fmt.Errorf("read update registration token: %w", err)
	}
	client, err := newHTTPClient(central)
	if err != nil {
		return nil, err
	}
	m.token = token
	m.client = client
	m.status.State = "idle"
	return m, nil
}

func (m *Manager) Status() Status {
	if m == nil {
		return Status{State: "disabled"}
	}
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.status
}

func (m *Manager) Run(ctx context.Context) {
	if m == nil || !m.cfg.Enabled {
		return
	}
	initial := 2 * time.Minute
	if m.cfg.CheckInterval < initial {
		initial = m.cfg.CheckInterval
	}
	timer := time.NewTimer(initial)
	defer timer.Stop()
	m.setNext(time.Now().UTC().Add(initial))
	for {
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			if _, err := m.Check(ctx, m.cfg.AutoInstall); err != nil {
				log.Printf("level=warning event=update_check_failed error=%q", err)
			}
			next := time.Now().UTC().Add(m.cfg.CheckInterval)
			m.setNext(next)
			timer.Reset(m.cfg.CheckInterval)
		}
	}
}

func (m *Manager) Check(ctx context.Context, allowInstall bool) (Status, error) {
	if m == nil || !m.cfg.Enabled {
		return m.Status(), nil
	}
	m.installMu.Lock()
	defer m.installMu.Unlock()

	now := time.Now().UTC()
	m.updateStatus(func(s *Status) {
		s.State = "checking"
		s.LastCheckAt = &now
		s.LastError = ""
		s.DownloadedBytes = 0
	})

	release, err := m.fetchLatest(ctx)
	if err != nil {
		m.fail(err)
		return m.Status(), err
	}
	if !release.Available || compareVersions(release.Version, m.currentVersion) <= 0 {
		m.updateStatus(func(s *Status) {
			s.State = "current"
			s.AvailableVersion = ""
			s.LastSuccessAt = &now
		})
		return m.Status(), nil
	}
	if release.OS != "" && release.OS != runtime.GOOS {
		err := fmt.Errorf("update OS mismatch: manifest=%s runtime=%s", release.OS, runtime.GOOS)
		m.fail(err)
		return m.Status(), err
	}
	if release.Arch != "" && release.Arch != runtime.GOARCH {
		err := fmt.Errorf("update architecture mismatch: manifest=%s runtime=%s", release.Arch, runtime.GOARCH)
		m.fail(err)
		return m.Status(), err
	}
	m.updateStatus(func(s *Status) {
		s.State = "update_available"
		s.AvailableVersion = release.Version
		s.LastSuccessAt = &now
	})
	if !allowInstall {
		return m.Status(), nil
	}
	if err := m.prepareAndInstall(ctx, release); err != nil {
		m.fail(err)
		return m.Status(), err
	}
	return m.Status(), nil
}

func (m *Manager) fetchLatest(ctx context.Context) (Release, error) {
	base, err := url.Parse(strings.TrimRight(m.central.URL, "/"))
	if err != nil {
		return Release{}, err
	}
	endpoint := *base
	endpoint.Path = strings.TrimRight(base.Path, "/") + m.cfg.Endpoint
	query := endpoint.Query()
	query.Set("channel", m.cfg.Channel)
	query.Set("os", runtime.GOOS)
	query.Set("arch", runtime.GOARCH)
	query.Set("current", m.currentVersion)
	endpoint.RawQuery = query.Encode()

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, endpoint.String(), nil)
	if err != nil {
		return Release{}, err
	}
	req.Header.Set("Authorization", "Bearer "+m.token)
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "vm-doc-agent/"+m.currentVersion)
	resp, err := m.client.Do(req)
	if err != nil {
		return Release{}, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
		return Release{}, fmt.Errorf("update manifest HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(body)))
	}
	var release Release
	decoder := json.NewDecoder(io.LimitReader(resp.Body, 1<<20))
	if err := decoder.Decode(&release); err != nil {
		return Release{}, fmt.Errorf("decode update manifest: %w", err)
	}
	return release, nil
}

func (m *Manager) prepareAndInstall(ctx context.Context, release Release) error {
	if strings.TrimSpace(release.AgentURL) == "" || strings.TrimSpace(release.AgentSHA256) == "" {
		return errors.New("update manifest is missing agent_url or agent_sha256")
	}
	if strings.TrimSpace(release.UpdaterURL) == "" || strings.TrimSpace(release.UpdaterSHA256) == "" {
		return errors.New("update manifest is missing updater_url or updater_sha256")
	}
	if err := os.MkdirAll(m.cfg.DownloadDir, 0750); err != nil {
		return fmt.Errorf("create update directory: %w", err)
	}
	ext := ""
	if runtime.GOOS == "windows" {
		ext = ".exe"
	}
	agentTmp := filepath.Join(m.cfg.DownloadDir, "vm-doc-agent-"+release.Version+".new"+ext)
	updaterTmp := filepath.Join(m.cfg.DownloadDir, "vm-doc-updater-"+release.Version+".new"+ext)

	m.updateStatus(func(s *Status) { s.State = "downloading" })
	n1, err := m.download(ctx, release.AgentURL, agentTmp, release.AgentSHA256, release.AgentSizeBytes)
	if err != nil {
		return fmt.Errorf("download agent update: %w", err)
	}
	n2, err := m.download(ctx, release.UpdaterURL, updaterTmp, release.UpdaterSHA256, release.UpdaterSizeBytes)
	if err != nil {
		return fmt.Errorf("download updater update: %w", err)
	}
	m.updateStatus(func(s *Status) { s.DownloadedBytes = n1 + n2 })
	if runtime.GOOS != "windows" {
		_ = os.Chmod(agentTmp, 0755)
		_ = os.Chmod(updaterTmp, 0755)
	}
	if err := verifyExecutableVersion(ctx, agentTmp, "vm-doc-agent", release.Version); err != nil {
		return err
	}
	if err := verifyExecutableVersion(ctx, updaterTmp, "vm-doc-updater", release.Version); err != nil {
		return err
	}

	currentExe, err := os.Executable()
	if err != nil {
		return fmt.Errorf("resolve current executable: %w", err)
	}
	currentExe, _ = filepath.Abs(currentExe)
	helperTarget := filepath.Join(filepath.Dir(currentExe), "vm-doc-updater"+ext)
	if err := replaceHelper(updaterTmp, helperTarget); err != nil {
		return fmt.Errorf("replace updater helper: %w", err)
	}

	healthURL := localHealthURL(m.listen)
	args := []string{
		"-pid", strconv.Itoa(os.Getpid()),
		"-source", agentTmp,
		"-target", currentExe,
		"-backup", currentExe + ".previous",
		"-config", m.configPath,
		"-health-url", healthURL,
		"-health-timeout", m.cfg.HealthTimeout.String(),
		"-expected-version", release.Version,
	}
	if err := launchHelper(helperTarget, args); err != nil {
		return fmt.Errorf("launch updater helper: %w", err)
	}
	prepared := time.Now().UTC()
	m.updateStatus(func(s *Status) {
		s.State = "installing"
		s.UpdatePreparedAt = &prepared
	})
	log.Printf("level=info event=update_install_scheduled current=%s target=%s channel=%s", m.currentVersion, release.Version, m.cfg.Channel)
	go func() {
		time.Sleep(1200 * time.Millisecond)
		if m.exit != nil {
			m.exit(0)
		}
	}()
	return nil
}

func (m *Manager) download(ctx context.Context, rawURL, destination, expectedHash string, expectedSize int64) (int64, error) {
	resolved, err := m.resolveDownloadURL(rawURL)
	if err != nil {
		return 0, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, resolved, nil)
	if err != nil {
		return 0, err
	}
	req.Header.Set("Authorization", "Bearer "+m.token)
	req.Header.Set("Accept", "application/octet-stream")
	req.Header.Set("User-Agent", "vm-doc-agent/"+m.currentVersion)
	resp, err := m.client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
		return 0, fmt.Errorf("download HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(body)))
	}
	max := m.cfg.MaxDownloadBytes
	if expectedSize > 0 && expectedSize > max {
		return 0, fmt.Errorf("release size %d exceeds max_download_bytes %d", expectedSize, max)
	}
	tmp := destination + ".part"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if err != nil {
		return 0, err
	}
	hasher := sha256.New()
	n, copyErr := io.Copy(io.MultiWriter(f, hasher), io.LimitReader(resp.Body, max+1))
	closeErr := f.Close()
	if copyErr != nil {
		_ = os.Remove(tmp)
		return 0, copyErr
	}
	if closeErr != nil {
		_ = os.Remove(tmp)
		return 0, closeErr
	}
	if n > max {
		_ = os.Remove(tmp)
		return 0, fmt.Errorf("download exceeds max_download_bytes %d", max)
	}
	if expectedSize > 0 && n != expectedSize {
		_ = os.Remove(tmp)
		return 0, fmt.Errorf("download size mismatch: expected=%d actual=%d", expectedSize, n)
	}
	actual := hex.EncodeToString(hasher.Sum(nil))
	if !strings.EqualFold(strings.TrimSpace(expectedHash), actual) {
		_ = os.Remove(tmp)
		return 0, fmt.Errorf("SHA256 mismatch: expected=%s actual=%s", expectedHash, actual)
	}
	if err := os.Rename(tmp, destination); err != nil {
		_ = os.Remove(tmp)
		return 0, err
	}
	return n, nil
}

func (m *Manager) resolveDownloadURL(raw string) (string, error) {
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil {
		return "", err
	}
	base, err := url.Parse(strings.TrimRight(m.central.URL, "/"))
	if err != nil {
		return "", err
	}
	if !u.IsAbs() {
		u = base.ResolveReference(u)
	}
	if !sameOrigin(base, u) {
		return "", errors.New("update download URL must use the configured central server origin")
	}
	return u.String(), nil
}

func sameOrigin(a, b *url.URL) bool {
	return strings.EqualFold(a.Scheme, b.Scheme) && strings.EqualFold(a.Host, b.Host)
}

func (m *Manager) fail(err error) {
	now := time.Now().UTC()
	m.updateStatus(func(s *Status) {
		s.State = "error"
		s.LastError = err.Error()
		s.LastCheckAt = &now
	})
}

func (m *Manager) updateStatus(fn func(*Status)) {
	m.mu.Lock()
	defer m.mu.Unlock()
	fn(&m.status)
}

func (m *Manager) setNext(value time.Time) {
	m.updateStatus(func(s *Status) { s.NextCheckAt = &value })
}

func replaceHelper(source, target string) error {
	if _, err := os.Stat(target); err == nil {
		_ = os.Remove(target + ".previous")
		if err := copyFile(target, target+".previous", 0755); err != nil {
			return err
		}
	}
	if err := copyFile(source, target+".new", 0755); err != nil {
		return err
	}
	if runtime.GOOS == "windows" {
		_ = os.Remove(target)
	}
	if err := os.Rename(target+".new", target); err != nil {
		return err
	}
	if runtime.GOOS != "windows" {
		_ = os.Chmod(target, 0755)
	}
	return nil
}

func copyFile(source, destination string, mode os.FileMode) error {
	in, err := os.Open(source)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(destination, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(out, in)
	syncErr := out.Sync()
	closeErr := out.Close()
	if copyErr != nil {
		return copyErr
	}
	if syncErr != nil {
		return syncErr
	}
	return closeErr
}

func verifyExecutableVersion(ctx context.Context, path, expectedName, expectedVersion string) error {
	checkCtx, cancel := context.WithTimeout(ctx, 20*time.Second)
	defer cancel()
	out, err := exec.CommandContext(checkCtx, path, "-version").CombinedOutput()
	if err != nil {
		return fmt.Errorf("validate downloaded %s: %w (%s)", expectedName, err, strings.TrimSpace(string(out)))
	}
	text := strings.TrimSpace(string(out))
	if !strings.Contains(text, expectedName) || !strings.Contains(text, " "+expectedVersion+" ") {
		return fmt.Errorf("downloaded %s version mismatch: %s", expectedName, text)
	}
	return nil
}

func localHealthURL(listen string) string {
	_, port, err := net.SplitHostPort(strings.TrimSpace(listen))
	if err != nil || port == "" {
		port = "9078"
	}
	return "http://127.0.0.1:" + port + "/health"
}

func newHTTPClient(cfg config.CentralConfig) (*http.Client, error) {
	transport := &http.Transport{
		Proxy:           http.ProxyFromEnvironment,
		TLSClientConfig: &tls.Config{MinVersion: tls.VersionTLS12, ServerName: cfg.TLSServerName, InsecureSkipVerify: cfg.InsecureSkipVerify}, //nolint:gosec
		IdleConnTimeout: 90 * time.Second,
	}
	if cfg.CAFile != "" {
		pool, err := x509.SystemCertPool()
		if err != nil || pool == nil {
			pool = x509.NewCertPool()
		}
		pem, err := os.ReadFile(cfg.CAFile)
		if err != nil {
			return nil, fmt.Errorf("read central CA file: %w", err)
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, errors.New("central CA file does not contain a valid PEM certificate")
		}
		transport.TLSClientConfig.RootCAs = pool
	}
	return &http.Client{Transport: transport, Timeout: cfg.RequestTimeout, CheckRedirect: func(_ *http.Request, _ []*http.Request) error { return http.ErrUseLastResponse }}, nil
}

func readSecret(path string) (string, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	value := strings.TrimSpace(string(raw))
	if len(value) < 24 {
		return "", errors.New("registration token must contain at least 24 characters")
	}
	return value, nil
}

func compareVersions(a, b string) int {
	pa := parseVersion(a)
	pb := parseVersion(b)
	for i := 0; i < 3; i++ {
		if pa[i] < pb[i] {
			return -1
		}
		if pa[i] > pb[i] {
			return 1
		}
	}
	return strings.Compare(a, b)
}

func parseVersion(v string) [3]int {
	v = strings.TrimPrefix(strings.TrimSpace(v), "v")
	core := strings.SplitN(v, "-", 2)[0]
	parts := strings.Split(core, ".")
	var out [3]int
	for i := 0; i < len(parts) && i < 3; i++ {
		out[i], _ = strconv.Atoi(parts[i])
	}
	return out
}
