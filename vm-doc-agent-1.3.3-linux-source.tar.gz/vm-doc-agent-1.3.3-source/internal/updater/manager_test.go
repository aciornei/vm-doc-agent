package updater

import (
	"net/url"
	"testing"
)

func TestCompareVersions(t *testing.T) {
	cases := []struct {
		a, b string
		want int
	}{
		{"1.3.0", "1.2.9", 1}, {"1.3.0", "1.3.0", 0}, {"1.2.9", "1.3.0", -1}, {"v2.0.0", "1.9.9", 1},
	}
	for _, tc := range cases {
		got := compareVersions(tc.a, tc.b)
		if tc.want < 0 && got >= 0 || tc.want == 0 && got != 0 || tc.want > 0 && got <= 0 {
			t.Fatalf("compareVersions(%q,%q)=%d want sign %d", tc.a, tc.b, got, tc.want)
		}
	}
}

func TestSameOrigin(t *testing.T) {
	a, _ := url.Parse("http://172.20.1.20:9080")
	b, _ := url.Parse("http://172.20.1.20:9080/api/file")
	c, _ := url.Parse("http://evil.example/api/file")
	if !sameOrigin(a, b) {
		t.Fatal("expected same origin")
	}
	if sameOrigin(a, c) {
		t.Fatal("unexpected same origin")
	}
}
