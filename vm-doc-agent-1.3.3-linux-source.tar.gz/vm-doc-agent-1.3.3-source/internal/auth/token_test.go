package auth

import (
	"path/filepath"
	"testing"
)

func TestEnsureTokenIsPersistent(t *testing.T) {
	path := filepath.Join(t.TempDir(), "token")
	first, err := EnsureToken(path)
	if err != nil {
		t.Fatal(err)
	}
	second, err := EnsureToken(path)
	if err != nil {
		t.Fatal(err)
	}
	if first != second || len(first) != 64 {
		t.Fatalf("unexpected tokens: %q %q", first, second)
	}
	if !ValidBearer("Bearer "+first, first) {
		t.Fatal("valid bearer token rejected")
	}
}
