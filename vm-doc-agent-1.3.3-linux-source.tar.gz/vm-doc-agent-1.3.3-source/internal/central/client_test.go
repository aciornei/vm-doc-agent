package central

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"vm-doc-agent/internal/config"
	"vm-doc-agent/internal/model"
)

func TestRegistrationInventoryAndHeartbeat(t *testing.T) {
	var mu sync.Mutex
	paths := []string{}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "Bearer registration-token-1234567890" {
			t.Fatalf("unexpected authorization header")
		}
		mu.Lock()
		paths = append(paths, r.URL.Path)
		mu.Unlock()
		if r.URL.Path == "/api/v1/agent-registration/register" {
			var request RegistrationRequest
			if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
				t.Fatal(err)
			}
			if request.Agent.ID != "agent-1" || request.BaseURL != "http://192.0.2.10:9078" || request.AgentToken != "local-agent-token-1234567890" {
				t.Fatalf("unexpected registration: %+v", request)
			}
			_ = json.NewEncoder(w).Encode(RegistrationResponse{AgentID: 7, Created: true, Linked: true})
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}))
	defer server.Close()

	dir := t.TempDir()
	tokenFile := filepath.Join(dir, "registration-token")
	if err := os.WriteFile(tokenFile, []byte("registration-token-1234567890\n"), 0600); err != nil {
		t.Fatal(err)
	}
	cfg := config.CentralConfig{
		Enabled:                 true,
		URL:                     server.URL,
		AllowHTTP:               true,
		RegistrationTokenFile:   tokenFile,
		HeartbeatInterval:       50 * time.Millisecond,
		RetryInterval:           20 * time.Millisecond,
		RequestTimeout:          time.Second,
		AdvertiseURL:            "http://192.0.2.10:9078",
		AgentCollectionInterval: 15 * time.Minute,
	}
	manager, err := New(cfg, "0.0.0.0:9078", "local-agent-token-1234567890")
	if err != nil {
		t.Fatal(err)
	}
	now := time.Now().UTC()
	snapshot := Snapshot{Inventory: model.Inventory{
		SchemaVersion: "2.0",
		Agent:         model.AgentInfo{ID: "agent-1", Name: "vm-doc-agent", Version: "1.1.0"},
		CollectedAt:   now,
		Collection:    model.CollectionInfo{Status: "success"},
		Host:          model.HostInfo{Hostname: "vm01"},
	}, Status: model.AgentRuntimeStatus{Status: "ready"}}
	ctx, cancel := context.WithCancel(context.Background())
	go manager.Run(ctx, func() Snapshot { return snapshot })
	time.Sleep(90 * time.Millisecond)
	cancel()
	time.Sleep(10 * time.Millisecond)

	mu.Lock()
	defer mu.Unlock()
	seen := map[string]bool{}
	for _, path := range paths {
		seen[path] = true
	}
	for _, expected := range []string{"/api/v1/agent-registration/register", "/api/v1/agent-registration/inventory", "/api/v1/agent-registration/heartbeat"} {
		if !seen[expected] {
			t.Fatalf("missing request %s; paths=%v", expected, paths)
		}
	}
}

func TestPrimaryInventoryIPPrefersDefaultRouteInterface(t *testing.T) {
	inventory := model.Inventory{Network: model.NetworkInfo{
		DefaultGateways: []model.GatewayInfo{{Family: "ipv4", Interface: "ens160"}},
		Interfaces: []model.NetworkInterface{
			{Name: "docker0", Addresses: []model.IPAddress{{Family: "ipv4", Address: "172.17.0.1"}}},
			{Name: "ens160", Addresses: []model.IPAddress{{Family: "ipv4", Address: "10.20.30.40"}}},
		},
	}}
	if got := primaryInventoryIP(inventory); got != "10.20.30.40" {
		t.Fatalf("unexpected address %q", got)
	}
}
