package central

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/config"
	"vm-doc-agent/internal/model"
)

const protocolVersion = "1"

type Snapshot struct {
	Inventory model.Inventory
	Status    model.AgentRuntimeStatus
}

type Provider func() Snapshot

type Manager struct {
	cfg               config.CentralConfig
	listen            string
	localAgentToken   string
	registrationToken string
	client            *http.Client
	notify            chan struct{}
	registered        bool
	lastInventoryHash string
}

type RegistrationRequest struct {
	ProtocolVersion          string           `json:"protocol_version"`
	Agent                    model.AgentInfo  `json:"agent"`
	Host                     RegistrationHost `json:"host"`
	BaseURL                  string           `json:"base_url"`
	AgentToken               string           `json:"agent_token"`
	RefreshIntervalSeconds   int64            `json:"refresh_interval_seconds"`
	HeartbeatIntervalSeconds int64            `json:"heartbeat_interval_seconds"`
	CollectedAt              time.Time        `json:"collected_at"`
}

type RegistrationHost struct {
	Hostname          string `json:"hostname"`
	FQDN              string `json:"fqdn,omitempty"`
	ProductUUID       string `json:"product_uuid,omitempty"`
	ProductUUIDLegacy string `json:"product_uuid_legacy,omitempty"`
	MachineID         string `json:"machine_id,omitempty"`
	PrimaryIP         string `json:"primary_ip,omitempty"`
}

type HeartbeatRequest struct {
	ProtocolVersion  string          `json:"protocol_version"`
	Agent            model.AgentInfo `json:"agent"`
	RuntimeStatus    string          `json:"runtime_status"`
	CollectionStatus string          `json:"collection_status,omitempty"`
	CollectedAt      time.Time       `json:"collected_at,omitempty"`
	InventorySHA256  string          `json:"inventory_sha256,omitempty"`
}

type RegistrationResponse struct {
	AgentID int64  `json:"agent_id"`
	VMID    *int64 `json:"vm_id,omitempty"`
	Created bool   `json:"created"`
	Linked  bool   `json:"linked"`
}

func New(cfg config.CentralConfig, listen, localAgentToken string) (*Manager, error) {
	if !cfg.Enabled {
		return nil, nil
	}
	registrationToken, err := readSecret(cfg.RegistrationTokenFile)
	if err != nil {
		return nil, fmt.Errorf("read central registration token: %w", err)
	}
	transport := &http.Transport{
		Proxy: http.ProxyFromEnvironment,
		TLSClientConfig: &tls.Config{
			MinVersion:         tls.VersionTLS12,
			ServerName:         cfg.TLSServerName,
			InsecureSkipVerify: cfg.InsecureSkipVerify, //nolint:gosec -- explicit operator setting for private PKI bootstrap
		},
		IdleConnTimeout: 90 * time.Second,
	}
	if cfg.CAFile != "" {
		pool, err := systemCertPoolWithFile(cfg.CAFile)
		if err != nil {
			return nil, err
		}
		transport.TLSClientConfig.RootCAs = pool
	}
	client := &http.Client{
		Transport: transport,
		Timeout:   cfg.RequestTimeout,
		CheckRedirect: func(_ *http.Request, _ []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	return &Manager{
		cfg:               cfg,
		listen:            listen,
		localAgentToken:   localAgentToken,
		registrationToken: registrationToken,
		client:            client,
		notify:            make(chan struct{}, 1),
	}, nil
}

func (m *Manager) NotifyInventory() {
	if m == nil {
		return
	}
	select {
	case m.notify <- struct{}{}:
	default:
	}
}

func (m *Manager) Run(ctx context.Context, provider Provider) {
	if m == nil {
		return
	}
	select {
	case <-m.notify:
	default:
	}
	initialDelay := m.cfg.HeartbeatInterval
	if !m.sync(ctx, provider()) {
		initialDelay = m.cfg.RetryInterval
	}
	timer := time.NewTimer(initialDelay)
	defer timer.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-m.notify:
			delay := m.cfg.HeartbeatInterval
			if !m.sync(ctx, provider()) {
				delay = m.cfg.RetryInterval
			}
			resetTimer(timer, delay)
		case <-timer.C:
			snapshot := provider()
			if err := m.ensureRegistered(ctx, snapshot); err != nil {
				log.Printf("level=warning event=central_registration_failed error=%q", err)
				resetTimer(timer, m.cfg.RetryInterval)
				continue
			}
			if err := m.sendHeartbeat(ctx, snapshot); err != nil {
				m.registered = false
				log.Printf("level=warning event=central_heartbeat_failed error=%q", err)
				resetTimer(timer, m.cfg.RetryInterval)
				continue
			}
			resetTimer(timer, m.cfg.HeartbeatInterval)
		}
	}
}

func resetTimer(timer *time.Timer, duration time.Duration) {
	if !timer.Stop() {
		select {
		case <-timer.C:
		default:
		}
	}
	timer.Reset(duration)
}

func (m *Manager) sync(ctx context.Context, snapshot Snapshot) bool {
	if err := m.ensureRegistered(ctx, snapshot); err != nil {
		log.Printf("level=warning event=central_registration_failed error=%q", err)
		return false
	}
	hash, raw, err := inventoryHash(snapshot.Inventory)
	if err != nil {
		log.Printf("level=warning event=central_inventory_encode_failed error=%q", err)
		return false
	}
	if hash != m.lastInventoryHash {
		if err := m.pushInventory(ctx, raw); err != nil {
			m.registered = false
			log.Printf("level=warning event=central_inventory_push_failed error=%q", err)
			return false
		}
		m.lastInventoryHash = hash
		log.Printf("level=info event=central_inventory_pushed collected_at=%s bytes=%d", snapshot.Inventory.CollectedAt.Format(time.RFC3339Nano), len(raw))
	}
	if err := m.sendHeartbeat(ctx, snapshot); err != nil {
		m.registered = false
		log.Printf("level=warning event=central_heartbeat_failed error=%q", err)
		return false
	}
	return true
}

func (m *Manager) ensureRegistered(ctx context.Context, snapshot Snapshot) error {
	if m.registered {
		return nil
	}
	baseURL, primaryIP, err := m.advertisedURL(snapshot.Inventory)
	if err != nil {
		return err
	}
	request := RegistrationRequest{
		ProtocolVersion: protocolVersion,
		Agent:           snapshot.Inventory.Agent,
		Host: RegistrationHost{
			Hostname:          snapshot.Inventory.Host.Hostname,
			FQDN:              snapshot.Inventory.Host.FQDN,
			ProductUUID:       snapshot.Inventory.Host.ProductUUID,
			ProductUUIDLegacy: snapshot.Inventory.Host.Correlation.SMBIOSLegacyByteOrder,
			MachineID:         snapshot.Inventory.Host.MachineID,
			PrimaryIP:         primaryIP,
		},
		BaseURL:                  baseURL,
		AgentToken:               m.localAgentToken,
		RefreshIntervalSeconds:   int64(m.cfg.AgentCollectionInterval.Seconds()),
		HeartbeatIntervalSeconds: int64(m.cfg.HeartbeatInterval.Seconds()),
		CollectedAt:              snapshot.Inventory.CollectedAt,
	}
	var response RegistrationResponse
	if err := m.postJSON(ctx, "/api/v1/agent-registration/register", request, &response); err != nil {
		return err
	}
	m.registered = true
	log.Printf("level=info event=central_registered agent_id=%d vm_id=%v created=%t linked=%t", response.AgentID, response.VMID, response.Created, response.Linked)
	return nil
}

func (m *Manager) sendHeartbeat(ctx context.Context, snapshot Snapshot) error {
	hash, _, _ := inventoryHash(snapshot.Inventory)
	request := HeartbeatRequest{
		ProtocolVersion:  protocolVersion,
		Agent:            snapshot.Inventory.Agent,
		RuntimeStatus:    snapshot.Status.Status,
		CollectionStatus: snapshot.Inventory.Collection.Status,
		CollectedAt:      snapshot.Inventory.CollectedAt,
		InventorySHA256:  hash,
	}
	return m.postJSON(ctx, "/api/v1/agent-registration/heartbeat", request, nil)
}

func (m *Manager) pushInventory(ctx context.Context, raw []byte) error {
	return m.postRaw(ctx, "/api/v1/agent-registration/inventory", raw, nil)
}

func (m *Manager) postJSON(ctx context.Context, path string, input any, output any) error {
	raw, err := json.Marshal(input)
	if err != nil {
		return err
	}
	return m.postRaw(ctx, path, raw, output)
}

func (m *Manager) postRaw(ctx context.Context, path string, raw []byte, output any) error {
	endpoint := strings.TrimRight(m.cfg.URL, "/") + path
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(raw))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+m.registrationToken)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "vm-doc-agent-central/1")
	resp, err := m.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return err
	}
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		return fmt.Errorf("central server returned HTTP %d: %s", resp.StatusCode, truncate(strings.TrimSpace(string(body)), 500))
	}
	if output != nil && len(bytes.TrimSpace(body)) > 0 {
		if err := json.Unmarshal(body, output); err != nil {
			return fmt.Errorf("decode central response: %w", err)
		}
	}
	return nil
}

func (m *Manager) advertisedURL(inventory model.Inventory) (string, string, error) {
	if value := strings.TrimSpace(m.cfg.AdvertiseURL); value != "" {
		u, err := url.Parse(value)
		if err != nil || u.Hostname() == "" {
			return "", "", errors.New("central.advertise_url is invalid")
		}
		return strings.TrimRight(value, "/"), u.Hostname(), nil
	}
	host, port, err := net.SplitHostPort(m.listen)
	if err != nil {
		return "", "", fmt.Errorf("parse listen address for central registration: %w", err)
	}
	if port == "" {
		return "", "", errors.New("listen address does not contain a port")
	}
	primaryIP := primaryInventoryIP(inventory)
	if usableAdvertiseHost(host) {
		primaryIP = strings.Trim(host, "[]")
	}
	if primaryIP == "" {
		return "", "", errors.New("cannot determine an address for central registration; set central.advertise_url")
	}
	return "http://" + net.JoinHostPort(primaryIP, port), primaryIP, nil
}

func primaryInventoryIP(inventory model.Inventory) string {
	preferred := map[string]bool{}
	for _, gateway := range inventory.Network.DefaultGateways {
		if gateway.Family == "ipv4" && gateway.Interface != "" {
			preferred[gateway.Interface] = true
		}
	}
	for _, passPreferred := range []bool{true, false} {
		for _, iface := range inventory.Network.Interfaces {
			if iface.Loopback || (passPreferred && !preferred[iface.Name]) {
				continue
			}
			for _, address := range iface.Addresses {
				if address.Family != "ipv4" || !usableIP(address.Address) {
					continue
				}
				return address.Address
			}
		}
	}
	return ""
}

func usableIP(raw string) bool {
	ip := net.ParseIP(strings.TrimSpace(raw))
	return ip != nil && ip.To4() != nil && !ip.IsLoopback() && !ip.IsUnspecified() && !ip.IsLinkLocalUnicast()
}

func usableAdvertiseHost(host string) bool {
	host = strings.Trim(strings.TrimSpace(host), "[]")
	if host == "" || host == "0.0.0.0" || host == "::" || strings.EqualFold(host, "localhost") {
		return false
	}
	ip := net.ParseIP(host)
	return ip == nil || (!ip.IsLoopback() && !ip.IsUnspecified())
}

func inventoryHash(inventory model.Inventory) (string, []byte, error) {
	raw, err := json.Marshal(inventory)
	if err != nil {
		return "", nil, err
	}
	hash := sha256.Sum256(raw)
	return hex.EncodeToString(hash[:]), raw, nil
}

func readSecret(path string) (string, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	value := strings.TrimSpace(string(raw))
	if len(value) < 24 {
		return "", errors.New("registration token must contain at least 24 characters")
	}
	return value, nil
}

func systemCertPoolWithFile(path string) (*x509.CertPool, error) {
	pool, err := x509.SystemCertPool()
	if err != nil || pool == nil {
		pool = x509.NewCertPool()
	}
	pem, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read central CA file: %w", err)
	}
	if !pool.AppendCertsFromPEM(pem) {
		return nil, errors.New("central CA file does not contain a valid PEM certificate")
	}
	return pool, nil
}

func truncate(value string, max int) string {
	if len(value) > max {
		return value[:max]
	}
	return value
}

func PortFromListen(listen string) int {
	_, port, err := net.SplitHostPort(listen)
	if err != nil {
		return 0
	}
	value, _ := strconv.Atoi(port)
	return value
}
