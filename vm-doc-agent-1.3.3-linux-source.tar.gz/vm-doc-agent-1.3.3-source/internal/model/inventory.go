package model

import "time"

type Inventory struct {
	SchemaVersion      string                    `json:"schema_version"`
	Agent              AgentInfo                 `json:"agent"`
	CollectedAt        time.Time                 `json:"collected_at"`
	Collection         CollectionInfo            `json:"collection"`
	Host               HostInfo                  `json:"host"`
	OS                 OSInfo                    `json:"os"`
	System             SystemInfo                `json:"system"`
	Storage            StorageInfo               `json:"storage"`
	Network            NetworkInfo               `json:"network"`
	Proxy              ProxyInfo                 `json:"proxy"`
	Services           []ServiceInfo             `json:"services"`
	ListeningPorts     []ListeningSocket         `json:"listening_ports"`
	Firewall           FirewallInfo              `json:"firewall"`
	Accounts           AccountsInfo              `json:"accounts"`
	SSSD               SSSDInfo                  `json:"sssd"`
	Integrations       IntegrationsInfo          `json:"integrations"`
	Policies           PoliciesInfo              `json:"policies"`
	Cron               CronInfo                  `json:"cron"`
	NTP                NTPInfo                   `json:"ntp"`
	Truncations        map[string]TruncationInfo `json:"truncations,omitempty"`
	CollectionWarnings []string                  `json:"collection_warnings,omitempty"`
}

type CollectionInfo struct {
	StartedAt   time.Time                  `json:"started_at"`
	CompletedAt time.Time                  `json:"completed_at"`
	DurationMS  int64                      `json:"duration_ms"`
	Status      string                     `json:"status"`
	Collectors  map[string]CollectorStatus `json:"collectors"`
}

type CollectorStatus struct {
	Status       string     `json:"status"`
	StartedAt    *time.Time `json:"started_at,omitempty"`
	CollectedAt  *time.Time `json:"collected_at,omitempty"`
	DurationMS   int64      `json:"duration_ms"`
	WarningCount int        `json:"warning_count,omitempty"`
	Warnings     []string   `json:"warnings,omitempty"`
	Error        string     `json:"error,omitempty"`
	Truncated    bool       `json:"truncated,omitempty"`
}

type TruncationInfo struct {
	Detected int    `json:"detected"`
	Returned int    `json:"returned"`
	Limit    int    `json:"limit"`
	Reason   string `json:"reason"`
}

type AgentInfo struct {
	Name      string `json:"name"`
	Version   string `json:"version"`
	ID        string `json:"id"`
	Commit    string `json:"commit,omitempty"`
	BuildDate string `json:"build_date,omitempty"`
}

type HostInfo struct {
	Hostname          string          `json:"hostname"`
	FQDN              string          `json:"fqdn,omitempty"`
	MachineID         string          `json:"machine_id,omitempty"`
	ProductUUID       string          `json:"product_uuid,omitempty"`
	ProductUUIDSource string          `json:"product_uuid_source,omitempty"`
	ProductName       string          `json:"product_name,omitempty"`
	ProductVendor     string          `json:"product_vendor,omitempty"`
	SerialNumber      string          `json:"serial_number,omitempty"`
	Virtualization    string          `json:"virtualization,omitempty"`
	CorrelationUUID   string          `json:"correlation_uuid,omitempty"`
	Correlation       CorrelationInfo `json:"correlation"`
}

type CorrelationInfo struct {
	Primary               string `json:"primary"`
	DMIProductUUID        string `json:"dmi_product_uuid,omitempty"`
	SMBIOSLegacyByteOrder string `json:"smbios_legacy_byte_order,omitempty"`
	MachineID             string `json:"machine_id,omitempty"`
	AgentID               string `json:"agent_id"`
}

type OSInfo struct {
	Family          string   `json:"family"`
	Name            string   `json:"name,omitempty"`
	PrettyName      string   `json:"pretty_name,omitempty"`
	ID              string   `json:"id,omitempty"`
	IDLike          []string `json:"id_like,omitempty"`
	Version         string   `json:"version,omitempty"`
	VersionID       string   `json:"version_id,omitempty"`
	Kernel          string   `json:"kernel,omitempty"`
	Architecture    string   `json:"architecture,omitempty"`
	DetectionSource string   `json:"detection_source,omitempty"`
	InitSystem      string   `json:"init_system,omitempty"`
}

type SystemInfo struct {
	Timezone       string     `json:"timezone,omitempty"`
	TimezoneSource string     `json:"timezone_source,omitempty"`
	BootTime       *time.Time `json:"boot_time,omitempty"`
	UptimeSeconds  uint64     `json:"uptime_seconds,omitempty"`
}

type StorageInfo struct {
	Partitions []PartitionInfo `json:"partitions"`
}

type PartitionInfo struct {
	Device         string   `json:"device"`
	MountPoint     string   `json:"mount_point"`
	FileSystem     string   `json:"filesystem"`
	MountOptions   []string `json:"mount_options,omitempty"`
	TotalBytes     uint64   `json:"total_bytes"`
	UsedBytes      uint64   `json:"used_bytes"`
	AvailableBytes uint64   `json:"available_bytes"`
	UsagePercent   float64  `json:"usage_percent"`
	ReadOnly       bool     `json:"read_only"`
	Remote         bool     `json:"remote"`
}

type NetworkInfo struct {
	Interfaces      []NetworkInterface `json:"interfaces"`
	Routes          []RouteInfo        `json:"routes,omitempty"`
	DefaultGateways []GatewayInfo      `json:"default_gateways,omitempty"`
	DNSServers      []string           `json:"dns_servers,omitempty"`
	SearchDomains   []string           `json:"search_domains,omitempty"`
	ResolverSource  string             `json:"resolver_source,omitempty"`
}

type NetworkInterface struct {
	Name      string      `json:"name"`
	Index     int         `json:"index"`
	MAC       string      `json:"mac,omitempty"`
	MTU       int         `json:"mtu"`
	Flags     []string    `json:"flags,omitempty"`
	Loopback  bool        `json:"loopback"`
	Addresses []IPAddress `json:"addresses"`
}

type IPAddress struct {
	Address      string `json:"address"`
	CIDR         string `json:"cidr"`
	Family       string `json:"family"`
	PrefixLength int    `json:"prefix_length"`
	Scope        string `json:"scope"`
}

type RouteInfo struct {
	Family      string `json:"family"`
	Destination string `json:"destination"`
	Gateway     string `json:"gateway,omitempty"`
	Interface   string `json:"interface,omitempty"`
	Protocol    string `json:"protocol,omitempty"`
	Source      string `json:"source,omitempty"`
	Metric      int    `json:"metric,omitempty"`
	Default     bool   `json:"default"`
}

type GatewayInfo struct {
	Family    string `json:"family"`
	Address   string `json:"address"`
	Interface string `json:"interface,omitempty"`
	Metric    int    `json:"metric,omitempty"`
}

type ProxyInfo struct {
	Configured bool     `json:"configured"`
	HTTPProxy  string   `json:"http_proxy,omitempty"`
	HTTPSProxy string   `json:"https_proxy,omitempty"`
	FTPProxy   string   `json:"ftp_proxy,omitempty"`
	AllProxy   string   `json:"all_proxy,omitempty"`
	NoProxy    []string `json:"no_proxy,omitempty"`
	Sources    []string `json:"sources,omitempty"`
}

type ServiceInfo struct {
	Name           string   `json:"name"`
	Manager        string   `json:"manager"`
	LoadState      string   `json:"load_state,omitempty"`
	ActiveState    string   `json:"active_state,omitempty"`
	SubState       string   `json:"sub_state,omitempty"`
	EnabledState   string   `json:"enabled_state,omitempty"`
	Runlevels      []string `json:"runlevels,omitempty"`
	Description    string   `json:"description,omitempty"`
	SoftwareName   string   `json:"software_name,omitempty"`
	Version        string   `json:"version,omitempty"`
	PackageName    string   `json:"package_name,omitempty"`
	PackageVersion string   `json:"package_version,omitempty"`
	VersionSource  string   `json:"version_source,omitempty"`
}

type ListeningSocket struct {
	Protocol  string        `json:"protocol"`
	Family    string        `json:"family"`
	Address   string        `json:"address"`
	Port      uint16        `json:"port"`
	Wildcard  bool          `json:"wildcard"`
	Inode     string        `json:"inode,omitempty"`
	Processes []ProcessInfo `json:"processes,omitempty"`
}

type ProcessInfo struct {
	PID        int    `json:"pid"`
	Name       string `json:"name,omitempty"`
	Executable string `json:"executable,omitempty"`
}

type AgentRuntimeStatus struct {
	Status                   string                     `json:"status"`
	Agent                    AgentInfo                  `json:"agent"`
	SchemaVersion            string                     `json:"schema_version"`
	StartedAt                time.Time                  `json:"started_at"`
	UptimeSeconds            uint64                     `json:"uptime_seconds"`
	CollectionInProgress     bool                       `json:"collection_in_progress"`
	LastCollectionAt         *time.Time                 `json:"last_collection_at,omitempty"`
	LastCollectionDurationMS int64                      `json:"last_collection_duration_ms,omitempty"`
	LastCollectionSuccessful bool                       `json:"last_collection_successful"`
	LastError                string                     `json:"last_error,omitempty"`
	NextCollectionAt         *time.Time                 `json:"next_collection_at,omitempty"`
	InventoryFile            string                     `json:"inventory_file"`
	PreviousInventoryFile    string                     `json:"previous_inventory_file"`
	InventorySizeBytes       int64                      `json:"inventory_size_bytes"`
	Collectors               map[string]CollectorStatus `json:"collectors,omitempty"`
}
