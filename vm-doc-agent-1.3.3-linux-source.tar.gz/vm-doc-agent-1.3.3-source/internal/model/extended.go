package model

import "time"

type FirewallInfo struct {
	Detected        bool              `json:"detected"`
	Active          bool              `json:"active"`
	Backends        []string          `json:"backends"`
	DefaultPolicies map[string]string `json:"default_policies,omitempty"`
	Zones           []FirewallZone    `json:"zones,omitempty"`
	Rules           []FirewallRule    `json:"rules,omitempty"`
	ConfigFiles     []string          `json:"config_files,omitempty"`
}

type FirewallZone struct {
	Name       string   `json:"name"`
	Active     bool     `json:"active"`
	Interfaces []string `json:"interfaces,omitempty"`
	Sources    []string `json:"sources,omitempty"`
	Services   []string `json:"services,omitempty"`
	Ports      []string `json:"ports,omitempty"`
	Target     string   `json:"target,omitempty"`
}

type FirewallRule struct {
	Backend string `json:"backend"`
	Family  string `json:"family,omitempty"`
	Table   string `json:"table,omitempty"`
	Chain   string `json:"chain,omitempty"`
	Action  string `json:"action,omitempty"`
	Rule    string `json:"rule"`
}

type AccountsInfo struct {
	LocalUsers     []LocalUserInfo    `json:"local_users"`
	PasswordPolicy PasswordPolicyInfo `json:"password_policy"`
}

type LocalUserInfo struct {
	Username           string     `json:"username"`
	UID                uint64     `json:"uid"`
	GID                uint64     `json:"gid"`
	GECOS              string     `json:"gecos,omitempty"`
	Home               string     `json:"home,omitempty"`
	Shell              string     `json:"shell,omitempty"`
	SystemAccount      bool       `json:"system_account"`
	PasswordStatus     string     `json:"password_status"`
	PasswordLocked     bool       `json:"password_locked"`
	PasswordLastSet    *time.Time `json:"password_last_set,omitempty"`
	PasswordExpiresAt  *time.Time `json:"password_expires_at,omitempty"`
	AccountExpiresAt   *time.Time `json:"account_expires_at,omitempty"`
	MinPasswordAgeDays *int64     `json:"min_password_age_days,omitempty"`
	MaxPasswordAgeDays *int64     `json:"max_password_age_days,omitempty"`
	WarningDays        *int64     `json:"warning_days,omitempty"`
	InactiveDays       *int64     `json:"inactive_days,omitempty"`
}

type PasswordPolicyInfo struct {
	Sources              []string          `json:"sources,omitempty"`
	LoginDefs            map[string]string `json:"login_defs,omitempty"`
	PAMModules           []PAMModuleInfo   `json:"pam_modules,omitempty"`
	Pwquality            map[string]string `json:"pwquality,omitempty"`
	PasswordHistory      map[string]string `json:"password_history,omitempty"`
	ComplexityConfigured bool              `json:"complexity_configured"`
}

type PAMModuleInfo struct {
	File    string            `json:"file"`
	Module  string            `json:"module"`
	Options map[string]string `json:"options,omitempty"`
	Raw     string            `json:"raw,omitempty"`
}

type SSSDInfo struct {
	Installed          bool              `json:"installed"`
	Version            string            `json:"version,omitempty"`
	BinaryPath         string            `json:"binary_path,omitempty"`
	ServiceName        string            `json:"service_name,omitempty"`
	ServiceActive      string            `json:"service_active,omitempty"`
	ServiceEnabled     string            `json:"service_enabled,omitempty"`
	ConfigPresent      bool              `json:"config_present"`
	ConfigPath         string            `json:"config_path,omitempty"`
	ConfigPermissions  string            `json:"config_permissions,omitempty"`
	ConfigOwner        string            `json:"config_owner,omitempty"`
	ConfigValid        *bool             `json:"config_valid,omitempty"`
	ConfigCheckMessage string            `json:"config_check_message,omitempty"`
	Services           []string          `json:"services,omitempty"`
	Domains            []SSSDDomainInfo  `json:"domains,omitempty"`
	SafeGlobalOptions  map[string]string `json:"safe_global_options,omitempty"`
}

type SSSDDomainInfo struct {
	Name        string            `json:"name"`
	SafeOptions map[string]string `json:"safe_options,omitempty"`
}

type IntegrationsInfo struct {
	GLPIAgent    ComponentInfo   `json:"glpi_agent"`
	NodeExporter PrometheusAgent `json:"node_exporter"`
	Auditbeat    BeatInfo        `json:"auditbeat"`
	Filebeat     BeatInfo        `json:"filebeat"`
	Syslog       SyslogInfo      `json:"syslog"`
}

type ComponentInfo struct {
	Installed      bool     `json:"installed"`
	Name           string   `json:"name,omitempty"`
	Version        string   `json:"version,omitempty"`
	BinaryPath     string   `json:"binary_path,omitempty"`
	PackageName    string   `json:"package_name,omitempty"`
	PackageVersion string   `json:"package_version,omitempty"`
	ServiceNames   []string `json:"service_names,omitempty"`
	ServiceActive  string   `json:"service_active,omitempty"`
	ServiceEnabled string   `json:"service_enabled,omitempty"`
	ConfigFiles    []string `json:"config_files,omitempty"`
}

type PrometheusAgent struct {
	ComponentInfo
	ListenAddresses   []string   `json:"listen_addresses,omitempty"`
	MetricsEndpoints  []string   `json:"metrics_endpoints,omitempty"`
	MetricsReachable  bool       `json:"metrics_reachable"`
	MetricsHTTPStatus int        `json:"metrics_http_status,omitempty"`
	MetricSampleCount int        `json:"metric_sample_count,omitempty"`
	MetricsCheckedAt  *time.Time `json:"metrics_checked_at,omitempty"`
	MetricsError      string     `json:"metrics_error,omitempty"`
}

type BeatInfo struct {
	ComponentInfo
	Configured        bool             `json:"configured"`
	ConfigValid       *bool            `json:"config_valid,omitempty"`
	ConfigCheckOutput string           `json:"config_check_output,omitempty"`
	Outputs           []string         `json:"outputs,omitempty"`
	OutputDetails     []BeatOutputInfo `json:"output_details,omitempty"`
	OutputTestOK      *bool            `json:"output_test_ok,omitempty"`
	OutputTestOutput  string           `json:"output_test_output,omitempty"`
	Modules           []string         `json:"modules,omitempty"`
}

type BeatOutputInfo struct {
	Type                   string   `json:"type"`
	Enabled                *bool    `json:"enabled,omitempty"`
	Hosts                  []string `json:"hosts,omitempty"`
	Protocol               string   `json:"protocol,omitempty"`
	Index                  string   `json:"index,omitempty"`
	Pipeline               string   `json:"pipeline,omitempty"`
	Topic                  string   `json:"topic,omitempty"`
	Key                    string   `json:"key,omitempty"`
	Path                   string   `json:"path,omitempty"`
	Filename               string   `json:"filename,omitempty"`
	LoadBalance            *bool    `json:"load_balance,omitempty"`
	Workers                *int     `json:"workers,omitempty"`
	SSLEnabled             *bool    `json:"ssl_enabled,omitempty"`
	SSLVerificationMode    string   `json:"ssl_verification_mode,omitempty"`
	CertificateAuthorities []string `json:"certificate_authorities,omitempty"`
	SourceFile             string   `json:"source_file"`
}

type SyslogInfo struct {
	Installed          bool           `json:"installed"`
	Implementation     string         `json:"implementation,omitempty"`
	Version            string         `json:"version,omitempty"`
	ServiceName        string         `json:"service_name,omitempty"`
	ServiceActive      string         `json:"service_active,omitempty"`
	ServiceEnabled     string         `json:"service_enabled,omitempty"`
	ConfigFiles        []string       `json:"config_files,omitempty"`
	RemoteDestinations []SyslogRemote `json:"remote_destinations,omitempty"`
	ConfiguredRemote   bool           `json:"configured_remote"`
}

type SyslogRemote struct {
	Protocol string `json:"protocol,omitempty"`
	Host     string `json:"host"`
	Port     string `json:"port,omitempty"`
	Source   string `json:"source"`
}

type PoliciesInfo struct {
	SELinux       MandatoryAccessControlInfo `json:"selinux"`
	AppArmor      MandatoryAccessControlInfo `json:"apparmor"`
	AuditRules    []PolicyFileInfo           `json:"audit_rules,omitempty"`
	Sudoers       []PolicyFileInfo           `json:"sudoers,omitempty"`
	Limits        []PolicyFileInfo           `json:"limits,omitempty"`
	Sysctl        []PolicyFileInfo           `json:"sysctl,omitempty"`
	CustomMarkers []PolicyFileInfo           `json:"custom_markers,omitempty"`
}

type MandatoryAccessControlInfo struct {
	Installed bool     `json:"installed"`
	Enabled   bool     `json:"enabled"`
	Mode      string   `json:"mode,omitempty"`
	Policy    string   `json:"policy,omitempty"`
	Profiles  []string `json:"profiles,omitempty"`
}

type PolicyFileInfo struct {
	Path       string     `json:"path"`
	Name       string     `json:"name"`
	Type       string     `json:"type,omitempty"`
	Size       int64      `json:"size"`
	Mode       string     `json:"mode,omitempty"`
	Owner      string     `json:"owner,omitempty"`
	ModifiedAt *time.Time `json:"modified_at,omitempty"`
	SHA256     string     `json:"sha256,omitempty"`
}

type CronInfo struct {
	Entries         []CronEntry      `json:"entries"`
	PeriodicScripts []CronScriptInfo `json:"periodic_scripts"`
	EnvironmentKeys []string         `json:"environment_keys,omitempty"`
}

type CronEntry struct {
	Source   string `json:"source"`
	Owner    string `json:"owner,omitempty"`
	User     string `json:"user,omitempty"`
	Schedule string `json:"schedule"`
	Command  string `json:"command"`
	Special  bool   `json:"special"`
	Line     int    `json:"line"`
}

type CronScriptInfo struct {
	Path       string     `json:"path"`
	Period     string     `json:"period"`
	Executable bool       `json:"executable"`
	Owner      string     `json:"owner,omitempty"`
	ModifiedAt *time.Time `json:"modified_at,omitempty"`
}

type NTPInfo struct {
	Installed       bool              `json:"installed"`
	Implementation  string            `json:"implementation,omitempty"`
	Version         string            `json:"version,omitempty"`
	ServiceName     string            `json:"service_name,omitempty"`
	ServiceActive   string            `json:"service_active,omitempty"`
	ServiceEnabled  string            `json:"service_enabled,omitempty"`
	Synchronized    *bool             `json:"synchronized,omitempty"`
	CurrentSource   string            `json:"current_source,omitempty"`
	Servers         []NTPServerInfo   `json:"servers,omitempty"`
	ConfigFiles     []string          `json:"config_files,omitempty"`
	TrackingSummary map[string]string `json:"tracking_summary,omitempty"`
}

type NTPServerInfo struct {
	Address   string `json:"address"`
	Type      string `json:"type,omitempty"`
	Selected  bool   `json:"selected"`
	Reachable *bool  `json:"reachable,omitempty"`
	Source    string `json:"source,omitempty"`
}
