package collector

import (
	"context"
	"os"
	"os/exec"
	"strings"
	"time"
)

func readTrimmed(path string) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}

func runCommand(name string, arguments ...string) string {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	output, err := exec.CommandContext(ctx, name, arguments...).Output()
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(output))
}

func detectFQDN(hostname string) string {
	if value := runCommand("hostname", "-f"); value != "" && value != "localhost" {
		return value
	}
	return hostname
}

func detectVirtualization() string {
	if value := runCommand("systemd-detect-virt"); value != "" && value != "none" {
		return value
	}
	vendor := strings.ToLower(readTrimmed("/sys/class/dmi/id/sys_vendor"))
	product := strings.ToLower(readTrimmed("/sys/class/dmi/id/product_name"))
	combined := vendor + " " + product
	switch {
	case strings.Contains(combined, "vmware"):
		return "vmware"
	case strings.Contains(combined, "virtualbox"):
		return "virtualbox"
	case strings.Contains(combined, "kvm"), strings.Contains(combined, "qemu"):
		return "kvm"
	case strings.Contains(combined, "microsoft") && strings.Contains(combined, "virtual"):
		return "hyperv"
	case strings.Contains(combined, "xen"):
		return "xen"
	default:
		return "physical-or-unknown"
	}
}

func collectSerialNumber() string {
	if value := readTrimmed("/sys/class/dmi/id/product_serial"); value != "" {
		return value
	}
	return runCommand("dmidecode", "-s", "system-serial-number")
}
