package collector

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"

	"vm-doc-agent/internal/model"
)

func commandOutput(timeout time.Duration, name string, arguments ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	command := exec.CommandContext(ctx, name, arguments...)
	output, err := command.CombinedOutput()
	text := strings.TrimSpace(string(output))
	if ctx.Err() == context.DeadlineExceeded {
		return text, fmt.Errorf("command timed out")
	}
	if err != nil {
		return text, err
	}
	return text, nil
}

func firstExecutable(names ...string) (string, string) {
	for _, name := range names {
		path, err := exec.LookPath(name)
		if err == nil {
			return name, path
		}
	}
	return "", ""
}

func firstExisting(paths ...string) string {
	for _, path := range paths {
		if info, err := os.Stat(path); err == nil && !info.IsDir() {
			return path
		}
	}
	return ""
}

func existingFiles(paths ...string) []string {
	result := make([]string, 0)
	seen := map[string]bool{}
	for _, path := range paths {
		matches, err := filepath.Glob(path)
		if err != nil {
			continue
		}
		for _, match := range matches {
			info, err := os.Stat(match)
			if err == nil && !info.IsDir() && !seen[match] {
				seen[match] = true
				result = append(result, match)
			}
		}
	}
	sort.Strings(result)
	return result
}

func serviceState(services []model.ServiceInfo, candidates ...string) (name, active, enabled string) {
	for _, candidate := range candidates {
		baseCandidate := strings.TrimSuffix(candidate, ".service")
		for _, service := range services {
			baseService := strings.TrimSuffix(service.Name, ".service")
			if baseService == baseCandidate || strings.EqualFold(baseService, baseCandidate) {
				return service.Name, service.ActiveState, service.EnabledState
			}
		}
	}
	return "", "", ""
}

func packageVersion(candidates ...string) (string, string) {
	if _, err := exec.LookPath("dpkg-query"); err == nil {
		for _, candidate := range candidates {
			output, err := commandOutput(3*time.Second, "dpkg-query", "-W", "-f=${Package}\t${Version}", candidate)
			if err == nil {
				parts := strings.SplitN(output, "\t", 2)
				if len(parts) == 2 && strings.TrimSpace(parts[1]) != "" {
					return strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
				}
			}
		}
	}
	if _, err := exec.LookPath("rpm"); err == nil {
		for _, candidate := range candidates {
			output, err := commandOutput(3*time.Second, "rpm", "-q", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}", candidate)
			if err == nil {
				parts := strings.SplitN(output, "\t", 2)
				if len(parts) == 2 && strings.TrimSpace(parts[1]) != "" {
					return strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
				}
			}
		}
	}
	return "", ""
}

func normalizeVersionOutput(value string) string {
	for _, line := range strings.Split(value, "\n") {
		line = strings.TrimSpace(line)
		if line != "" {
			return line
		}
	}
	return ""
}

func fileOwner(info os.FileInfo) string {
	stat, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		return ""
	}
	uid := strconv.FormatUint(uint64(stat.Uid), 10)
	if account, err := user.LookupId(uid); err == nil {
		return account.Username
	}
	return uid
}

func policyFileInfo(path, kind string, hash bool) (model.PolicyFileInfo, bool) {
	info, err := os.Stat(path)
	if err != nil || info.IsDir() {
		return model.PolicyFileInfo{}, false
	}
	modified := info.ModTime().UTC()
	item := model.PolicyFileInfo{
		Path: path, Name: filepath.Base(path), Type: kind, Size: info.Size(),
		Mode: info.Mode().Perm().String(), Owner: fileOwner(info), ModifiedAt: &modified,
	}
	if hash && info.Size() <= 10*1024*1024 {
		data, err := os.ReadFile(path)
		if err == nil {
			sum := sha256.Sum256(data)
			item.SHA256 = hex.EncodeToString(sum[:])
		}
	}
	return item, true
}

func uniqueSorted(values []string) []string {
	seen := map[string]bool{}
	result := make([]string, 0, len(values))
	for _, value := range values {
		value = strings.TrimSpace(value)
		if value != "" && !seen[value] {
			seen[value] = true
			result = append(result, value)
		}
	}
	sort.Strings(result)
	return result
}

func boolPtr(value bool) *bool    { return &value }
func int64Ptr(value int64) *int64 { return &value }
