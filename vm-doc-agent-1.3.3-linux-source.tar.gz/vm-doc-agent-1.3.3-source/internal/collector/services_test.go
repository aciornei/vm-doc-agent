package collector

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"

	"vm-doc-agent/internal/model"
)

func TestParseDebianServiceStatus(t *testing.T) {
	output := " [ + ]  ssh\n [ - ]  cron\n [ ? ]  legacy\n"
	got := parseDebianServiceStatus(output)
	if got["ssh"] != "active" {
		t.Fatalf("ssh status = %q", got["ssh"])
	}
	if got["cron"] != "inactive" {
		t.Fatalf("cron status = %q", got["cron"])
	}
	if got["legacy"] != "unknown" {
		t.Fatalf("legacy status = %q", got["legacy"])
	}
}

func TestServiceVersionRegistry(t *testing.T) {
	postfix, ok := serviceVersionForName("postfix.service")
	if !ok || postfix.Software != "Postfix" || postfix.Package != "postfix" {
		t.Fatalf("unexpected postfix spec: %+v ok=%v", postfix, ok)
	}
	dovecot, ok := serviceVersionForName("dovecot.service")
	if !ok || dovecot.Software != "Dovecot" {
		t.Fatalf("unexpected dovecot spec: %+v ok=%v", dovecot, ok)
	}
	if _, ok := serviceVersionForName("unknown-custom.service"); ok {
		t.Fatal("unknown service should not have a version spec")
	}
}

func TestServiceVersionRegistryAgent(t *testing.T) {
	agent, ok := serviceVersionForName("vm-doc-agent.service")
	if !ok || agent.Software != "VM Documentation Agent" || len(agent.Commands) != 1 {
		t.Fatalf("unexpected agent spec: %+v ok=%v", agent, ok)
	}
	if got := cleanSoftwareVersion(agent.Software, "vm-doc-agent 1.3.3 schema=2.0\n"); got != "1.3.3" {
		t.Fatalf("agent version = %q", got)
	}
}

func TestPackageKey(t *testing.T) {
	cases := map[string]string{
		"postfix":       "postfix",
		"postfix:amd64": "postfix",
		"libfoo:custom": "libfoo:custom",
	}
	for input, expected := range cases {
		if got := packageKey(input); got != expected {
			t.Fatalf("packageKey(%q) = %q, want %q", input, got, expected)
		}
	}
}

func TestGenericServicePackageMetadataWhenAvailable(t *testing.T) {
	if _, err := exec.LookPath("dpkg-query"); err != nil {
		t.Skip("dpkg-query not available")
	}
	service := model.ServiceInfo{Name: "apparmor.service", Manager: "systemd", ActiveState: "active"}
	if serviceUnitPath(service) == "" {
		t.Skip("apparmor systemd unit not available")
	}
	services := []model.ServiceInfo{service}
	enrichServicePackageMetadata(services, "debian")
	if services[0].PackageName == "" || services[0].PackageVersion == "" || services[0].Version == "" {
		t.Fatalf("package metadata missing: %+v", services[0])
	}
	if services[0].VersionSource != "package" {
		t.Fatalf("version source = %q", services[0].VersionSource)
	}
}

func TestEnrichVMDocAgentVersion(t *testing.T) {
	dir := t.TempDir()
	binary := filepath.Join(dir, "vm-doc-agent")
	if err := os.WriteFile(binary, []byte("#!/bin/sh\necho 'vm-doc-agent 1.3.3 schema=2.0'\n"), 0755); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PATH", dir+string(os.PathListSeparator)+os.Getenv("PATH"))
	service := model.ServiceInfo{Name: "vm-doc-agent.service", Manager: "systemd", ActiveState: "active"}
	enrichServiceVersion(&service, "debian")
	if service.Version != "1.3.3" || service.SoftwareName != "VM Documentation Agent" {
		t.Fatalf("unexpected agent metadata: %+v", service)
	}
	if service.VersionSource != "vm-doc-agent -version" {
		t.Fatalf("version source = %q", service.VersionSource)
	}
}
