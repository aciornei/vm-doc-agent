package collector

import (
	"fmt"
	"os"
	"sort"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectFirewall() (model.FirewallInfo, []string) {
	info := model.FirewallInfo{Backends: []string{}, DefaultPolicies: map[string]string{}, Zones: []model.FirewallZone{}, Rules: []model.FirewallRule{}, ConfigFiles: []string{}}
	warnings := []string{}

	if _, path := firstExecutable("nft"); path != "" {
		info.Detected = true
		output, err := commandOutput(5*time.Second, "nft", "-a", "list", "ruleset")
		if err == nil || strings.TrimSpace(output) != "" {
			info.Backends = append(info.Backends, "nftables")
			parseNFTRules(output, &info)
			if err != nil {
				warnings = append(warnings, fmt.Sprintf("firewall: nft list ruleset: %v", err))
			}
		}
	}

	for _, binary := range []struct{ name, family string }{{"iptables-save", "ipv4"}, {"ip6tables-save", "ipv6"}} {
		if _, path := firstExecutable(binary.name); path == "" {
			continue
		}
		info.Detected = true
		output, err := commandOutput(5*time.Second, binary.name)
		if err == nil || strings.TrimSpace(output) != "" {
			backend := "iptables"
			if binary.family == "ipv6" {
				backend = "ip6tables"
			}
			info.Backends = append(info.Backends, backend)
			parseIPTablesSave(output, backend, binary.family, &info)
			if err != nil {
				warnings = append(warnings, fmt.Sprintf("firewall: %s: %v", binary.name, err))
			}
		}
	}

	if _, path := firstExecutable("firewall-cmd"); path != "" {
		info.Detected = true
		state, err := commandOutput(3*time.Second, "firewall-cmd", "--state")
		if err == nil && strings.Contains(strings.ToLower(state), "running") {
			info.Active = true
			info.Backends = append(info.Backends, "firewalld")
			zones, zoneWarnings := collectFirewalldZones()
			info.Zones = zones
			warnings = append(warnings, zoneWarnings...)
		}
	}

	if _, path := firstExecutable("ufw"); path != "" {
		info.Detected = true
		output, err := commandOutput(5*time.Second, "ufw", "status", "verbose")
		if err == nil || strings.TrimSpace(output) != "" {
			info.Backends = append(info.Backends, "ufw")
			parseUFW(output, &info)
			if err != nil {
				warnings = append(warnings, fmt.Sprintf("firewall: ufw status: %v", err))
			}
		}
	}

	if _, err := os.Stat("/etc/sysconfig/SuSEfirewall2"); err == nil {
		info.Detected = true
		info.Backends = append(info.Backends, "susefirewall2")
		info.ConfigFiles = append(info.ConfigFiles, "/etc/sysconfig/SuSEfirewall2")
		parseSUSEFirewall2("/etc/sysconfig/SuSEfirewall2", &info)
	}

	info.ConfigFiles = append(info.ConfigFiles, existingFiles(
		"/etc/nftables.conf", "/etc/nftables/*.nft", "/etc/iptables/rules.v4", "/etc/iptables/rules.v6",
		"/etc/sysconfig/iptables", "/etc/sysconfig/ip6tables", "/etc/firewalld/firewalld.conf", "/etc/firewalld/zones/*.xml",
		"/etc/ufw/ufw.conf", "/etc/ufw/user.rules", "/etc/ufw/user6.rules",
	)...)
	info.Backends = uniqueSorted(info.Backends)
	info.ConfigFiles = uniqueSorted(info.ConfigFiles)
	if len(info.Rules) > 0 || len(info.Zones) > 0 {
		info.Active = true
	}
	for _, policy := range info.DefaultPolicies {
		if value := strings.ToUpper(strings.TrimSpace(policy)); value != "" && value != "ACCEPT" {
			info.Active = true
		}
	}
	sort.Slice(info.Rules, func(i, j int) bool {
		if info.Rules[i].Backend != info.Rules[j].Backend {
			return info.Rules[i].Backend < info.Rules[j].Backend
		}
		if info.Rules[i].Table != info.Rules[j].Table {
			return info.Rules[i].Table < info.Rules[j].Table
		}
		if info.Rules[i].Chain != info.Rules[j].Chain {
			return info.Rules[i].Chain < info.Rules[j].Chain
		}
		return info.Rules[i].Rule < info.Rules[j].Rule
	})
	return info, warnings
}

func parseIPTablesSave(output, backend, family string, info *model.FirewallInfo) {
	table := ""
	for _, raw := range strings.Split(output, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") || line == "COMMIT" {
			continue
		}
		if strings.HasPrefix(line, "*") {
			table = strings.TrimPrefix(line, "*")
			continue
		}
		if strings.HasPrefix(line, ":") {
			fields := strings.Fields(strings.TrimPrefix(line, ":"))
			if len(fields) >= 2 && fields[1] != "-" {
				info.DefaultPolicies[backend+":"+table+":"+fields[0]] = fields[1]
			}
			continue
		}
		if strings.HasPrefix(line, "-A ") {
			fields := strings.Fields(line)
			chain := ""
			action := ""
			if len(fields) > 1 {
				chain = fields[1]
			}
			for i := 2; i+1 < len(fields); i++ {
				if fields[i] == "-j" {
					action = fields[i+1]
					break
				}
			}
			info.Rules = append(info.Rules, model.FirewallRule{Backend: backend, Family: family, Table: table, Chain: chain, Action: action, Rule: sanitizeConfigLine(line)})
		}
	}
}

func parseNFTRules(output string, info *model.FirewallInfo) {
	family, table, chain := "", "", ""
	for _, raw := range strings.Split(output, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) >= 3 && fields[0] == "table" {
			family, table = fields[1], strings.TrimSuffix(fields[2], "{")
			continue
		}
		if len(fields) >= 2 && fields[0] == "chain" {
			chain = strings.TrimSuffix(fields[1], "{")
			continue
		}
		if strings.HasPrefix(line, "policy ") {
			policy := strings.TrimSuffix(strings.TrimSpace(strings.TrimPrefix(line, "policy ")), ";")
			info.DefaultPolicies["nftables:"+family+":"+table+":"+chain] = policy
			continue
		}
		if line == "}" || strings.HasSuffix(line, "{") || strings.HasPrefix(line, "type ") || strings.HasPrefix(line, "hook ") {
			continue
		}
		if chain != "" {
			action := ""
			for _, candidate := range []string{"accept", "drop", "reject", "return", "jump", "goto"} {
				if strings.Contains(" "+line+" ", " "+candidate+" ") {
					action = candidate
					break
				}
			}
			info.Rules = append(info.Rules, model.FirewallRule{Backend: "nftables", Family: family, Table: table, Chain: chain, Action: action, Rule: sanitizeConfigLine(line)})
		}
	}
}

func collectFirewalldZones() ([]model.FirewallZone, []string) {
	warnings := []string{}
	activeOutput, _ := commandOutput(3*time.Second, "firewall-cmd", "--get-active-zones")
	activeZones := map[string]bool{}
	current := ""
	for _, raw := range strings.Split(activeOutput, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" {
			continue
		}
		if !strings.Contains(line, ":") {
			current = line
			activeZones[current] = true
		}
	}
	zonesOutput, err := commandOutput(3*time.Second, "firewall-cmd", "--get-zones")
	if err != nil {
		return []model.FirewallZone{}, []string{fmt.Sprintf("firewall: firewalld zones: %v", err)}
	}
	zones := []model.FirewallZone{}
	for _, zoneName := range strings.Fields(zonesOutput) {
		output, err := commandOutput(3*time.Second, "firewall-cmd", "--zone", zoneName, "--list-all")
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("firewall: firewalld zone %s: %v", zoneName, err))
			continue
		}
		zone := model.FirewallZone{Name: zoneName, Active: activeZones[zoneName]}
		for _, raw := range strings.Split(output, "\n") {
			parts := strings.SplitN(strings.TrimSpace(raw), ":", 2)
			if len(parts) != 2 {
				continue
			}
			value := strings.TrimSpace(parts[1])
			switch strings.TrimSpace(parts[0]) {
			case "target":
				zone.Target = value
			case "interfaces":
				zone.Interfaces = strings.Fields(value)
			case "sources":
				zone.Sources = strings.Fields(value)
			case "services":
				zone.Services = strings.Fields(value)
			case "ports":
				zone.Ports = strings.Fields(value)
			}
		}
		zones = append(zones, zone)
	}
	return zones, warnings
}

func parseUFW(output string, info *model.FirewallInfo) {
	active := false
	for _, raw := range strings.Split(output, "\n") {
		line := strings.TrimSpace(raw)
		lower := strings.ToLower(line)
		if strings.HasPrefix(lower, "status:") {
			active = strings.Contains(lower, "active") && !strings.Contains(lower, "inactive")
			continue
		}
		if strings.HasPrefix(lower, "default:") {
			info.DefaultPolicies["ufw"] = strings.TrimSpace(strings.TrimPrefix(line, "Default:"))
			continue
		}
		if line == "" || strings.HasPrefix(line, "To ") || strings.HasPrefix(line, "--") {
			continue
		}
		if strings.Contains(line, "ALLOW") || strings.Contains(line, "DENY") || strings.Contains(line, "REJECT") || strings.Contains(line, "LIMIT") {
			info.Rules = append(info.Rules, model.FirewallRule{Backend: "ufw", Rule: sanitizeConfigLine(line)})
		}
	}
	if active {
		info.Active = true
	}
}

func parseSUSEFirewall2(path string, info *model.FirewallInfo) {
	data, err := os.ReadFile(path)
	if err != nil {
		return
	}
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") || !strings.HasPrefix(line, "FW_") {
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		value := strings.Trim(strings.TrimSpace(parts[1]), "\"")
		if value == "" {
			continue
		}
		key := parts[0]
		if strings.Contains(key, "SERVICES") || strings.Contains(key, "ALLOW") || strings.Contains(key, "ROUTE") || strings.Contains(key, "DEV") {
			info.Rules = append(info.Rules, model.FirewallRule{Backend: "susefirewall2", Rule: key + "=" + value})
		}
	}
}
