package collector

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"vm-doc-agent/internal/model"
)

var cronEnvPattern = regexp.MustCompile(`^([A-Za-z_][A-Za-z0-9_]*)\s*=`)
var cronSecretPattern = regexp.MustCompile(`(?i)(password|passwd|pwd|token|secret|api[_-]?key|access[_-]?key|private[_-]?key)=([^\s]+)`)
var cronURLCredentialsPattern = regexp.MustCompile(`([a-zA-Z][a-zA-Z0-9+.-]*://[^:/\s]+:)([^@/\s]+)(@)`)

func collectCron() (model.CronInfo, []string) {
	info := model.CronInfo{Entries: []model.CronEntry{}, PeriodicScripts: []model.CronScriptInfo{}, EnvironmentKeys: []string{}}
	warnings := []string{}

	systemFiles := existingFiles("/etc/crontab", "/etc/cron.d/*")
	for _, path := range systemFiles {
		entries, envKeys, fileWarnings := parseCronFile(path, "", true)
		info.Entries = append(info.Entries, entries...)
		info.EnvironmentKeys = append(info.EnvironmentKeys, envKeys...)
		warnings = append(warnings, fileWarnings...)
	}

	spoolPatterns := []string{"/var/spool/cron/crontabs/*", "/var/spool/cron/*", "/var/cron/tabs/*"}
	seen := map[string]bool{}
	for _, pattern := range spoolPatterns {
		for _, path := range existingFiles(pattern) {
			if seen[path] {
				continue
			}
			seen[path] = true
			owner := filepath.Base(path)
			if fileInfo, err := os.Stat(path); err == nil {
				if value := fileOwner(fileInfo); value != "" {
					owner = value
				}
			}
			entries, envKeys, fileWarnings := parseCronFile(path, owner, false)
			info.Entries = append(info.Entries, entries...)
			info.EnvironmentKeys = append(info.EnvironmentKeys, envKeys...)
			warnings = append(warnings, fileWarnings...)
		}
	}

	periods := []struct{ path, name string }{
		{"/etc/cron.hourly", "hourly"}, {"/etc/cron.daily", "daily"}, {"/etc/cron.weekly", "weekly"}, {"/etc/cron.monthly", "monthly"},
	}
	for _, period := range periods {
		entries, periodWarnings := collectCronDirectory(period.path, period.name)
		info.PeriodicScripts = append(info.PeriodicScripts, entries...)
		warnings = append(warnings, periodWarnings...)
	}
	info.EnvironmentKeys = uniqueSorted(info.EnvironmentKeys)
	sort.Slice(info.Entries, func(i, j int) bool {
		if info.Entries[i].Source != info.Entries[j].Source {
			return info.Entries[i].Source < info.Entries[j].Source
		}
		return info.Entries[i].Line < info.Entries[j].Line
	})
	sort.Slice(info.PeriodicScripts, func(i, j int) bool { return info.PeriodicScripts[i].Path < info.PeriodicScripts[j].Path })
	return info, warnings
}

func parseCronFile(path, owner string, systemFile bool) ([]model.CronEntry, []string, []string) {
	file, err := os.Open(path)
	if err != nil {
		return nil, nil, []string{fmt.Sprintf("cron: read %s: %v", path, err)}
	}
	defer file.Close()
	entries := []model.CronEntry{}
	envKeys := []string{}
	warnings := []string{}
	scanner := bufio.NewScanner(file)
	lineNumber := 0
	for scanner.Scan() {
		lineNumber++
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if match := cronEnvPattern.FindStringSubmatch(line); len(match) == 2 {
			envKeys = append(envKeys, match[1])
			continue
		}
		fields := strings.Fields(line)
		if len(fields) == 0 {
			continue
		}
		entry := model.CronEntry{Source: path, Owner: owner, Line: lineNumber}
		if strings.HasPrefix(fields[0], "@") {
			entry.Special = true
			entry.Schedule = fields[0]
			commandStart := 1
			if systemFile {
				if len(fields) < 3 {
					warnings = append(warnings, fmt.Sprintf("cron: malformed special entry %s:%d", path, lineNumber))
					continue
				}
				entry.User = fields[1]
				commandStart = 2
			} else if len(fields) < 2 {
				warnings = append(warnings, fmt.Sprintf("cron: malformed special entry %s:%d", path, lineNumber))
				continue
			}
			entry.Command = sanitizeCronCommand(strings.Join(fields[commandStart:], " "))
			entries = append(entries, entry)
			continue
		}
		minimum := 6
		if systemFile {
			minimum = 7
		}
		if len(fields) < minimum {
			warnings = append(warnings, fmt.Sprintf("cron: malformed entry %s:%d", path, lineNumber))
			continue
		}
		entry.Schedule = strings.Join(fields[:5], " ")
		commandStart := 5
		if systemFile {
			entry.User = fields[5]
			commandStart = 6
		}
		entry.Command = sanitizeCronCommand(strings.Join(fields[commandStart:], " "))
		entries = append(entries, entry)
	}
	if err := scanner.Err(); err != nil {
		warnings = append(warnings, fmt.Sprintf("cron: scan %s: %v", path, err))
	}
	return entries, envKeys, warnings
}

func collectCronDirectory(path, period string) ([]model.CronScriptInfo, []string) {
	entries, err := os.ReadDir(path)
	if err != nil {
		if os.IsNotExist(err) {
			return []model.CronScriptInfo{}, nil
		}
		return []model.CronScriptInfo{}, []string{fmt.Sprintf("cron: read directory %s: %v", path, err)}
	}
	result := []model.CronScriptInfo{}
	for _, entry := range entries {
		if entry.IsDir() || strings.HasPrefix(entry.Name(), ".") || strings.HasSuffix(entry.Name(), "~") {
			continue
		}
		fullPath := filepath.Join(path, entry.Name())
		fileInfo, err := entry.Info()
		if err != nil {
			continue
		}
		modified := fileInfo.ModTime().UTC()
		result = append(result, model.CronScriptInfo{Path: fullPath, Period: period, Executable: fileInfo.Mode().Perm()&0111 != 0, Owner: fileOwner(fileInfo), ModifiedAt: &modified})
	}
	return result, nil
}

func sanitizeCronCommand(command string) string {
	command = cronSecretPattern.ReplaceAllString(command, "$1=<redacted>")
	command = cronURLCredentialsPattern.ReplaceAllString(command, "$1<redacted>$3")
	return truncateString(strings.TrimSpace(command), 4096)
}
