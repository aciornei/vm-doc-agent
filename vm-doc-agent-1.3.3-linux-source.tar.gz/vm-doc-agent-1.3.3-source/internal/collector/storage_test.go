package collector

import "testing"

func TestUnescapeMountField(t *testing.T) {
	got := unescapeMountField(`/srv/My\040Data\134Archive`)
	want := "/srv/My Data\\Archive"
	if got != want {
		t.Fatalf("unescapeMountField() = %q, want %q", got, want)
	}
}

func TestIsRemoteMount(t *testing.T) {
	cases := []struct {
		device     string
		filesystem string
		want       bool
	}{
		{"server:/export", "nfs", true},
		{"//server/share", "cifs", true},
		{"/dev/sda1", "ext4", false},
	}
	for _, test := range cases {
		if got := isRemoteMount(test.device, test.filesystem); got != test.want {
			t.Errorf("isRemoteMount(%q, %q) = %v, want %v", test.device, test.filesystem, got, test.want)
		}
	}
}
