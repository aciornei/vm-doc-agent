package collector

import (
	"bufio"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectSystem() (model.SystemInfo, []string) {
	info := model.SystemInfo{}
	warnings := []string{}
	info.Timezone, info.TimezoneSource = detectTimezone()
	if boot, uptime, ok := readBootTime(); ok {
		info.BootTime = &boot
		info.UptimeSeconds = uptime
	} else {
		warnings = append(warnings, "system: could not determine boot time from /proc/stat or /proc/uptime")
	}
	return info, warnings
}

func detectTimezone() (string, string) {
	if data, err := os.ReadFile("/etc/timezone"); err == nil {
		if value := strings.TrimSpace(string(data)); value != "" {
			return value, "/etc/timezone"
		}
	}
	if target, err := filepath.EvalSymlinks("/etc/localtime"); err == nil {
		if index := strings.Index(target, "/zoneinfo/"); index >= 0 {
			return strings.TrimPrefix(target[index:], "/zoneinfo/"), "/etc/localtime"
		}
	}
	name, _ := time.Now().Zone()
	return name, "runtime"
}

func readBootTime() (time.Time, uint64, bool) {
	if file, err := os.Open("/proc/stat"); err == nil {
		defer file.Close()
		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			fields := strings.Fields(scanner.Text())
			if len(fields) == 2 && fields[0] == "btime" {
				seconds, err := strconv.ParseInt(fields[1], 10, 64)
				if err == nil {
					boot := time.Unix(seconds, 0).UTC()
					uptime := uint64(time.Since(boot).Seconds())
					return boot, uptime, true
				}
			}
		}
	}
	if data, err := os.ReadFile("/proc/uptime"); err == nil {
		fields := strings.Fields(string(data))
		if len(fields) > 0 {
			seconds, err := strconv.ParseFloat(fields[0], 64)
			if err == nil && seconds >= 0 {
				boot := time.Now().UTC().Add(-time.Duration(seconds * float64(time.Second)))
				return boot, uint64(seconds), true
			}
		}
	}
	return time.Time{}, 0, false
}
