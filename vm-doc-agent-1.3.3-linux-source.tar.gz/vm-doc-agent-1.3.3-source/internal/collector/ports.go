package collector

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	"vm-doc-agent/internal/model"
)

type procSocket struct {
	protocol string
	family   string
	address  string
	port     uint16
	inode    string
}

func collectListeningPorts() ([]model.ListeningSocket, []string) {
	sources := []struct {
		path     string
		protocol string
		family   string
	}{
		{"/proc/net/tcp", "tcp", "ipv4"},
		{"/proc/net/tcp6", "tcp", "ipv6"},
		{"/proc/net/udp", "udp", "ipv4"},
		{"/proc/net/udp6", "udp", "ipv6"},
	}

	sockets := make([]procSocket, 0)
	warnings := make([]string, 0)
	for _, source := range sources {
		parsed, err := readProcSockets(source.path, source.protocol, source.family)
		if err != nil {
			if !os.IsNotExist(err) {
				warnings = append(warnings, fmt.Sprintf("listening_ports: read %s: %v", source.path, err))
			}
			continue
		}
		sockets = append(sockets, parsed...)
	}

	inodes := make(map[string]struct{})
	for _, socket := range sockets {
		if socket.inode != "" && socket.inode != "0" {
			inodes[socket.inode] = struct{}{}
		}
	}
	processesByInode := mapSocketProcesses(inodes)

	result := make([]model.ListeningSocket, 0, len(sockets))
	for _, socket := range sockets {
		ip := net.ParseIP(socket.address)
		wildcard := ip != nil && ip.IsUnspecified()
		result = append(result, model.ListeningSocket{
			Protocol:  socket.protocol,
			Family:    socket.family,
			Address:   socket.address,
			Port:      socket.port,
			Wildcard:  wildcard,
			Inode:     socket.inode,
			Processes: processesByInode[socket.inode],
		})
	}

	sort.Slice(result, func(i, j int) bool {
		if result[i].Port != result[j].Port {
			return result[i].Port < result[j].Port
		}
		if result[i].Protocol != result[j].Protocol {
			return result[i].Protocol < result[j].Protocol
		}
		if result[i].Family != result[j].Family {
			return result[i].Family < result[j].Family
		}
		return result[i].Address < result[j].Address
	})
	return result, warnings
}

func readProcSockets(path, protocol, family string) ([]procSocket, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	result := make([]procSocket, 0)
	scanner := bufio.NewScanner(file)
	firstLine := true
	for scanner.Scan() {
		if firstLine {
			firstLine = false
			continue
		}
		fields := strings.Fields(scanner.Text())
		if len(fields) < 10 {
			continue
		}
		state := fields[3]
		if protocol == "tcp" && state != "0A" {
			continue
		}
		if protocol == "udp" && state != "07" {
			continue
		}
		address, port, err := parseProcEndpoint(fields[1], family)
		if err != nil || port == 0 {
			continue
		}
		result = append(result, procSocket{
			protocol: protocol,
			family:   family,
			address:  address,
			port:     port,
			inode:    fields[9],
		})
	}
	if err := scanner.Err(); err != nil {
		return result, err
	}
	return result, nil
}

func parseProcEndpoint(value, family string) (string, uint16, error) {
	separator := strings.LastIndex(value, ":")
	if separator < 0 {
		return "", 0, fmt.Errorf("invalid endpoint %q", value)
	}
	addressHex := value[:separator]
	portValue, err := strconv.ParseUint(value[separator+1:], 16, 16)
	if err != nil {
		return "", 0, fmt.Errorf("invalid port in %q: %w", value, err)
	}
	address, err := parseProcIPAddress(addressHex, family)
	if err != nil {
		return "", 0, err
	}
	return address, uint16(portValue), nil
}

func parseProcIPAddress(value, family string) (string, error) {
	bytes, err := hex.DecodeString(value)
	if err != nil {
		return "", fmt.Errorf("decode address %q: %w", value, err)
	}
	switch family {
	case "ipv4":
		if len(bytes) != net.IPv4len {
			return "", fmt.Errorf("invalid IPv4 length %d", len(bytes))
		}
		reverseBytes(bytes)
		return net.IP(bytes).String(), nil
	case "ipv6":
		if len(bytes) != net.IPv6len {
			return "", fmt.Errorf("invalid IPv6 length %d", len(bytes))
		}
		for offset := 0; offset < len(bytes); offset += 4 {
			reverseBytes(bytes[offset : offset+4])
		}
		return net.IP(bytes).String(), nil
	default:
		return "", fmt.Errorf("unknown address family %q", family)
	}
}

func reverseBytes(values []byte) {
	for left, right := 0, len(values)-1; left < right; left, right = left+1, right-1 {
		values[left], values[right] = values[right], values[left]
	}
}

func mapSocketProcesses(wanted map[string]struct{}) map[string][]model.ProcessInfo {
	result := make(map[string][]model.ProcessInfo)
	if len(wanted) == 0 {
		return result
	}
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return result
	}
	seen := make(map[string]map[int]struct{})
	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil || pid <= 0 {
			continue
		}
		fdDirectory := filepath.Join("/proc", entry.Name(), "fd")
		fds, err := os.ReadDir(fdDirectory)
		if err != nil {
			continue
		}
		matched := make(map[string]struct{})
		for _, fd := range fds {
			target, err := os.Readlink(filepath.Join(fdDirectory, fd.Name()))
			if err != nil || !strings.HasPrefix(target, "socket:[") || !strings.HasSuffix(target, "]") {
				continue
			}
			inode := strings.TrimSuffix(strings.TrimPrefix(target, "socket:["), "]")
			if _, needed := wanted[inode]; needed {
				matched[inode] = struct{}{}
			}
		}
		if len(matched) == 0 {
			continue
		}
		process := model.ProcessInfo{
			PID:        pid,
			Name:       readTrimmed(filepath.Join("/proc", entry.Name(), "comm")),
			Executable: readProcessExecutable(entry.Name()),
		}
		for inode := range matched {
			if seen[inode] == nil {
				seen[inode] = make(map[int]struct{})
			}
			if _, exists := seen[inode][pid]; exists {
				continue
			}
			seen[inode][pid] = struct{}{}
			result[inode] = append(result[inode], process)
		}
	}
	for inode := range result {
		sort.Slice(result[inode], func(i, j int) bool { return result[inode][i].PID < result[inode][j].PID })
	}
	return result
}

func readProcessExecutable(pid string) string {
	value, err := os.Readlink(filepath.Join("/proc", pid, "exe"))
	if err != nil {
		return ""
	}
	return strings.TrimSuffix(value, " (deleted)")
}
