package collector

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

type shadowEntry struct {
	password string
	last     *int64
	min      *int64
	max      *int64
	warn     *int64
	inactive *int64
	expire   *int64
}

func collectAccounts() (model.AccountsInfo, []string) {
	policy, policyWarnings := collectPasswordPolicy()
	shadow, shadowWarnings := readShadowEntries("/etc/shadow")
	users, userWarnings := readLocalUsers("/etc/passwd", shadow, policy)
	warnings := append(policyWarnings, shadowWarnings...)
	warnings = append(warnings, userWarnings...)
	return model.AccountsInfo{LocalUsers: users, PasswordPolicy: policy}, warnings
}

func readLocalUsers(path string, shadow map[string]shadowEntry, policy model.PasswordPolicyInfo) ([]model.LocalUserInfo, []string) {
	file, err := os.Open(path)
	if err != nil {
		return []model.LocalUserInfo{}, []string{fmt.Sprintf("accounts: read %s: %v", path, err)}
	}
	defer file.Close()

	uidMin := uint64(1000)
	if value := policy.LoginDefs["UID_MIN"]; value != "" {
		if parsed, err := strconv.ParseUint(value, 10, 64); err == nil {
			uidMin = parsed
		}
	}

	result := make([]model.LocalUserInfo, 0)
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		fields := strings.Split(line, ":")
		if len(fields) < 7 {
			continue
		}
		uid, errUID := strconv.ParseUint(fields[2], 10, 64)
		gid, errGID := strconv.ParseUint(fields[3], 10, 64)
		if errUID != nil || errGID != nil {
			continue
		}
		item := model.LocalUserInfo{
			Username: fields[0], UID: uid, GID: gid, GECOS: fields[4], Home: fields[5], Shell: fields[6],
			SystemAccount:  uid < uidMin,
			PasswordStatus: "unknown",
		}
		if entry, ok := shadow[fields[0]]; ok {
			item.PasswordStatus, item.PasswordLocked = passwordStatus(entry.password)
			item.MinPasswordAgeDays = entry.min
			item.MaxPasswordAgeDays = entry.max
			item.WarningDays = entry.warn
			item.InactiveDays = entry.inactive
			if entry.last != nil && *entry.last > 0 {
				value := daysSinceEpoch(*entry.last)
				item.PasswordLastSet = &value
				if entry.max != nil && *entry.max >= 0 && *entry.max < 99999 {
					expires := daysSinceEpoch(*entry.last + *entry.max)
					item.PasswordExpiresAt = &expires
				}
			}
			if entry.expire != nil && *entry.expire > 0 {
				value := daysSinceEpoch(*entry.expire)
				item.AccountExpiresAt = &value
			}
		}
		result = append(result, item)
	}
	warnings := []string{}
	if err := scanner.Err(); err != nil {
		warnings = append(warnings, fmt.Sprintf("accounts: scan %s: %v", path, err))
	}
	return result, warnings
}

func readShadowEntries(path string) (map[string]shadowEntry, []string) {
	result := map[string]shadowEntry{}
	file, err := os.Open(path)
	if err != nil {
		return result, []string{fmt.Sprintf("accounts: cannot read password aging metadata from %s: %v", path, err)}
	}
	defer file.Close()
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		fields := strings.Split(scanner.Text(), ":")
		if len(fields) < 2 {
			continue
		}
		entry := shadowEntry{password: fields[1]}
		if len(fields) > 2 {
			entry.last = parseOptionalInt(fields[2])
		}
		if len(fields) > 3 {
			entry.min = parseOptionalInt(fields[3])
		}
		if len(fields) > 4 {
			entry.max = parseOptionalInt(fields[4])
		}
		if len(fields) > 5 {
			entry.warn = parseOptionalInt(fields[5])
		}
		if len(fields) > 6 {
			entry.inactive = parseOptionalInt(fields[6])
		}
		if len(fields) > 7 {
			entry.expire = parseOptionalInt(fields[7])
		}
		result[fields[0]] = entry
	}
	warnings := []string{}
	if err := scanner.Err(); err != nil {
		warnings = append(warnings, fmt.Sprintf("accounts: scan %s: %v", path, err))
	}
	return result, warnings
}

func parseOptionalInt(value string) *int64 {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil
	}
	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil {
		return nil
	}
	return int64Ptr(parsed)
}

func passwordStatus(value string) (string, bool) {
	switch {
	case value == "":
		return "empty", false
	case value == "!" || value == "!!" || value == "*" || value == "!*" || strings.HasPrefix(value, "!") || strings.HasPrefix(value, "*"):
		return "locked", true
	case strings.HasPrefix(value, "$"):
		return "password_set", false
	default:
		return "password_set_or_external", false
	}
}

func daysSinceEpoch(days int64) time.Time {
	return time.Unix(days*86400, 0).UTC()
}

func collectPasswordPolicy() (model.PasswordPolicyInfo, []string) {
	policy := model.PasswordPolicyInfo{
		LoginDefs: map[string]string{}, Pwquality: map[string]string{}, PasswordHistory: map[string]string{},
	}
	warnings := []string{}
	if data, err := os.ReadFile("/etc/login.defs"); err == nil {
		policy.Sources = append(policy.Sources, "/etc/login.defs")
		wanted := map[string]bool{"UID_MIN": true, "PASS_MAX_DAYS": true, "PASS_MIN_DAYS": true, "PASS_WARN_AGE": true, "PASS_MIN_LEN": true, "ENCRYPT_METHOD": true, "SHA_CRYPT_MIN_ROUNDS": true, "SHA_CRYPT_MAX_ROUNDS": true}
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(strings.SplitN(line, "#", 2)[0])
			fields := strings.Fields(line)
			if len(fields) >= 2 && wanted[fields[0]] {
				policy.LoginDefs[fields[0]] = fields[1]
			}
		}
	}

	for _, path := range existingFiles("/etc/security/pwquality.conf", "/etc/security/pwquality.conf.d/*.conf", "/etc/security/pam_pwcheck.conf") {
		policy.Sources = append(policy.Sources, path)
		data, err := os.ReadFile(path)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("password policy: read %s: %v", path, err))
			continue
		}
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(strings.SplitN(line, "#", 2)[0])
			if line == "" {
				continue
			}
			parts := strings.SplitN(line, "=", 2)
			if len(parts) == 2 {
				policy.Pwquality[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
			}
		}
	}

	pamPaths := existingFiles(
		"/etc/pam.d/common-password", "/etc/pam.d/system-auth", "/etc/pam.d/password-auth",
		"/etc/pam.d/common-auth-pc", "/etc/pam.d/common-password-pc", "/etc/pam.d/passwd",
	)
	for _, path := range pamPaths {
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		for _, raw := range strings.Split(string(data), "\n") {
			line := strings.TrimSpace(raw)
			if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "password") {
				continue
			}
			fields := strings.Fields(line)
			moduleIndex := -1
			for i, field := range fields {
				base := filepath.Base(field)
				if strings.HasPrefix(base, "pam_") && strings.Contains(base, ".so") {
					moduleIndex = i
					break
				}
			}
			if moduleIndex < 0 {
				continue
			}
			module := filepath.Base(fields[moduleIndex])
			if module != "pam_pwquality.so" && module != "pam_cracklib.so" && module != "pam_pwhistory.so" && module != "pam_unix.so" && module != "pam_pwcheck.so" {
				continue
			}
			options := map[string]string{}
			for _, option := range fields[moduleIndex+1:] {
				parts := strings.SplitN(option, "=", 2)
				if len(parts) == 2 {
					options[parts[0]] = parts[1]
				} else {
					options[option] = "true"
				}
			}
			policy.PAMModules = append(policy.PAMModules, model.PAMModuleInfo{File: path, Module: module, Options: options, Raw: sanitizeConfigLine(line)})
			policy.Sources = append(policy.Sources, path)
			if module == "pam_pwhistory.so" || options["remember"] != "" {
				for key, value := range options {
					policy.PasswordHistory[key] = value
				}
			}
		}
	}
	policy.Sources = uniqueSorted(policy.Sources)
	policy.ComplexityConfigured = len(policy.Pwquality) > 0
	for _, module := range policy.PAMModules {
		if module.Module == "pam_pwquality.so" || module.Module == "pam_cracklib.so" || module.Module == "pam_pwcheck.so" {
			policy.ComplexityConfigured = true
		}
	}
	return policy, warnings
}

func sanitizeConfigLine(line string) string {
	secretAssignment := regexp.MustCompile(`(?i)(password|passwd|secret|token|authtok|api[_-]?key|access[_-]?key)(\s*[:=]\s*)("[^"]*"|'[^']*'|[^\s,;]+)`)
	return secretAssignment.ReplaceAllString(line, `${1}${2}<redacted>`)
}
