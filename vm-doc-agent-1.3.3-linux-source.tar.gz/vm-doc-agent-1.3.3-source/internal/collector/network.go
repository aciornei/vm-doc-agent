package collector

import (
	"bufio"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectNetwork() (model.NetworkInfo, []string) {
	interfaces, interfaceWarnings := collectNetworkInterfaces()
	routes, routeWarnings := collectRoutes()
	dnsServers, searchDomains, resolverSource, resolverWarnings := collectResolver()
	warnings := append(interfaceWarnings, routeWarnings...)
	warnings = append(warnings, resolverWarnings...)
	return model.NetworkInfo{
		Interfaces:      interfaces,
		Routes:          routes,
		DefaultGateways: gatewaysFromRoutes(routes),
		DNSServers:      dnsServers,
		SearchDomains:   searchDomains,
		ResolverSource:  resolverSource,
	}, warnings
}

func collectNetworkInterfaces() ([]model.NetworkInterface, []string) {
	interfaces, err := net.Interfaces()
	if err != nil {
		return []model.NetworkInterface{}, []string{fmt.Sprintf("network: list interfaces: %v", err)}
	}

	result := make([]model.NetworkInterface, 0, len(interfaces))
	warnings := make([]string, 0)
	for _, networkInterface := range interfaces {
		addresses, err := networkInterface.Addrs()
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("network: addresses for %s: %v", networkInterface.Name, err))
			addresses = []net.Addr{}
		}

		parsedAddresses := make([]model.IPAddress, 0, len(addresses))
		for _, address := range addresses {
			ipAddress, ok := parseInterfaceAddress(address.String())
			if !ok {
				warnings = append(warnings, fmt.Sprintf("network: cannot parse address %q on %s", address.String(), networkInterface.Name))
				continue
			}
			parsedAddresses = append(parsedAddresses, ipAddress)
		}
		sort.Slice(parsedAddresses, func(i, j int) bool {
			if parsedAddresses[i].Family == parsedAddresses[j].Family {
				return parsedAddresses[i].Address < parsedAddresses[j].Address
			}
			return parsedAddresses[i].Family < parsedAddresses[j].Family
		})

		result = append(result, model.NetworkInterface{
			Name: networkInterface.Name, Index: networkInterface.Index,
			MAC: networkInterface.HardwareAddr.String(), MTU: networkInterface.MTU,
			Flags:     interfaceFlags(networkInterface.Flags),
			Loopback:  networkInterface.Flags&net.FlagLoopback != 0,
			Addresses: parsedAddresses,
		})
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].Index == result[j].Index {
			return result[i].Name < result[j].Name
		}
		return result[i].Index < result[j].Index
	})
	return result, warnings
}

func collectRoutes() ([]model.RouteInfo, []string) {
	warnings := []string{}
	if _, err := exec.LookPath("ip"); err == nil {
		routes := []model.RouteInfo{}
		for _, item := range []struct{ family, flag string }{{"ipv4", "-4"}, {"ipv6", "-6"}} {
			output, commandErr := commandOutput(6*time.Second, "ip", "-o", item.flag, "route", "show", "table", "main")
			if commandErr != nil && strings.TrimSpace(output) == "" {
				warnings = append(warnings, fmt.Sprintf("network: ip %s route: %v", item.flag, commandErr))
				continue
			}
			routes = append(routes, parseIPRoutes(output, item.family)...)
		}
		if len(routes) > 0 {
			sortRoutes(routes)
			return routes, warnings
		}
	}

	routes, fallbackWarnings := collectProcIPv4Routes("/proc/net/route")
	warnings = append(warnings, fallbackWarnings...)
	sortRoutes(routes)
	return routes, warnings
}

func parseIPRoutes(output, family string) []model.RouteInfo {
	result := []model.RouteInfo{}
	for _, raw := range strings.Split(output, "\n") {
		fields := strings.Fields(strings.TrimSpace(raw))
		if len(fields) == 0 {
			continue
		}
		route := model.RouteInfo{Family: family, Destination: fields[0]}
		if fields[0] == "default" {
			route.Default = true
			if family == "ipv4" {
				route.Destination = "0.0.0.0/0"
			} else {
				route.Destination = "::/0"
			}
		}
		for index := 1; index < len(fields); index++ {
			switch fields[index] {
			case "via":
				if index+1 < len(fields) {
					route.Gateway = fields[index+1]
					index++
				}
			case "dev":
				if index+1 < len(fields) {
					route.Interface = fields[index+1]
					index++
				}
			case "proto":
				if index+1 < len(fields) {
					route.Protocol = fields[index+1]
					index++
				}
			case "src", "prefsrc":
				if index+1 < len(fields) {
					route.Source = fields[index+1]
					index++
				}
			case "metric":
				if index+1 < len(fields) {
					route.Metric, _ = strconv.Atoi(fields[index+1])
					index++
				}
			}
		}
		result = append(result, route)
	}
	return result
}

func collectProcIPv4Routes(path string) ([]model.RouteInfo, []string) {
	file, err := os.Open(path)
	if err != nil {
		return []model.RouteInfo{}, []string{fmt.Sprintf("network: read %s: %v", path, err)}
	}
	defer file.Close()
	result := []model.RouteInfo{}
	scanner := bufio.NewScanner(file)
	first := true
	for scanner.Scan() {
		if first {
			first = false
			continue
		}
		fields := strings.Fields(scanner.Text())
		if len(fields) < 8 {
			continue
		}
		destination, errDest := decodeProcIPv4(fields[1])
		gateway, errGateway := decodeProcIPv4(fields[2])
		mask, errMask := decodeProcIPv4(fields[7])
		if errDest != nil || errGateway != nil || errMask != nil {
			continue
		}
		prefix, _ := net.IPMask(net.ParseIP(mask).To4()).Size()
		destinationCIDR := fmt.Sprintf("%s/%d", destination, prefix)
		metric, _ := strconv.Atoi(fields[6])
		route := model.RouteInfo{
			Family: "ipv4", Destination: destinationCIDR, Gateway: gateway,
			Interface: fields[0], Metric: metric, Protocol: "kernel",
			Default: destination == "0.0.0.0" && prefix == 0,
		}
		if gateway == "0.0.0.0" {
			route.Gateway = ""
		}
		result = append(result, route)
	}
	warnings := []string{}
	if err := scanner.Err(); err != nil {
		warnings = append(warnings, fmt.Sprintf("network: scan %s: %v", path, err))
	}
	return result, warnings
}

func decodeProcIPv4(value string) (string, error) {
	bytes, err := hex.DecodeString(value)
	if err != nil || len(bytes) != 4 {
		return "", fmt.Errorf("invalid IPv4 route hex %q", value)
	}
	return net.IPv4(bytes[3], bytes[2], bytes[1], bytes[0]).String(), nil
}

func sortRoutes(routes []model.RouteInfo) {
	sort.Slice(routes, func(i, j int) bool {
		if routes[i].Default != routes[j].Default {
			return routes[i].Default
		}
		if routes[i].Family != routes[j].Family {
			return routes[i].Family < routes[j].Family
		}
		if routes[i].Destination != routes[j].Destination {
			return routes[i].Destination < routes[j].Destination
		}
		if routes[i].Metric != routes[j].Metric {
			return routes[i].Metric < routes[j].Metric
		}
		return routes[i].Interface < routes[j].Interface
	})
}

func gatewaysFromRoutes(routes []model.RouteInfo) []model.GatewayInfo {
	result := []model.GatewayInfo{}
	seen := map[string]bool{}
	for _, route := range routes {
		if !route.Default || route.Gateway == "" {
			continue
		}
		key := route.Family + "|" + route.Gateway + "|" + route.Interface + "|" + strconv.Itoa(route.Metric)
		if seen[key] {
			continue
		}
		seen[key] = true
		result = append(result, model.GatewayInfo{Family: route.Family, Address: route.Gateway, Interface: route.Interface, Metric: route.Metric})
	}
	return result
}

func collectResolver() ([]string, []string, string, []string) {
	path := "/etc/resolv.conf"
	data, err := os.ReadFile(path)
	if err != nil {
		return []string{}, []string{}, path, []string{fmt.Sprintf("network: read %s: %v", path, err)}
	}
	source := path
	if resolved, err := os.Readlink(path); err == nil {
		source = path + " -> " + resolved
	}
	servers := []string{}
	search := []string{}
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(strings.SplitN(raw, "#", 2)[0])
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		switch strings.ToLower(fields[0]) {
		case "nameserver":
			if net.ParseIP(fields[1]) != nil {
				servers = append(servers, fields[1])
			}
		case "search":
			search = append(search, fields[1:]...)
		case "domain":
			search = append(search, fields[1])
		}
	}
	return uniqueSorted(servers), uniqueSorted(search), source, nil
}

func parseInterfaceAddress(value string) (model.IPAddress, bool) {
	ip, network, err := net.ParseCIDR(value)
	if err != nil {
		return model.IPAddress{}, false
	}
	prefix, _ := network.Mask.Size()
	family := "ipv6"
	if ip.To4() != nil {
		family = "ipv4"
		ip = ip.To4()
	}
	return model.IPAddress{Address: ip.String(), CIDR: fmt.Sprintf("%s/%d", ip.String(), prefix), Family: family, PrefixLength: prefix, Scope: ipScope(ip)}, true
}

func ipScope(ip net.IP) string {
	switch {
	case ip.IsUnspecified():
		return "unspecified"
	case ip.IsLoopback():
		return "loopback"
	case ip.IsLinkLocalUnicast(), ip.IsLinkLocalMulticast():
		return "link"
	case ip.IsPrivate():
		return "private"
	case ip.IsMulticast():
		return "multicast"
	default:
		return "global"
	}
}

func interfaceFlags(flags net.Flags) []string {
	values := make([]string, 0, 7)
	known := []struct {
		flag net.Flags
		name string
	}{
		{net.FlagUp, "up"}, {net.FlagBroadcast, "broadcast"}, {net.FlagLoopback, "loopback"},
		{net.FlagPointToPoint, "point_to_point"}, {net.FlagMulticast, "multicast"}, {net.FlagRunning, "running"},
	}
	for _, item := range known {
		if flags&item.flag != 0 {
			values = append(values, item.name)
		}
	}
	if text := strings.TrimSpace(flags.String()); text != "" && len(values) == 0 {
		values = append(values, text)
	}
	return values
}
