package collector

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"vm-doc-agent/internal/model"
)

func collectServices(initSystem, osFamily string) ([]model.ServiceInfo, []string) {
	switch initSystem {
	case "systemd":
		services, warnings := collectSystemdServices(osFamily)
		if len(services) > 0 {
			return services, warnings
		}
		fallback, fallbackWarnings := collectSysVServices(osFamily)
		return fallback, append(warnings, fallbackWarnings...)
	case "sysv":
		return collectSysVServices(osFamily)
	default:
		if _, err := exec.LookPath("systemctl"); err == nil {
			services, warnings := collectSystemdServices(osFamily)
			if len(services) > 0 {
				return services, warnings
			}
		}
		return collectSysVServices(osFamily)
	}
}

func collectSystemdServices(osFamily string) ([]model.ServiceInfo, []string) {
	warnings := make([]string, 0)
	unitsOutput, err := runCommandCombined(12*time.Second, "systemctl", "list-units", "--type=service", "--all", "--no-legend", "--no-pager", "--plain")
	if err != nil {
		unitsOutput, err = runCommandCombined(12*time.Second, "systemctl", "list-units", "--type=service", "--all", "--no-legend", "--no-pager")
	}
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("services: systemctl list-units: %v", err))
		return []model.ServiceInfo{}, warnings
	}

	enabledStates := make(map[string]string)
	unitFilesOutput, unitFilesErr := runCommandCombined(12*time.Second, "systemctl", "list-unit-files", "--type=service", "--no-legend", "--no-pager")
	if unitFilesErr != nil {
		warnings = append(warnings, fmt.Sprintf("services: systemctl list-unit-files: %v", unitFilesErr))
	} else {
		for _, line := range strings.Split(unitFilesOutput, "\n") {
			fields := strings.Fields(strings.TrimSpace(line))
			if len(fields) >= 2 {
				enabledStates[fields[0]] = fields[1]
			}
		}
	}

	services := make([]model.ServiceInfo, 0)
	for _, line := range strings.Split(unitsOutput, "\n") {
		line = strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(line), "●"))
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		name := fields[0]
		if !strings.HasSuffix(name, ".service") {
			continue
		}
		description := ""
		if len(fields) > 4 {
			description = strings.Join(fields[4:], " ")
		}
		services = append(services, model.ServiceInfo{
			Name:         name,
			Manager:      "systemd",
			LoadState:    fields[1],
			ActiveState:  fields[2],
			SubState:     fields[3],
			EnabledState: enabledStates[name],
			Description:  description,
		})
	}

	// list-units does not always include inactive unit files that have never been loaded.
	known := make(map[string]struct{}, len(services))
	for _, service := range services {
		known[service.Name] = struct{}{}
	}
	for name, enabledState := range enabledStates {
		if !strings.HasSuffix(name, ".service") {
			continue
		}
		if _, exists := known[name]; exists {
			continue
		}
		services = append(services, model.ServiceInfo{
			Name:         name,
			Manager:      "systemd",
			LoadState:    "not-loaded",
			ActiveState:  "inactive",
			SubState:     "unknown",
			EnabledState: enabledState,
		})
	}

	enrichServiceVersions(services, osFamily)
	sort.Slice(services, func(i, j int) bool { return services[i].Name < services[j].Name })
	return services, warnings
}

func collectSysVServices(osFamily string) ([]model.ServiceInfo, []string) {
	entries, err := os.ReadDir("/etc/init.d")
	if err != nil {
		return []model.ServiceInfo{}, []string{fmt.Sprintf("services: read /etc/init.d: %v", err)}
	}

	statusMap := make(map[string]string)
	warnings := make([]string, 0)
	if osFamily == "debian" {
		if output, statusErr := runCommandCombined(20*time.Second, "service", "--status-all"); statusErr == nil || strings.TrimSpace(output) != "" {
			statusMap = parseDebianServiceStatus(output)
		} else if !errorsCommandNotFound(statusErr) {
			warnings = append(warnings, fmt.Sprintf("services: service --status-all: %v", statusErr))
		}
	}

	services := make([]model.ServiceInfo, 0)
	for _, entry := range entries {
		name := entry.Name()
		if ignoreInitScript(name) {
			continue
		}
		path := filepath.Join("/etc/init.d", name)
		info, statErr := os.Stat(path)
		if statErr != nil || info.IsDir() || info.Mode()&0111 == 0 {
			continue
		}

		runlevels := enabledRunlevels(name)
		enabledState := "disabled"
		if len(runlevels) > 0 {
			enabledState = "enabled"
		}
		activeState := statusMap[name]
		if activeState == "" {
			activeState = inferPIDFileStatus(name)
		}
		services = append(services, model.ServiceInfo{
			Name:         name,
			Manager:      "sysv",
			LoadState:    "loaded",
			ActiveState:  activeState,
			EnabledState: enabledState,
			Runlevels:    runlevels,
			Description:  initScriptDescription(path),
		})
	}
	enrichServiceVersions(services, osFamily)
	sort.Slice(services, func(i, j int) bool { return services[i].Name < services[j].Name })
	return services, warnings
}

type serviceVersionSpec struct {
	Software string
	Package  string
	Commands [][]string
}

func enrichServiceVersions(services []model.ServiceInfo, osFamily string) {
	if len(services) == 0 {
		return
	}

	// First populate generic package metadata from the package that owns the
	// service unit/init script. This gives us a useful version for ordinary
	// services too, not only for products from the explicit detector list.
	enrichServicePackageMetadata(services, osFamily)

	// Product-specific version detection can involve external commands. Run only
	// the known detectors, concurrently, so a slow utility cannot serialize the
	// complete service collector.
	indices := make(chan int)
	var wg sync.WaitGroup
	workers := 4
	if len(services) < workers {
		workers = len(services)
	}
	for worker := 0; worker < workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for index := range indices {
				enrichServiceVersion(&services[index], osFamily)
			}
		}()
	}
	for index := range services {
		if _, ok := serviceVersionForName(services[index].Name); ok {
			indices <- index
		}
	}
	close(indices)
	wg.Wait()
}

func enrichServicePackageMetadata(services []model.ServiceInfo, osFamily string) {
	type unitRef struct {
		index int
		path  string
	}
	refs := make([]unitRef, 0, len(services))
	paths := make([]string, 0, len(services))
	for index := range services {
		path := serviceUnitPath(services[index])
		if path == "" {
			continue
		}
		refs = append(refs, unitRef{index: index, path: path})
		paths = append(paths, path)
	}
	if len(refs) == 0 {
		return
	}

	if strings.EqualFold(osFamily, "debian") {
		owners := debianPackageOwners(paths)
		packages := make([]string, 0, len(owners))
		seen := make(map[string]struct{}, len(owners))
		for _, pkg := range owners {
			key := packageKey(pkg)
			if key == "" {
				continue
			}
			if _, exists := seen[key]; exists {
				continue
			}
			seen[key] = struct{}{}
			packages = append(packages, pkg)
		}
		versions := debianPackageVersions(packages)
		for _, ref := range refs {
			pkg := owners[ref.path]
			if pkg == "" {
				continue
			}
			service := &services[ref.index]
			service.PackageName = packageKey(pkg)
			service.PackageVersion = versions[packageKey(pkg)]
			if service.Version == "" && service.PackageVersion != "" {
				service.Version = service.PackageVersion
				service.VersionSource = "package"
			}
		}
		return
	}

	// RPM families do not have an equally convenient multi-file owner query with
	// a stable path-to-result mapping, so query only services that matter in the
	// operational view (active/enabled) plus explicitly known products.
	indices := make(chan unitRef)
	var wg sync.WaitGroup
	workers := 6
	if len(refs) < workers {
		workers = len(refs)
	}
	for worker := 0; worker < workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for ref := range indices {
				service := &services[ref.index]
				if !serviceNeedsGenericPackage(*service) {
					continue
				}
				pkg, version := rpmPackageOwner(ref.path)
				if pkg == "" {
					continue
				}
				service.PackageName = pkg
				service.PackageVersion = version
				if service.Version == "" && version != "" {
					service.Version = version
					service.VersionSource = "package"
				}
			}
		}()
	}
	for _, ref := range refs {
		indices <- ref
	}
	close(indices)
	wg.Wait()
}

func serviceNeedsGenericPackage(service model.ServiceInfo) bool {
	if _, known := serviceVersionForName(service.Name); known {
		return true
	}
	return strings.EqualFold(service.ActiveState, "active") || strings.EqualFold(service.EnabledState, "enabled")
}

func serviceUnitPath(service model.ServiceInfo) string {
	if service.Manager == "sysv" {
		path := filepath.Join("/etc/init.d", service.Name)
		if info, err := os.Stat(path); err == nil && !info.IsDir() {
			return resolvedPath(path)
		}
		return ""
	}

	name := strings.TrimSpace(service.Name)
	if name == "" {
		return ""
	}
	candidates := []string{name}
	if at := strings.Index(name, "@"); at >= 0 && strings.HasSuffix(name, ".service") {
		candidates = append(candidates, name[:at]+"@.service")
	}
	dirs := []string{"/etc/systemd/system", "/run/systemd/system", "/usr/local/lib/systemd/system", "/usr/lib/systemd/system", "/lib/systemd/system"}
	for _, candidate := range candidates {
		for _, dir := range dirs {
			path := filepath.Join(dir, candidate)
			if info, err := os.Stat(path); err == nil && !info.IsDir() {
				return resolvedPath(path)
			}
		}
	}
	return ""
}

func resolvedPath(path string) string {
	resolved, err := filepath.EvalSymlinks(path)
	if err == nil && strings.TrimSpace(resolved) != "" {
		return resolved
	}
	return path
}

func debianPackageOwners(paths []string) map[string]string {
	result := make(map[string]string)
	for start := 0; start < len(paths); start += 100 {
		end := start + 100
		if end > len(paths) {
			end = len(paths)
		}
		args := append([]string{"-S"}, paths[start:end]...)
		output, _ := runCommandCombined(5*time.Second, "dpkg-query", args...)
		for _, line := range strings.Split(output, "\n") {
			line = strings.TrimSpace(line)
			separator := strings.LastIndex(line, ": ")
			if separator <= 0 {
				continue
			}
			pkg := strings.TrimSpace(line[:separator])
			path := strings.TrimSpace(line[separator+2:])
			if pkg != "" && path != "" {
				result[path] = pkg
			}
		}
	}
	return result
}

func debianPackageVersions(packages []string) map[string]string {
	result := make(map[string]string)
	for start := 0; start < len(packages); start += 100 {
		end := start + 100
		if end > len(packages) {
			end = len(packages)
		}
		args := []string{"-W", "-f=${binary:Package}\t${Version}\n"}
		args = append(args, packages[start:end]...)
		output, _ := runCommandCombined(5*time.Second, "dpkg-query", args...)
		for _, line := range strings.Split(output, "\n") {
			fields := strings.SplitN(strings.TrimSpace(line), "\t", 2)
			if len(fields) != 2 {
				continue
			}
			key := packageKey(fields[0])
			if key != "" {
				result[key] = strings.TrimSpace(fields[1])
			}
		}
	}
	return result
}

func packageKey(name string) string {
	name = strings.TrimSpace(name)
	if colon := strings.LastIndex(name, ":"); colon > 0 {
		suffix := name[colon+1:]
		if suffix == "amd64" || suffix == "i386" || suffix == "arm64" || suffix == "armhf" || suffix == "ppc64el" || suffix == "s390x" {
			name = name[:colon]
		}
	}
	return name
}

func rpmPackageOwner(path string) (string, string) {
	output, err := runCommandCombined(2*time.Second, "rpm", "-qf", "--qf", "%{NAME}\t%{VERSION}-%{RELEASE}", path)
	if err != nil && strings.TrimSpace(output) == "" {
		return "", ""
	}
	fields := strings.SplitN(strings.TrimSpace(output), "\t", 2)
	if len(fields) != 2 || strings.Contains(strings.ToLower(fields[0]), "not owned") {
		return "", ""
	}
	return strings.TrimSpace(fields[0]), strings.TrimSpace(fields[1])
}

func enrichServiceVersion(service *model.ServiceInfo, osFamily string) {
	spec, ok := serviceVersionForName(service.Name)
	if !ok {
		return
	}
	service.SoftwareName = spec.Software
	service.PackageName = spec.Package
	for _, command := range spec.Commands {
		if len(command) == 0 {
			continue
		}
		binary := resolveServiceExecutable(command[0])
		if binary == "" {
			continue
		}
		output, err := runCommandCombined(2*time.Second, binary, command[1:]...)
		if err != nil && strings.TrimSpace(output) == "" {
			continue
		}
		if version := cleanSoftwareVersion(spec.Software, output); version != "" {
			service.Version = version
			service.VersionSource = strings.Join(command, " ")
			break
		}
	}
	if spec.Package != "" {
		service.PackageVersion = detectPackageVersion(osFamily, spec.Package)
	}
	if service.Version == "" && service.PackageVersion != "" {
		service.Version = service.PackageVersion
		service.VersionSource = "package"
	}
}

func resolveServiceExecutable(name string) string {
	if path, err := exec.LookPath(name); err == nil {
		return path
	}
	for _, dir := range []string{"/usr/local/sbin", "/usr/local/bin", "/usr/sbin", "/usr/bin", "/sbin", "/bin"} {
		path := filepath.Join(dir, name)
		if info, err := os.Stat(path); err == nil && info.Mode().IsRegular() && info.Mode()&0111 != 0 {
			return path
		}
	}
	return ""
}

func serviceVersionForName(serviceName string) (serviceVersionSpec, bool) {
	name := strings.ToLower(strings.TrimSpace(strings.TrimSuffix(serviceName, ".service")))
	// Unitățile instanțiate păstrează prefixul produsului, de ex. postgresql@16-main.
	if at := strings.Index(name, "@"); at >= 0 {
		name = name[:at]
	}
	switch {
	case name == "vm-doc-agent":
		return serviceVersionSpec{Software: "VM Documentation Agent", Commands: [][]string{{"vm-doc-agent", "-version"}}}, true
	case name == "postfix" || strings.HasPrefix(name, "postfix-"):
		return serviceVersionSpec{Software: "Postfix", Package: "postfix", Commands: [][]string{{"postconf", "-h", "mail_version"}}}, true
	case name == "dovecot" || strings.HasPrefix(name, "dovecot-"):
		return serviceVersionSpec{Software: "Dovecot", Package: "dovecot-core", Commands: [][]string{{"dovecot", "--version"}}}, true
	case name == "nginx":
		return serviceVersionSpec{Software: "Nginx", Package: "nginx", Commands: [][]string{{"nginx", "-v"}}}, true
	case name == "apache2":
		return serviceVersionSpec{Software: "Apache HTTP Server", Package: "apache2", Commands: [][]string{{"apache2", "-v"}}}, true
	case name == "httpd":
		return serviceVersionSpec{Software: "Apache HTTP Server", Package: "httpd", Commands: [][]string{{"httpd", "-v"}}}, true
	case name == "redis" || name == "redis-server":
		return serviceVersionSpec{Software: "Redis", Package: "redis-server", Commands: [][]string{{"redis-server", "--version"}}}, true
	case name == "mariadb":
		return serviceVersionSpec{Software: "MariaDB", Package: "mariadb-server", Commands: [][]string{{"mariadbd", "--version"}, {"mariadb", "--version"}}}, true
	case name == "mysql" || name == "mysqld":
		return serviceVersionSpec{Software: "MySQL/MariaDB", Package: "mysql-server", Commands: [][]string{{"mysqld", "--version"}, {"mysql", "--version"}}}, true
	case name == "postgresql":
		return serviceVersionSpec{Software: "PostgreSQL", Package: "postgresql", Commands: [][]string{{"psql", "--version"}, {"postgres", "--version"}}}, true
	case name == "haproxy":
		return serviceVersionSpec{Software: "HAProxy", Package: "haproxy", Commands: [][]string{{"haproxy", "-v"}}}, true
	case name == "prometheus":
		return serviceVersionSpec{Software: "Prometheus", Package: "prometheus", Commands: [][]string{{"prometheus", "--version"}}}, true
	case name == "node_exporter" || name == "node-exporter":
		return serviceVersionSpec{Software: "Node Exporter", Package: "prometheus-node-exporter", Commands: [][]string{{"node_exporter", "--version"}}}, true
	case name == "filebeat":
		return serviceVersionSpec{Software: "Filebeat", Package: "filebeat", Commands: [][]string{{"filebeat", "version"}}}, true
	case name == "auditbeat":
		return serviceVersionSpec{Software: "Auditbeat", Package: "auditbeat", Commands: [][]string{{"auditbeat", "version"}}}, true
	case name == "sssd":
		return serviceVersionSpec{Software: "SSSD", Package: "sssd", Commands: [][]string{{"sssd", "--version"}}}, true
	case name == "rsyslog":
		return serviceVersionSpec{Software: "rsyslog", Package: "rsyslog", Commands: [][]string{{"rsyslogd", "-v"}}}, true
	case name == "chrony" || name == "chronyd":
		return serviceVersionSpec{Software: "chrony", Package: "chrony", Commands: [][]string{{"chronyd", "--version"}}}, true
	case name == "docker":
		return serviceVersionSpec{Software: "Docker Engine", Package: "docker-ce", Commands: [][]string{{"docker", "--version"}}}, true
	case name == "containerd":
		return serviceVersionSpec{Software: "containerd", Package: "containerd", Commands: [][]string{{"containerd", "--version"}}}, true
	case name == "rabbitmq-server":
		return serviceVersionSpec{Software: "RabbitMQ", Package: "rabbitmq-server", Commands: nil}, true
	case name == "sogo":
		return serviceVersionSpec{Software: "SOGo", Package: "sogo", Commands: nil}, true
	case strings.HasPrefix(name, "php") && strings.Contains(name, "fpm"):
		binary := strings.ReplaceAll(name, "-fpm", "") + "-fpm"
		return serviceVersionSpec{Software: "PHP-FPM", Package: name, Commands: [][]string{{binary, "-v"}, {"php", "-v"}}}, true
	default:
		return serviceVersionSpec{}, false
	}
}

func cleanSoftwareVersion(software, output string) string {
	line := strings.TrimSpace(output)
	if line == "" {
		return ""
	}
	if index := strings.IndexByte(line, '\n'); index >= 0 {
		line = strings.TrimSpace(line[:index])
	}
	lower := strings.ToLower(line)
	switch software {
	case "VM Documentation Agent":
		fields := strings.Fields(line)
		if len(fields) >= 2 && strings.EqualFold(fields[0], "vm-doc-agent") {
			return strings.TrimSpace(fields[1])
		}
	case "Postfix", "Dovecot":
		fields := strings.Fields(line)
		if software == "Dovecot" && len(fields) > 1 && strings.EqualFold(fields[0], "dovecot") {
			return strings.TrimSpace(fields[1])
		}
		return strings.TrimSpace(line)
	case "Nginx":
		if index := strings.Index(lower, "nginx/"); index >= 0 {
			return strings.TrimSpace(line[index+len("nginx/"):])
		}
	case "PostgreSQL":
		fields := strings.Fields(line)
		if len(fields) > 0 {
			return fields[len(fields)-1]
		}
	}
	// Păstrăm ieșirea scurtă pentru produsele cu format propriu; este mai utilă
	// decât pierderea versiunii și rămâne distinctă de package_version.
	if len(line) > 160 {
		line = line[:160]
	}
	return strings.TrimSpace(line)
}

func detectPackageVersion(osFamily, packageName string) string {
	packageName = strings.TrimSpace(packageName)
	if packageName == "" {
		return ""
	}
	if strings.EqualFold(osFamily, "debian") {
		output, err := runCommandCombined(3*time.Second, "dpkg-query", "-W", "-f=${Version}", packageName)
		if err == nil || strings.TrimSpace(output) != "" {
			return strings.TrimSpace(output)
		}
	}
	output, err := runCommandCombined(3*time.Second, "rpm", "-q", "--qf", "%{VERSION}-%{RELEASE}", packageName)
	if err == nil || strings.TrimSpace(output) != "" {
		value := strings.TrimSpace(output)
		if !strings.Contains(strings.ToLower(value), "not installed") && !strings.Contains(strings.ToLower(value), "not owned") {
			return value
		}
	}
	return ""
}

func parseDebianServiceStatus(output string) map[string]string {
	result := make(map[string]string)
	for _, line := range strings.Split(output, "\n") {
		line = strings.TrimSpace(line)
		if len(line) < 5 || line[0] != '[' {
			continue
		}
		closing := strings.Index(line, "]")
		if closing < 0 {
			continue
		}
		marker := strings.TrimSpace(line[1:closing])
		name := strings.TrimSpace(line[closing+1:])
		if name == "" {
			continue
		}
		switch marker {
		case "+":
			result[name] = "active"
		case "-":
			result[name] = "inactive"
		default:
			result[name] = "unknown"
		}
	}
	return result
}

func enabledRunlevels(serviceName string) []string {
	levels := make([]string, 0, 6)
	seen := make(map[string]struct{})
	bases := []string{"/etc", "/etc/init.d", "/etc/rc.d"}
	for level := 0; level <= 6; level++ {
		levelText := strconv.Itoa(level)
		for _, base := range bases {
			directory := filepath.Join(base, "rc"+levelText+".d")
			entries, err := os.ReadDir(directory)
			if err != nil {
				continue
			}
			for _, entry := range entries {
				name := entry.Name()
				if len(name) < 4 || name[0] != 'S' || name[1] < '0' || name[1] > '9' || name[2] < '0' || name[2] > '9' {
					continue
				}
				if name[3:] == serviceName || symlinkTargetBase(filepath.Join(directory, name)) == serviceName {
					if _, exists := seen[levelText]; !exists {
						seen[levelText] = struct{}{}
						levels = append(levels, levelText)
					}
				}
			}
		}
	}
	sort.Strings(levels)
	return levels
}

func symlinkTargetBase(path string) string {
	target, err := os.Readlink(path)
	if err != nil {
		return ""
	}
	return filepath.Base(target)
}

func inferPIDFileStatus(serviceName string) string {
	candidates := []string{
		filepath.Join("/run", serviceName+".pid"),
		filepath.Join("/var/run", serviceName+".pid"),
		filepath.Join("/run", serviceName, serviceName+".pid"),
		filepath.Join("/var/run", serviceName, serviceName+".pid"),
	}
	for _, candidate := range candidates {
		data, err := os.ReadFile(candidate)
		if err != nil {
			continue
		}
		pidText := strings.Fields(string(data))
		if len(pidText) == 0 {
			continue
		}
		pid, err := strconv.Atoi(pidText[0])
		if err != nil || pid <= 0 {
			continue
		}
		if _, err := os.Stat(filepath.Join("/proc", strconv.Itoa(pid))); err == nil {
			return "active"
		}
		return "inactive"
	}
	return "unknown"
}

func initScriptDescription(path string) string {
	file, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer file.Close()
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(scanner.Text()), "#"))
		if strings.HasPrefix(line, "Short-Description:") {
			return strings.TrimSpace(strings.TrimPrefix(line, "Short-Description:"))
		}
	}
	return ""
}

func ignoreInitScript(name string) bool {
	if strings.HasPrefix(name, ".") || strings.HasSuffix(name, "~") {
		return true
	}
	switch name {
	case "README", "README.md", "boot", "boot.local", "functions", "halt", "rc", "rcS", "reboot", "single", "skeleton":
		return true
	default:
		return false
	}
}

func runCommandCombined(timeout time.Duration, name string, arguments ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	command := exec.CommandContext(ctx, name, arguments...)
	command.Env = append(os.Environ(), "LANG=C", "LC_ALL=C")
	output, err := command.CombinedOutput()
	text := strings.TrimSpace(string(output))
	if ctx.Err() == context.DeadlineExceeded {
		return text, fmt.Errorf("command timed out after %s", timeout)
	}
	return text, err
}

func errorsCommandNotFound(err error) bool {
	if err == nil {
		return false
	}
	var executableError *exec.Error
	return errors.As(err, &executableError)
}
