package collector

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"vm-doc-agent/internal/model"
)

func writeTestFile(t *testing.T, dir, name, content string) string {
	t.Helper()
	path := filepath.Join(dir, name)
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	return path
}

func TestReadLocalUsersAndShadow(t *testing.T) {
	dir := t.TempDir()
	passwd := writeTestFile(t, dir, "passwd", "root:x:0:0:root:/root:/bin/bash\nandrei:x:1000:1000:Andrei:/home/andrei:/bin/bash\n")
	shadowPath := writeTestFile(t, dir, "shadow", "root:!:19000:0:99999:7:::\nandrei:$6$hash:20000:1:90:14:7:21000:\n")
	shadow, warnings := readShadowEntries(shadowPath)
	if len(warnings) != 0 {
		t.Fatalf("unexpected warnings: %v", warnings)
	}
	users, warnings := readLocalUsers(passwd, shadow, model.PasswordPolicyInfo{LoginDefs: map[string]string{"UID_MIN": "1000"}})
	if len(warnings) != 0 || len(users) != 2 {
		t.Fatalf("users=%d warnings=%v", len(users), warnings)
	}
	if !users[0].SystemAccount || !users[0].PasswordLocked {
		t.Fatalf("unexpected root: %+v", users[0])
	}
	if users[1].PasswordExpiresAt == nil || users[1].PasswordLastSet == nil {
		t.Fatalf("missing aging dates: %+v", users[1])
	}
}

func TestParseCronFileAndRedaction(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "crontab", "MAILTO=root@example\n0 1 * * * root curl https://user:pass@example/api?token=abcd\n@reboot root APP_PASSWORD=secret /opt/start.sh\n")
	entries, env, warnings := parseCronFile(path, "", true)
	if len(warnings) != 0 || len(entries) != 2 || len(env) != 1 {
		t.Fatalf("entries=%v env=%v warnings=%v", entries, env, warnings)
	}
	for _, entry := range entries {
		if entry.Command == "" || entry.Command == "secret" {
			t.Fatalf("unexpected command: %q", entry.Command)
		}
		if entry.Command == "curl https://user:pass@example/api?token=abcd" {
			t.Fatalf("credentials not redacted: %q", entry.Command)
		}
	}
}

func TestParseINIExcludesSecrets(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "sssd.conf", "[sssd]\ndomains = example.local\nservices = nss, pam\n[domain/example.local]\nid_provider = ad\nldap_uri = ldaps://ldap.example.local\nldap_default_authtok = secret\n")
	sections, err := parseINI(path)
	if err != nil {
		t.Fatal(err)
	}
	if sections["domain/example.local"]["id_provider"] != "ad" {
		t.Fatalf("unexpected sections: %+v", sections)
	}
	if _, ok := sections["domain/example.local"]["ldap_default_authtok"]; ok {
		t.Fatal("secret key was retained")
	}
}

func TestParseIPTablesSave(t *testing.T) {
	info := model.FirewallInfo{DefaultPolicies: map[string]string{}}
	parseIPTablesSave("*filter\n:INPUT DROP [0:0]\n:FORWARD ACCEPT [0:0]\n-A INPUT -p tcp --dport 22 -j ACCEPT\nCOMMIT\n", "iptables", "ipv4", &info)
	if info.DefaultPolicies["iptables:filter:INPUT"] != "DROP" || len(info.Rules) != 1 || info.Rules[0].Action != "ACCEPT" {
		t.Fatalf("unexpected firewall info: %+v", info)
	}
}

func TestParseNTPConfigFiles(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "chrony.conf", "server 10.0.0.1 iburst\npool pool.example.local iburst\n")
	servers := parseNTPConfigFiles([]string{path})
	if len(servers) != 2 || servers[0].Address != "10.0.0.1" {
		t.Fatalf("unexpected servers: %+v", servers)
	}
}

func TestParseSyslogDestinations(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "rsyslog.conf", "*.* @@graylog.example.local:514\naction(type=\"omfwd\" target=\"10.0.0.5\" port=\"10514\" protocol=\"tcp\")\n")
	values, err := parseSyslogDestinations(path)
	if err != nil {
		t.Fatal(err)
	}
	if len(values) < 2 {
		t.Fatalf("unexpected destinations: %+v", values)
	}
}

func TestParseBeatOutputDetails(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "filebeat.yml", `
filebeat.modules:
  - module: system

output.logstash:
  enabled: true
  hosts:
    - "logstash01.example.local:5044"
    - "ssl://user:password@logstash02.example.local:5044"
  loadbalance: true
  worker: 2
  ssl:
    enabled: true
    verification_mode: full
    certificate_authorities: ["/etc/pki/ca.crt"]
`)
	outputs, modules, details := parseBeatConfig(path)
	if len(outputs) != 1 || outputs[0] != "logstash" {
		t.Fatalf("unexpected outputs: %+v", outputs)
	}
	if len(modules) != 1 || modules[0] != "system" {
		t.Fatalf("unexpected modules: %+v", modules)
	}
	if len(details) != 1 {
		t.Fatalf("unexpected details: %+v", details)
	}
	value := details[0]
	if len(value.Hosts) != 2 || !containsString(value.Hosts, "ssl://<redacted>@logstash02.example.local:5044") {
		t.Fatalf("unexpected hosts: %+v", value.Hosts)
	}
	if value.Enabled == nil || !*value.Enabled || value.LoadBalance == nil || !*value.LoadBalance {
		t.Fatalf("missing flags: %+v", value)
	}
	if value.Workers == nil || *value.Workers != 2 || value.SSLEnabled == nil || !*value.SSLEnabled {
		t.Fatalf("missing worker/ssl: %+v", value)
	}
	if value.SSLVerificationMode != "full" || len(value.CertificateAuthorities) != 1 {
		t.Fatalf("unexpected ssl details: %+v", value)
	}
}

func TestParseBeatFileAndElasticsearchOutputs(t *testing.T) {
	dir := t.TempDir()
	path := writeTestFile(t, dir, "auditbeat.yml", `
output.elasticsearch:
  hosts: ["https://es01.example.local:9200", "https://es02.example.local:9200"]
  index: "auditbeat-custom-%{+yyyy.MM.dd}"
  pipeline: "audit-pipeline"

output.file:
  path: "/var/tmp/auditbeat"
  filename: "events.json"
`)
	outputs, _, details := parseBeatConfig(path)
	if len(outputs) != 2 || len(details) != 2 {
		t.Fatalf("outputs=%v details=%+v", outputs, details)
	}
	var elasticsearch, fileFound bool
	for _, detail := range details {
		switch detail.Type {
		case "elasticsearch":
			elasticsearch = detail.Index != "" && detail.Pipeline == "audit-pipeline" && len(detail.Hosts) == 2
		case "file":
			fileFound = detail.Path == "/var/tmp/auditbeat" && detail.Filename == "events.json"
		}
	}
	if !elasticsearch || !fileFound {
		t.Fatalf("unexpected details: %+v", details)
	}
}

func TestSanitizeBeatText(t *testing.T) {
	input := "elasticsearch: https://user:secret@example.local:9200 password=abc token: xyz"
	output := sanitizeBeatText(input)
	if strings.Contains(output, "secret") || strings.Contains(output, "password=abc") || strings.Contains(output, "token: xyz") {
		t.Fatalf("secret retained: %q", output)
	}
}
