package collector

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"vm-doc-agent/internal/model"
)

func collectProxy() (model.ProxyInfo, []string) {
	info := model.ProxyInfo{NoProxy: []string{}, Sources: []string{}}
	warnings := []string{}
	applyProxyEnvironment(&info)
	paths := existingFiles(
		"/etc/environment", "/etc/sysconfig/proxy", "/etc/apt/apt.conf", "/etc/apt/apt.conf.d/*",
		"/etc/yum.conf", "/etc/dnf/dnf.conf", "/etc/zypp/zypp.conf",
	)
	for _, path := range paths {
		data, err := os.ReadFile(path)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("proxy: read %s: %v", path, err))
			continue
		}
		before := proxyFingerprint(info)
		parseProxyFile(&info, path, string(data))
		if proxyFingerprint(info) != before {
			info.Sources = append(info.Sources, path)
		}
	}
	info.NoProxy = uniqueSorted(info.NoProxy)
	info.Sources = uniqueSorted(info.Sources)
	info.Configured = info.HTTPProxy != "" || info.HTTPSProxy != "" || info.FTPProxy != "" || info.AllProxy != "" || len(info.NoProxy) > 0
	return info, warnings
}

func applyProxyEnvironment(info *model.ProxyInfo) {
	values := map[string]string{}
	for _, entry := range os.Environ() {
		parts := strings.SplitN(entry, "=", 2)
		if len(parts) == 2 {
			values[strings.ToLower(parts[0])] = parts[1]
		}
	}
	setProxyValue(info, "http_proxy", values["http_proxy"])
	setProxyValue(info, "https_proxy", values["https_proxy"])
	setProxyValue(info, "ftp_proxy", values["ftp_proxy"])
	setProxyValue(info, "all_proxy", values["all_proxy"])
	setProxyValue(info, "no_proxy", values["no_proxy"])
	if proxyFingerprint(*info) != "||||" {
		info.Sources = append(info.Sources, "process_environment")
	}
}

func parseProxyFile(info *model.ProxyInfo, path, content string) {
	aptPattern := regexp.MustCompile(`(?i)^Acquire::(http|https|ftp)::Proxy\s+["']?([^"';]+)`)
	for _, raw := range strings.Split(content, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimSuffix(line, ";")
		if matches := aptPattern.FindStringSubmatch(line); len(matches) == 3 {
			setProxyValue(info, strings.ToLower(matches[1])+"_proxy", matches[2])
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.ToLower(strings.Trim(strings.TrimSpace(parts[0]), `"'`))
		value := strings.Trim(strings.TrimSpace(parts[1]), `"'`)
		switch key {
		case "http_proxy", "https_proxy", "ftp_proxy", "all_proxy", "no_proxy", "proxy", "proxy_url":
			if key == "proxy" || key == "proxy_url" {
				key = "http_proxy"
			}
			setProxyValue(info, key, value)
		case "proxy_enabled":
			// Presence is recorded through the source, but no endpoint is invented.
		}
	}
	_ = filepath.Base(path)
}

func setProxyValue(info *model.ProxyInfo, key, value string) {
	value = strings.TrimSpace(value)
	if value == "" {
		return
	}
	if key == "no_proxy" {
		for _, item := range strings.Split(value, ",") {
			if item = strings.TrimSpace(item); item != "" {
				info.NoProxy = append(info.NoProxy, item)
			}
		}
		return
	}
	value = sanitizeProxyEndpoint(value)
	switch key {
	case "http_proxy":
		if info.HTTPProxy == "" {
			info.HTTPProxy = value
		}
	case "https_proxy":
		if info.HTTPSProxy == "" {
			info.HTTPSProxy = value
		}
	case "ftp_proxy":
		if info.FTPProxy == "" {
			info.FTPProxy = value
		}
	case "all_proxy":
		if info.AllProxy == "" {
			info.AllProxy = value
		}
	}
}

func sanitizeProxyEndpoint(value string) string {
	urlCredentials := regexp.MustCompile(`(?i)([a-z][a-z0-9+.-]*://)([^/@\s]+)@`)
	return urlCredentials.ReplaceAllString(strings.TrimSpace(value), `${1}<redacted>@`)
}

func proxyFingerprint(info model.ProxyInfo) string {
	return strings.Join([]string{info.HTTPProxy, info.HTTPSProxy, info.FTPProxy, info.AllProxy, strings.Join(info.NoProxy, ",")}, "|")
}
