package collector

import (
	"testing"
	"time"

	"vm-doc-agent/internal/model"
)

func TestRunCollectorTimeout(t *testing.T) {
	_, status, warnings := runCollector("slow", true, 10*time.Millisecond, func() (string, []string) {
		time.Sleep(50 * time.Millisecond)
		return "late", nil
	})
	if status.Status != "timeout" || len(warnings) != 1 {
		t.Fatalf("unexpected result: %+v %v", status, warnings)
	}
}

func TestDisabledCollectorHasNoTimestamps(t *testing.T) {
	_, status, _ := runCollector("off", false, time.Second, func() (string, []string) { return "", nil })
	if status.Status != "disabled" || status.StartedAt != nil || status.CollectedAt != nil {
		t.Fatalf("unexpected disabled status: %+v", status)
	}
}

func TestApplyLimitsMarksCollectorPartial(t *testing.T) {
	inventory := model.Inventory{
		Collection:  model.CollectionInfo{Collectors: map[string]model.CollectorStatus{"services": {Status: "success"}}},
		Services:    []model.ServiceInfo{{Name: "a"}, {Name: "b"}, {Name: "c"}},
		Truncations: map[string]model.TruncationInfo{},
	}
	applyLimits(&inventory, Limits{MaxPartitions: 10, MaxRoutes: 10, MaxServices: 2, MaxPorts: 10, MaxFirewallRules: 10, MaxFirewallZones: 10, MaxAccounts: 10, MaxCronEntries: 10, MaxCronScripts: 10, MaxPolicyFiles: 10, MaxInventoryBytes: 1024 * 1024})
	if len(inventory.Services) != 2 {
		t.Fatalf("unexpected services: %d", len(inventory.Services))
	}
	if inventory.Collection.Collectors["services"].Status != "partial" {
		t.Fatalf("status not partial: %+v", inventory.Collection.Collectors["services"])
	}
	if _, ok := inventory.Truncations["services"]; !ok {
		t.Fatal("missing truncation metadata")
	}
}

func TestParseIPRoutes(t *testing.T) {
	routes := parseIPRoutes("default via 10.0.0.1 dev eth0 proto dhcp metric 100\n10.0.0.0/24 dev eth0 proto kernel src 10.0.0.5", "ipv4")
	if len(routes) != 2 || !routes[0].Default || routes[0].Gateway != "10.0.0.1" || routes[1].Source != "10.0.0.5" {
		t.Fatalf("unexpected routes: %+v", routes)
	}
}

func TestSanitizeProxyEndpoint(t *testing.T) {
	value := sanitizeProxyEndpoint("http://user:secret@proxy.example:3128")
	if value != "http://<redacted>@proxy.example:3128" {
		t.Fatalf("unexpected proxy: %s", value)
	}
}
