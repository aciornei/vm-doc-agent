package collector

import (
	"crypto/rand"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func ensureAgentID(stateDir string) (string, error) {
	if err := os.MkdirAll(stateDir, 0750); err != nil {
		return "", fmt.Errorf("create state directory: %w", err)
	}
	path := filepath.Join(stateDir, "agent-id")
	if value := normalizeUUID(readTrimmed(path)); value != "" {
		return value, nil
	}
	value, err := newUUID()
	if err != nil {
		return "", err
	}
	temporary := path + ".tmp"
	if err := os.WriteFile(temporary, []byte(value+"\n"), 0600); err != nil {
		return "", fmt.Errorf("write agent id: %w", err)
	}
	if err := os.Rename(temporary, path); err != nil {
		return "", fmt.Errorf("save agent id: %w", err)
	}
	return value, nil
}

func newUUID() (string, error) {
	value := make([]byte, 16)
	if _, err := rand.Read(value); err != nil {
		return "", fmt.Errorf("generate agent id: %w", err)
	}
	value[6] = (value[6] & 0x0f) | 0x40
	value[8] = (value[8] & 0x3f) | 0x80
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", value[0:4], value[4:6], value[6:8], value[8:10], value[10:16]), nil
}

func readMachineID() string {
	for _, path := range []string{"/etc/machine-id", "/var/lib/dbus/machine-id"} {
		if value := strings.ToLower(readTrimmed(path)); value != "" {
			return value
		}
	}
	return ""
}
