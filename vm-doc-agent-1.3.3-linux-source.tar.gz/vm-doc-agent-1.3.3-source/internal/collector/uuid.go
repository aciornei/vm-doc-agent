package collector

import (
	"encoding/hex"
	"fmt"
	"strings"
)

func collectProductUUID() (string, string) {
	if value := normalizeUUID(readTrimmed("/sys/class/dmi/id/product_uuid")); value != "" {
		return value, "/sys/class/dmi/id/product_uuid"
	}
	if value := normalizeUUID(runCommand("dmidecode", "-s", "system-uuid")); value != "" {
		return value, "dmidecode -s system-uuid"
	}
	return "", ""
}

func normalizeUUID(value string) string {
	value = strings.ToLower(strings.TrimSpace(value))
	value = strings.Trim(value, "{}")
	if value == "" || value == "00000000-0000-0000-0000-000000000000" || value == "ffffffff-ffff-ffff-ffff-ffffffffffff" {
		return ""
	}
	compact := strings.ReplaceAll(value, "-", "")
	if len(compact) != 32 {
		return ""
	}
	if _, err := hex.DecodeString(compact); err != nil {
		return ""
	}
	return fmt.Sprintf("%s-%s-%s-%s-%s", compact[0:8], compact[8:12], compact[12:16], compact[16:20], compact[20:32])
}

func smbiosLegacyByteOrder(value string) string {
	value = normalizeUUID(value)
	compact := strings.ReplaceAll(value, "-", "")
	if len(compact) != 32 {
		return ""
	}
	bytes, err := hex.DecodeString(compact)
	if err != nil || len(bytes) != 16 {
		return ""
	}
	reverse(bytes[0:4])
	reverse(bytes[4:6])
	reverse(bytes[6:8])
	result := fmt.Sprintf("%x-%x-%x-%x-%x", bytes[0:4], bytes[4:6], bytes[6:8], bytes[8:10], bytes[10:16])
	if result == value {
		return ""
	}
	return result
}

func reverse(value []byte) {
	for left, right := 0, len(value)-1; left < right; left, right = left+1, right-1 {
		value[left], value[right] = value[right], value[left]
	}
}
