package collector

import (
	"encoding/json"
	"fmt"

	"vm-doc-agent/internal/model"
)

func applyLimits(inventory *model.Inventory, limits Limits) {
	truncatePartitionList(inventory, limits.MaxPartitions)
	truncateRouteList(inventory, limits.MaxRoutes)
	truncateServiceList(inventory, limits.MaxServices)
	truncatePortList(inventory, limits.MaxPorts)
	truncateFirewall(inventory, limits.MaxFirewallRules, limits.MaxFirewallZones)
	truncateAccounts(inventory, limits.MaxAccounts)
	truncateCron(inventory, limits.MaxCronEntries, limits.MaxCronScripts)
	truncatePolicies(inventory, limits.MaxPolicyFiles)
	truncateLongStrings(inventory)
	shrinkToInventoryLimit(inventory, limits.MaxInventoryBytes)
	if len(inventory.Truncations) == 0 {
		inventory.Truncations = nil
	}
}

func truncatePartitionList(inventory *model.Inventory, limit int) {
	if len(inventory.Storage.Partitions) <= limit {
		return
	}
	total := len(inventory.Storage.Partitions)
	inventory.Storage.Partitions = inventory.Storage.Partitions[:limit]
	markTruncated(inventory, "storage", "storage.partitions", total, limit, limit, "configured item limit")
}

func truncateRouteList(inventory *model.Inventory, limit int) {
	if len(inventory.Network.Routes) <= limit {
		return
	}
	total := len(inventory.Network.Routes)
	inventory.Network.Routes = inventory.Network.Routes[:limit]
	markTruncated(inventory, "network", "network.routes", total, limit, limit, "configured item limit")
}

func truncateServiceList(inventory *model.Inventory, limit int) {
	if len(inventory.Services) <= limit {
		return
	}
	total := len(inventory.Services)
	inventory.Services = inventory.Services[:limit]
	markTruncated(inventory, "services", "services", total, limit, limit, "configured item limit")
}

func truncatePortList(inventory *model.Inventory, limit int) {
	if len(inventory.ListeningPorts) <= limit {
		return
	}
	total := len(inventory.ListeningPorts)
	inventory.ListeningPorts = inventory.ListeningPorts[:limit]
	markTruncated(inventory, "listening_ports", "listening_ports", total, limit, limit, "configured item limit")
}

func truncateFirewall(inventory *model.Inventory, ruleLimit, zoneLimit int) {
	if len(inventory.Firewall.Rules) > ruleLimit {
		total := len(inventory.Firewall.Rules)
		inventory.Firewall.Rules = inventory.Firewall.Rules[:ruleLimit]
		markTruncated(inventory, "firewall", "firewall.rules", total, ruleLimit, ruleLimit, "configured item limit")
	}
	if len(inventory.Firewall.Zones) > zoneLimit {
		total := len(inventory.Firewall.Zones)
		inventory.Firewall.Zones = inventory.Firewall.Zones[:zoneLimit]
		markTruncated(inventory, "firewall", "firewall.zones", total, zoneLimit, zoneLimit, "configured item limit")
	}
}

func truncateAccounts(inventory *model.Inventory, limit int) {
	if len(inventory.Accounts.LocalUsers) <= limit {
		return
	}
	total := len(inventory.Accounts.LocalUsers)
	inventory.Accounts.LocalUsers = inventory.Accounts.LocalUsers[:limit]
	markTruncated(inventory, "accounts", "accounts.local_users", total, limit, limit, "configured item limit")
}

func truncateCron(inventory *model.Inventory, entryLimit, scriptLimit int) {
	if len(inventory.Cron.Entries) > entryLimit {
		total := len(inventory.Cron.Entries)
		inventory.Cron.Entries = inventory.Cron.Entries[:entryLimit]
		markTruncated(inventory, "cron", "cron.entries", total, entryLimit, entryLimit, "configured item limit")
	}
	if len(inventory.Cron.PeriodicScripts) > scriptLimit {
		total := len(inventory.Cron.PeriodicScripts)
		inventory.Cron.PeriodicScripts = inventory.Cron.PeriodicScripts[:scriptLimit]
		markTruncated(inventory, "cron", "cron.periodic_scripts", total, scriptLimit, scriptLimit, "configured item limit")
	}
}

func truncatePolicies(inventory *model.Inventory, limit int) {
	remaining := limit
	groups := []struct {
		name   string
		values *[]model.PolicyFileInfo
	}{
		{"policies.audit_rules", &inventory.Policies.AuditRules},
		{"policies.sudoers", &inventory.Policies.Sudoers},
		{"policies.limits", &inventory.Policies.Limits},
		{"policies.sysctl", &inventory.Policies.Sysctl},
		{"policies.custom_markers", &inventory.Policies.CustomMarkers},
	}
	totalAll := 0
	for _, group := range groups {
		totalAll += len(*group.values)
	}
	if totalAll <= limit {
		return
	}
	for _, group := range groups {
		values := *group.values
		keep := len(values)
		if keep > remaining {
			keep = remaining
		}
		if keep < 0 {
			keep = 0
		}
		*group.values = values[:keep]
		remaining -= keep
		if remaining < 0 {
			remaining = 0
		}
	}
	markTruncated(inventory, "policies", "policies.files", totalAll, limit, limit, "configured aggregate item limit")
}

func truncateLongStrings(inventory *model.Inventory) {
	for index := range inventory.Services {
		inventory.Services[index].Description = truncateString(inventory.Services[index].Description, 1024)
	}
	for index := range inventory.Firewall.Rules {
		inventory.Firewall.Rules[index].Rule = truncateString(inventory.Firewall.Rules[index].Rule, 4096)
	}
	for index := range inventory.Cron.Entries {
		inventory.Cron.Entries[index].Command = truncateString(inventory.Cron.Entries[index].Command, 4096)
	}
}

func shrinkToInventoryLimit(inventory *model.Inventory, maxBytes int) {
	if maxBytes <= 0 {
		return
	}
	for attempts := 0; attempts < 24; attempts++ {
		data, err := json.Marshal(inventory)
		if err != nil || len(data) <= maxBytes {
			return
		}
		name, collectorName, detected, returned, changed := shrinkLargestCollection(inventory)
		if !changed {
			inventory.CollectionWarnings = firstStrings(inventory.CollectionWarnings, 100)
			return
		}
		markTruncated(inventory, collectorName, name, detected, returned, maxBytes, "maximum inventory byte size")
	}
}

func shrinkLargestCollection(inventory *model.Inventory) (string, string, int, int, bool) {
	type candidate struct {
		name, collector string
		length          int
		shrink          func(int)
	}
	candidates := []candidate{
		{"firewall.rules", "firewall", len(inventory.Firewall.Rules), func(n int) { inventory.Firewall.Rules = inventory.Firewall.Rules[:n] }},
		{"cron.entries", "cron", len(inventory.Cron.Entries), func(n int) { inventory.Cron.Entries = inventory.Cron.Entries[:n] }},
		{"services", "services", len(inventory.Services), func(n int) { inventory.Services = inventory.Services[:n] }},
		{"listening_ports", "listening_ports", len(inventory.ListeningPorts), func(n int) { inventory.ListeningPorts = inventory.ListeningPorts[:n] }},
		{"accounts.local_users", "accounts", len(inventory.Accounts.LocalUsers), func(n int) { inventory.Accounts.LocalUsers = inventory.Accounts.LocalUsers[:n] }},
		{"network.routes", "network", len(inventory.Network.Routes), func(n int) { inventory.Network.Routes = inventory.Network.Routes[:n] }},
	}
	largest := candidate{}
	for _, item := range candidates {
		if item.length > largest.length {
			largest = item
		}
	}
	if largest.length <= 1 {
		return "", "", 0, 0, false
	}
	returned := largest.length / 2
	largest.shrink(returned)
	return largest.name, largest.collector, largest.length, returned, true
}

func markTruncated(inventory *model.Inventory, collectorName, path string, detected, returned, limit int, reason string) {
	if inventory.Truncations == nil {
		inventory.Truncations = map[string]model.TruncationInfo{}
	}
	inventory.Truncations[path] = model.TruncationInfo{Detected: detected, Returned: returned, Limit: limit, Reason: reason}
	status := inventory.Collection.Collectors[collectorName]
	status.Truncated = true
	if status.Status == "success" {
		status.Status = "partial"
	}
	status.WarningCount++
	warning := fmt.Sprintf("%s truncated: detected=%d returned=%d", path, detected, returned)
	if len(status.Warnings) < 20 {
		status.Warnings = append(status.Warnings, warning)
	}
	inventory.Collection.Collectors[collectorName] = status
	inventory.CollectionWarnings = append(inventory.CollectionWarnings, warning)
}
