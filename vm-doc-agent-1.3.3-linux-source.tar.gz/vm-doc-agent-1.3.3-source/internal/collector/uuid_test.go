package collector

import "testing"

func TestSMBIOSLegacyByteOrder(t *testing.T) {
	got := smbiosLegacyByteOrder("00112233-4455-6677-8899-aabbccddeeff")
	want := "33221100-5544-7766-8899-aabbccddeeff"
	if got != want {
		t.Fatalf("got %q, want %q", got, want)
	}
}

func TestNormalizeUUID(t *testing.T) {
	got := normalizeUUID("{00112233445566778899AABBCCDDEEFF}")
	want := "00112233-4455-6677-8899-aabbccddeeff"
	if got != want {
		t.Fatalf("got %q, want %q", got, want)
	}
}

func TestNormalizeInvalidUUID(t *testing.T) {
	if got := normalizeUUID("not-a-uuid"); got != "" {
		t.Fatalf("expected empty value, got %q", got)
	}
}
