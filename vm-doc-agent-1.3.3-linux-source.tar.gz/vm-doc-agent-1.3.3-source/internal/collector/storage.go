package collector

import (
	"bufio"
	"fmt"
	"os"
	"sort"
	"strconv"
	"strings"
	"syscall"

	"vm-doc-agent/internal/model"
)

var ignoredFileSystems = map[string]struct{}{
	"autofs": {}, "bdev": {}, "binfmt_misc": {}, "cgroup": {}, "cgroup2": {},
	"configfs": {}, "debugfs": {}, "devpts": {}, "devtmpfs": {}, "efivarfs": {},
	"fusectl": {}, "hugetlbfs": {}, "mqueue": {}, "nsfs": {}, "proc": {},
	"overlay": {}, "pstore": {}, "ramfs": {}, "rootfs": {}, "securityfs": {},
	"selinuxfs": {}, "squashfs": {}, "sysfs": {}, "tmpfs": {}, "tracefs": {},
}

var remoteFileSystems = map[string]struct{}{
	"9p": {}, "afs": {}, "cifs": {}, "ceph": {}, "davfs": {}, "davfs2": {},
	"fuse.sshfs": {}, "glusterfs": {}, "nfs": {}, "nfs4": {}, "smb3": {},
}

func collectPartitions() ([]model.PartitionInfo, []string) {
	mountsPath := "/proc/self/mounts"
	file, err := os.Open(mountsPath)
	if err != nil {
		mountsPath = "/proc/mounts"
		file, err = os.Open(mountsPath)
	}
	if err != nil {
		return []model.PartitionInfo{}, []string{fmt.Sprintf("partitions: cannot open mount table: %v", err)}
	}
	defer file.Close()

	partitions := make([]model.PartitionInfo, 0)
	warnings := make([]string, 0)
	seen := make(map[string]struct{})
	scanner := bufio.NewScanner(file)
	scanner.Buffer(make([]byte, 4096), 1024*1024)
	for scanner.Scan() {
		fields := strings.Fields(scanner.Text())
		if len(fields) < 4 {
			continue
		}
		device := unescapeMountField(fields[0])
		mountPoint := unescapeMountField(fields[1])
		fileSystem := fields[2]
		if _, ignored := ignoredFileSystems[fileSystem]; ignored {
			continue
		}
		key := device + "\x00" + mountPoint + "\x00" + fileSystem
		if _, exists := seen[key]; exists {
			continue
		}
		seen[key] = struct{}{}

		var stats syscall.Statfs_t
		if err := syscall.Statfs(mountPoint, &stats); err != nil {
			warnings = append(warnings, fmt.Sprintf("partitions: statfs %s: %v", mountPoint, err))
			continue
		}
		blockSize := uint64(stats.Bsize)
		total := stats.Blocks * blockSize
		free := stats.Bfree * blockSize
		available := stats.Bavail * blockSize
		used := uint64(0)
		if total >= free {
			used = total - free
		}
		usage := float64(0)
		if denominator := used + available; denominator > 0 {
			usage = float64(used) * 100 / float64(denominator)
		}
		options := strings.Split(fields[3], ",")
		sort.Strings(options)
		partitions = append(partitions, model.PartitionInfo{
			Device:         device,
			MountPoint:     mountPoint,
			FileSystem:     fileSystem,
			MountOptions:   options,
			TotalBytes:     total,
			UsedBytes:      used,
			AvailableBytes: available,
			UsagePercent:   roundTwoDecimals(usage),
			ReadOnly:       containsString(options, "ro"),
			Remote:         isRemoteMount(device, fileSystem),
		})
	}
	if err := scanner.Err(); err != nil {
		warnings = append(warnings, fmt.Sprintf("partitions: read %s: %v", mountsPath, err))
	}

	sort.Slice(partitions, func(i, j int) bool {
		if partitions[i].MountPoint == partitions[j].MountPoint {
			return partitions[i].Device < partitions[j].Device
		}
		return partitions[i].MountPoint < partitions[j].MountPoint
	})
	return partitions, warnings
}

func unescapeMountField(value string) string {
	var builder strings.Builder
	for index := 0; index < len(value); index++ {
		if value[index] == '\\' && index+3 < len(value) {
			if decoded, err := strconv.ParseUint(value[index+1:index+4], 8, 8); err == nil {
				builder.WriteByte(byte(decoded))
				index += 3
				continue
			}
		}
		builder.WriteByte(value[index])
	}
	return builder.String()
}

func isRemoteMount(device, fileSystem string) bool {
	if _, ok := remoteFileSystems[fileSystem]; ok {
		return true
	}
	return strings.Contains(device, ":") || strings.HasPrefix(device, "//")
}

func containsString(values []string, wanted string) bool {
	for _, value := range values {
		if value == wanted {
			return true
		}
	}
	return false
}

func roundTwoDecimals(value float64) float64 {
	if value >= 0 {
		return float64(int64(value*100+0.5)) / 100
	}
	return float64(int64(value*100-0.5)) / 100
}
