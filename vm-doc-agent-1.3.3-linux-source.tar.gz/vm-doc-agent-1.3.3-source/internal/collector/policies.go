package collector

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectPolicies(customPaths []string) (model.PoliciesInfo, []string) {
	info := model.PoliciesInfo{
		SELinux: collectSELinux(), AppArmor: collectAppArmor(),
		AuditRules: []model.PolicyFileInfo{}, Sudoers: []model.PolicyFileInfo{}, Limits: []model.PolicyFileInfo{}, Sysctl: []model.PolicyFileInfo{}, CustomMarkers: []model.PolicyFileInfo{},
	}
	warnings := []string{}
	info.AuditRules = collectPolicyFiles("audit", existingFiles("/etc/audit/audit.rules", "/etc/audit/rules.d/*.rules"), true)
	info.Sudoers = collectPolicyFiles("sudoers", existingFiles("/etc/sudoers", "/etc/sudoers.d/*"), true)
	info.Limits = collectPolicyFiles("limits", existingFiles("/etc/security/limits.conf", "/etc/security/limits.d/*.conf"), true)
	info.Sysctl = collectPolicyFiles("sysctl", existingFiles("/etc/sysctl.conf", "/etc/sysctl.d/*.conf", "/usr/lib/sysctl.d/*.conf"), true)
	customFiles, customWarnings := expandCustomPolicyPaths(customPaths)
	warnings = append(warnings, customWarnings...)
	info.CustomMarkers = collectPolicyFiles("custom", customFiles, true)
	return info, warnings
}

func collectSELinux() model.MandatoryAccessControlInfo {
	info := model.MandatoryAccessControlInfo{Profiles: []string{}}
	if _, err := os.Stat("/sys/fs/selinux"); err == nil {
		info.Installed = true
	}
	if _, path := firstExecutable("getenforce"); path != "" {
		info.Installed = true
		output, _ := commandOutput(3*time.Second, path)
		info.Mode = strings.ToLower(strings.TrimSpace(output))
		info.Enabled = info.Mode == "enforcing" || info.Mode == "permissive"
	}
	if info.Mode == "" {
		if value := readTrimmed("/sys/fs/selinux/enforce"); value == "1" {
			info.Mode = "enforcing"
			info.Enabled = true
		} else if value == "0" {
			info.Mode = "permissive"
			info.Enabled = true
		}
	}
	if data, err := os.ReadFile("/etc/selinux/config"); err == nil {
		info.Installed = true
		for _, raw := range strings.Split(string(data), "\n") {
			line := strings.TrimSpace(strings.SplitN(raw, "#", 2)[0])
			parts := strings.SplitN(line, "=", 2)
			if len(parts) != 2 {
				continue
			}
			switch strings.TrimSpace(parts[0]) {
			case "SELINUX":
				if info.Mode == "" {
					info.Mode = strings.ToLower(strings.TrimSpace(parts[1]))
					info.Enabled = info.Mode != "disabled"
				}
			case "SELINUXTYPE":
				info.Policy = strings.TrimSpace(parts[1])
			}
		}
	}
	return info
}

func collectAppArmor() model.MandatoryAccessControlInfo {
	info := model.MandatoryAccessControlInfo{Profiles: []string{}}
	if _, err := os.Stat("/sys/module/apparmor"); err == nil {
		info.Installed = true
	}
	if value := strings.ToUpper(readTrimmed("/sys/module/apparmor/parameters/enabled")); value == "Y" {
		info.Enabled = true
		info.Mode = "enabled"
	}
	if file, err := os.Open("/sys/kernel/security/apparmor/profiles"); err == nil {
		defer file.Close()
		info.Installed, info.Enabled = true, true
		scanner := bufio.NewScanner(file)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line != "" {
				info.Profiles = append(info.Profiles, line)
			}
			if len(info.Profiles) >= 500 {
				break
			}
		}
	}
	if len(info.Profiles) == 0 {
		for _, path := range existingFiles("/etc/apparmor.d/*") {
			base := filepath.Base(path)
			if !strings.HasPrefix(base, ".") {
				info.Profiles = append(info.Profiles, base)
			}
		}
	}
	if len(info.Profiles) > 0 {
		info.Installed = true
	}
	info.Profiles = uniqueSorted(info.Profiles)
	return info
}

func collectPolicyFiles(kind string, paths []string, hash bool) []model.PolicyFileInfo {
	result := make([]model.PolicyFileInfo, 0, len(paths))
	for _, path := range paths {
		if item, ok := policyFileInfo(path, kind, hash); ok {
			result = append(result, item)
		}
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Path < result[j].Path })
	return result
}

func expandCustomPolicyPaths(patterns []string) ([]string, []string) {
	result := []string{}
	warnings := []string{}
	seen := map[string]bool{}
	for _, pattern := range patterns {
		pattern = strings.TrimSpace(pattern)
		if pattern == "" {
			continue
		}
		matches, err := filepath.Glob(pattern)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("policies: invalid pattern %s: %v", pattern, err))
			continue
		}
		if len(matches) == 0 {
			if _, err := os.Stat(pattern); err == nil {
				matches = []string{pattern}
			} else {
				warnings = append(warnings, "policies: no match for "+pattern)
				continue
			}
		}
		for _, match := range matches {
			info, err := os.Stat(match)
			if err != nil {
				continue
			}
			if !info.IsDir() {
				if !seen[match] {
					seen[match] = true
					result = append(result, match)
				}
				continue
			}
			count := 0
			_ = filepath.Walk(match, func(path string, item os.FileInfo, walkErr error) error {
				if walkErr != nil {
					return nil
				}
				if item.IsDir() {
					return nil
				}
				if count >= 500 {
					return filepath.SkipDir
				}
				if !seen[path] {
					seen[path] = true
					result = append(result, path)
					count++
				}
				return nil
			})
		}
	}
	sort.Strings(result)
	return result, warnings
}
