package collector

import (
	"bufio"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectIntegrations(services []model.ServiceInfo, ports []model.ListeningSocket, outputTestTimeout time.Duration) (model.IntegrationsInfo, []string) {
	type beatResult struct {
		name     string
		info     model.BeatInfo
		warnings []string
	}
	beatChannel := make(chan beatResult, 2)
	for _, beatName := range []string{"auditbeat", "filebeat"} {
		name := beatName
		go func() {
			info, warnings := collectBeat(name, services, outputTestTimeout)
			beatChannel <- beatResult{name: name, info: info, warnings: warnings}
		}()
	}

	glpi, glpiWarnings := collectGLPIAgent(services)
	node, nodeWarnings := collectNodeExporter(services, ports)
	syslog, syslogWarnings := collectSyslog(services)
	var auditbeat, filebeat model.BeatInfo
	warnings := append(glpiWarnings, nodeWarnings...)
	warnings = append(warnings, syslogWarnings...)
	for index := 0; index < 2; index++ {
		result := <-beatChannel
		if result.name == "auditbeat" {
			auditbeat = result.info
		} else {
			filebeat = result.info
		}
		warnings = append(warnings, result.warnings...)
	}
	return model.IntegrationsInfo{GLPIAgent: glpi, NodeExporter: node, Auditbeat: auditbeat, Filebeat: filebeat, Syslog: syslog}, warnings
}

func collectGLPIAgent(services []model.ServiceInfo) (model.ComponentInfo, []string) {
	info := model.ComponentInfo{ConfigFiles: []string{}, ServiceNames: []string{}}
	warnings := []string{}
	binaryName, binaryPath := firstExecutable("glpi-agent", "fusioninventory-agent")
	info.BinaryPath = binaryPath
	info.Name = binaryName
	packageName, packageVersion := packageVersion("glpi-agent", "fusioninventory-agent", "fusioninventory-agent-task-inventory")
	info.PackageName, info.PackageVersion = packageName, packageVersion
	info.Installed = binaryPath != "" || packageVersion != ""
	if binaryPath != "" {
		output, err := commandOutput(5*time.Second, binaryPath, "--version")
		if err == nil || output != "" {
			info.Version = normalizeVersionOutput(output)
		}
		if err != nil && output == "" {
			warnings = append(warnings, fmt.Sprintf("glpi agent: version: %v", err))
		}
	}
	if info.Version == "" {
		info.Version = packageVersion
	}
	for _, candidate := range []string{"glpi-agent", "fusioninventory-agent"} {
		name, active, enabled := serviceState(services, candidate)
		if name != "" {
			info.ServiceNames = append(info.ServiceNames, name)
			if info.ServiceActive == "" || active == "active" || active == "running" {
				info.ServiceActive = active
			}
			if info.ServiceEnabled == "" {
				info.ServiceEnabled = enabled
			}
		}
	}
	info.ServiceNames = uniqueSorted(info.ServiceNames)
	info.ConfigFiles = existingFiles(
		"/etc/glpi-agent/agent.cfg", "/etc/glpi-agent/conf.d/*.cfg", "/etc/glpi-agent/conf.d/*.conf",
		"/etc/fusioninventory/agent.cfg", "/etc/fusioninventory/conf.d/*.cfg",
	)
	return info, warnings
}

func collectNodeExporter(services []model.ServiceInfo, ports []model.ListeningSocket) (model.PrometheusAgent, []string) {
	info := model.PrometheusAgent{ComponentInfo: model.ComponentInfo{ConfigFiles: []string{}, ServiceNames: []string{}}, ListenAddresses: []string{}, MetricsEndpoints: []string{}}
	warnings := []string{}
	_, binaryPath := firstExecutable("node_exporter", "prometheus-node-exporter")
	info.BinaryPath = binaryPath
	info.Name = "node_exporter"
	packageName, packageVersion := packageVersion("prometheus-node-exporter", "node_exporter")
	info.PackageName, info.PackageVersion = packageName, packageVersion
	info.Installed = binaryPath != "" || packageVersion != ""
	if binaryPath != "" {
		output, err := commandOutput(5*time.Second, binaryPath, "--version")
		if err == nil || output != "" {
			info.Version = normalizeVersionOutput(output)
		}
	}
	if info.Version == "" {
		info.Version = packageVersion
	}
	for _, candidate := range []string{"node_exporter", "prometheus-node-exporter"} {
		name, active, enabled := serviceState(services, candidate)
		if name != "" {
			info.ServiceNames = append(info.ServiceNames, name)
			if info.ServiceActive == "" || active == "active" || active == "running" {
				info.ServiceActive = active
			}
			if info.ServiceEnabled == "" {
				info.ServiceEnabled = enabled
			}
		}
	}
	info.ServiceNames = uniqueSorted(info.ServiceNames)
	info.ConfigFiles = existingFiles(
		"/etc/default/prometheus-node-exporter", "/etc/default/node_exporter", "/etc/sysconfig/node_exporter",
		"/etc/systemd/system/node_exporter.service", "/etc/systemd/system/prometheus-node-exporter.service",
		"/usr/lib/systemd/system/node_exporter.service", "/usr/lib/systemd/system/prometheus-node-exporter.service",
	)

	endpoints := []string{}
	for _, socket := range ports {
		matches := false
		for _, process := range socket.Processes {
			name := strings.ToLower(process.Name + " " + process.Executable)
			if strings.Contains(name, "node_exporter") || strings.Contains(name, "prometheus-node-exporter") {
				matches = true
				break
			}
		}
		if !matches && socket.Port == 9100 && info.Installed {
			matches = true
		}
		if !matches || socket.Protocol != "tcp" {
			continue
		}
		listen := net.JoinHostPort(socket.Address, strconv.Itoa(int(socket.Port)))
		info.ListenAddresses = append(info.ListenAddresses, listen)
		host := socket.Address
		if socket.Wildcard || host == "0.0.0.0" {
			host = "127.0.0.1"
		}
		if host == "::" {
			host = "::1"
		}
		endpoints = append(endpoints, "http://"+net.JoinHostPort(host, strconv.Itoa(int(socket.Port)))+"/metrics")
	}
	if len(endpoints) == 0 && info.Installed {
		endpoints = append(endpoints, "http://127.0.0.1:9100/metrics")
	}
	info.ListenAddresses = uniqueSorted(info.ListenAddresses)
	info.MetricsEndpoints = uniqueSorted(endpoints)
	checked := time.Now().UTC()
	info.MetricsCheckedAt = &checked
	for _, endpoint := range info.MetricsEndpoints {
		status, samples, err := checkPrometheusMetrics(endpoint)
		if status != 0 {
			info.MetricsHTTPStatus = status
		}
		if err == nil {
			info.MetricsReachable = true
			info.MetricSampleCount = samples
			info.MetricsError = ""
			break
		}
		info.MetricsError = err.Error()
	}
	if info.Installed && !info.MetricsReachable && info.MetricsError != "" {
		warnings = append(warnings, "node_exporter: metrics endpoint not readable locally: "+info.MetricsError)
	}
	return info, warnings
}

func checkPrometheusMetrics(endpoint string) (int, int, error) {
	client := &http.Client{Timeout: 4 * time.Second}
	request, err := http.NewRequest(http.MethodGet, endpoint, nil)
	if err != nil {
		return 0, 0, err
	}
	request.Header.Set("User-Agent", "vm-doc-agent/metrics-check")
	response, err := client.Do(request)
	if err != nil {
		return 0, 0, err
	}
	defer response.Body.Close()
	reader := io.LimitReader(response.Body, 2*1024*1024)
	scanner := bufio.NewScanner(reader)
	samples := 0
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" && !strings.HasPrefix(line, "#") {
			samples++
		}
	}
	if response.StatusCode < 200 || response.StatusCode >= 300 {
		return response.StatusCode, samples, fmt.Errorf("HTTP status %d", response.StatusCode)
	}
	if samples == 0 {
		return response.StatusCode, 0, fmt.Errorf("endpoint returned no metric samples")
	}
	return response.StatusCode, samples, scanner.Err()
}

func collectBeat(name string, services []model.ServiceInfo, outputTestTimeout time.Duration) (model.BeatInfo, []string) {
	info := model.BeatInfo{
		ComponentInfo: model.ComponentInfo{Name: name, ConfigFiles: []string{}, ServiceNames: []string{}},
		Outputs:       []string{},
		OutputDetails: []model.BeatOutputInfo{},
		Modules:       []string{},
	}
	warnings := []string{}
	_, binaryPath := firstExecutable(name)
	info.BinaryPath = binaryPath
	packageName, packageVersion := packageVersion(name)
	info.PackageName, info.PackageVersion = packageName, packageVersion
	info.Installed = binaryPath != "" || packageVersion != ""
	if binaryPath != "" {
		output, err := commandOutput(5*time.Second, binaryPath, "version")
		if err == nil || output != "" {
			info.Version = normalizeVersionOutput(output)
		}
	}
	if info.Version == "" {
		info.Version = packageVersion
	}
	serviceName, active, enabled := serviceState(services, name)
	if serviceName != "" {
		info.ServiceNames = []string{serviceName}
		info.ServiceActive = active
		info.ServiceEnabled = enabled
	}
	mainConfig := "/etc/" + name + "/" + name + ".yml"
	info.ConfigFiles = existingFiles(mainConfig, "/etc/"+name+"/*.yml", "/etc/"+name+"/*.yaml")
	info.Configured = firstExisting(mainConfig) != ""
	for _, configPath := range info.ConfigFiles {
		outputs, modules, outputDetails := parseBeatConfig(configPath)
		info.Outputs = append(info.Outputs, outputs...)
		info.Modules = append(info.Modules, modules...)
		info.OutputDetails = append(info.OutputDetails, outputDetails...)
	}
	moduleFiles := existingFiles("/etc/"+name+"/modules.d/*.yml", "/etc/"+name+"/modules.d/*.yaml")
	for _, path := range moduleFiles {
		info.Modules = append(info.Modules, strings.TrimSuffix(strings.TrimSuffix(filepath.Base(path), ".yml"), ".yaml"))
	}
	info.Outputs = uniqueSorted(info.Outputs)
	info.OutputDetails = uniqueBeatOutputs(info.OutputDetails)
	info.Modules = uniqueSorted(info.Modules)
	if binaryPath != "" && info.Configured {
		output, err := commandOutput(10*time.Second, binaryPath, "test", "config", "-c", mainConfig)
		valid := err == nil
		info.ConfigValid = boolPtr(valid)
		info.ConfigCheckOutput = truncateString(sanitizeBeatText(output), 1500)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("%s: config validation: %v", name, err))
		}

		if outputTestTimeout <= 0 {
			outputTestTimeout = 12 * time.Second
		}
		output, err = commandOutput(outputTestTimeout, binaryPath, "test", "output", "-c", mainConfig)
		outputOK := err == nil
		info.OutputTestOK = boolPtr(outputOK)
		info.OutputTestOutput = truncateString(sanitizeBeatText(output), 2500)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("%s: output validation: %v", name, err))
		}
	}
	return info, warnings
}

type beatYAMLPath struct {
	indent int
	key    string
}

func parseBeatConfig(path string) ([]string, []string, []model.BeatOutputInfo) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, nil, nil
	}
	lines := strings.Split(string(data), "\n")
	outputs := []string{}
	modules := []string{}
	outputDetails := []model.BeatOutputInfo{}
	outputPattern := regexp.MustCompile(`^\s*output\.([A-Za-z0-9_-]+)\s*:\s*(.*)$`)
	modulePattern := regexp.MustCompile(`^\s*-?\s*module\s*:\s*['\"]?([^'\"#\s]+)`)
	keyPattern := regexp.MustCompile(`^\s*([A-Za-z0-9_.-]+)\s*:\s*(.*)$`)

	for index := 0; index < len(lines); index++ {
		raw := lines[index]
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if matches := modulePattern.FindStringSubmatch(raw); len(matches) == 2 {
			modules = append(modules, matches[1])
		}
		matches := outputPattern.FindStringSubmatch(raw)
		if len(matches) != 3 {
			continue
		}

		outputType := strings.ToLower(matches[1])
		outputs = append(outputs, outputType)
		detail := model.BeatOutputInfo{Type: outputType, Hosts: []string{}, CertificateAuthorities: []string{}, SourceFile: path}
		baseIndent := leadingYAMLIndent(raw)
		stack := []beatYAMLPath{}
		lastIndex := index

		for next := index + 1; next < len(lines); next++ {
			childRaw := lines[next]
			childLine := strings.TrimSpace(childRaw)
			if childLine == "" || strings.HasPrefix(childLine, "#") {
				lastIndex = next
				continue
			}
			indent := leadingYAMLIndent(childRaw)
			if indent <= baseIndent {
				break
			}
			lastIndex = next

			for len(stack) > 0 && stack[len(stack)-1].indent >= indent {
				stack = stack[:len(stack)-1]
			}

			if strings.HasPrefix(childLine, "-") {
				if len(stack) > 0 {
					value := parseYAMLScalar(strings.TrimSpace(strings.TrimPrefix(childLine, "-")))
					applyBeatOutputValue(&detail, beatPath(stack), value, true)
				}
				continue
			}

			keyMatch := keyPattern.FindStringSubmatch(childRaw)
			if len(keyMatch) != 3 {
				continue
			}
			key := strings.ToLower(strings.TrimSpace(keyMatch[1]))
			value := strings.TrimSpace(stripYAMLComment(keyMatch[2]))
			pathParts := append([]beatYAMLPath{}, stack...)
			fullPath := beatPath(append(pathParts, beatYAMLPath{indent: indent, key: key}))
			if value == "" {
				stack = append(stack, beatYAMLPath{indent: indent, key: key})
				continue
			}
			for _, item := range parseYAMLValues(value) {
				applyBeatOutputValue(&detail, fullPath, item, false)
			}
		}
		index = lastIndex
		detail.Hosts = uniqueSorted(detail.Hosts)
		detail.CertificateAuthorities = uniqueSorted(detail.CertificateAuthorities)
		outputDetails = append(outputDetails, detail)
	}
	return uniqueSorted(outputs), uniqueSorted(modules), uniqueBeatOutputs(outputDetails)
}

func leadingYAMLIndent(value string) int {
	count := 0
	for _, char := range value {
		switch char {
		case ' ':
			count++
		case '\t':
			count += 2
		default:
			return count
		}
	}
	return count
}

func beatPath(stack []beatYAMLPath) string {
	parts := make([]string, 0, len(stack))
	for _, item := range stack {
		parts = append(parts, strings.ToLower(item.key))
	}
	return strings.Join(parts, ".")
}

func stripYAMLComment(value string) string {
	quote := rune(0)
	escaped := false
	for index, char := range value {
		if escaped {
			escaped = false
			continue
		}
		if char == '\\' && quote == '"' {
			escaped = true
			continue
		}
		if char == '\'' || char == '"' {
			if quote == 0 {
				quote = char
			} else if quote == char {
				quote = 0
			}
			continue
		}
		if char == '#' && quote == 0 {
			return strings.TrimSpace(value[:index])
		}
	}
	return strings.TrimSpace(value)
}

func parseYAMLValues(value string) []string {
	value = strings.TrimSpace(stripYAMLComment(value))
	if strings.HasPrefix(value, "[") && strings.HasSuffix(value, "]") {
		inside := strings.TrimSpace(value[1 : len(value)-1])
		if inside == "" {
			return nil
		}
		parts := []string{}
		start := 0
		quote := rune(0)
		for index, char := range inside {
			if char == '\'' || char == '"' {
				if quote == 0 {
					quote = char
				} else if quote == char {
					quote = 0
				}
			}
			if char == ',' && quote == 0 {
				parts = append(parts, parseYAMLScalar(inside[start:index]))
				start = index + 1
			}
		}
		parts = append(parts, parseYAMLScalar(inside[start:]))
		return parts
	}
	return []string{parseYAMLScalar(value)}
}

func parseYAMLScalar(value string) string {
	value = strings.TrimSpace(stripYAMLComment(value))
	value = strings.TrimSuffix(value, ",")
	if len(value) >= 2 {
		if (value[0] == '"' && value[len(value)-1] == '"') || (value[0] == '\'' && value[len(value)-1] == '\'') {
			value = value[1 : len(value)-1]
		}
	}
	return strings.TrimSpace(value)
}

func applyBeatOutputValue(detail *model.BeatOutputInfo, key, value string, listItem bool) {
	key = strings.ToLower(strings.ReplaceAll(strings.TrimSpace(key), "-", "_"))
	value = strings.TrimSpace(value)
	if value == "" || isSensitiveKey(key) {
		return
	}
	switch key {
	case "enabled":
		if parsed, ok := parseLooseBool(value); ok {
			detail.Enabled = boolPtr(parsed)
		}
	case "hosts", "host":
		detail.Hosts = append(detail.Hosts, sanitizeBeatEndpoint(value))
	case "protocol":
		detail.Protocol = value
	case "index":
		detail.Index = value
	case "pipeline":
		detail.Pipeline = value
	case "topic":
		detail.Topic = value
	case "key":
		detail.Key = value
	case "path":
		detail.Path = value
	case "filename":
		detail.Filename = value
	case "loadbalance", "load_balance":
		if parsed, ok := parseLooseBool(value); ok {
			detail.LoadBalance = boolPtr(parsed)
		}
	case "worker", "workers":
		if parsed, err := strconv.Atoi(value); err == nil {
			detail.Workers = &parsed
		}
	case "ssl.enabled":
		if parsed, ok := parseLooseBool(value); ok {
			detail.SSLEnabled = boolPtr(parsed)
		}
	case "ssl.verification_mode":
		detail.SSLVerificationMode = value
	case "ssl.certificate_authorities":
		detail.CertificateAuthorities = append(detail.CertificateAuthorities, value)
	default:
		_ = listItem
	}
}

func parseLooseBool(value string) (bool, bool) {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "true", "yes", "on", "1":
		return true, true
	case "false", "no", "off", "0":
		return false, true
	default:
		return false, false
	}
}

func sanitizeBeatEndpoint(value string) string {
	value = strings.TrimSpace(value)
	urlCredentials := regexp.MustCompile(`(?i)([a-z][a-z0-9+.-]*://)([^/@\s]+)@`)
	value = urlCredentials.ReplaceAllString(value, `${1}<redacted>@`)
	plainCredentials := regexp.MustCompile(`^([^@\s]+)@([^@\s]+)$`)
	if !strings.Contains(value, "://") && plainCredentials.MatchString(value) && strings.Contains(strings.SplitN(value, "@", 2)[0], ":") {
		parts := strings.SplitN(value, "@", 2)
		value = "<redacted>@" + parts[1]
	}
	return value
}

func sanitizeBeatText(value string) string {
	value = sanitizeConfigLine(value)
	urlCredentials := regexp.MustCompile(`(?i)([a-z][a-z0-9+.-]*://)([^/@\s]+)@`)
	value = urlCredentials.ReplaceAllString(value, `${1}<redacted>@`)
	secretAssignment := regexp.MustCompile(`(?i)(password|passwd|secret|token|api[_-]?key|access[_-]?key|authtok)(\s*[:=]\s*)([^\s,;]+)`)
	value = secretAssignment.ReplaceAllString(value, `${1}${2}<redacted>`)
	return value
}

func uniqueBeatOutputs(values []model.BeatOutputInfo) []model.BeatOutputInfo {
	seen := map[string]bool{}
	result := []model.BeatOutputInfo{}
	for _, value := range values {
		value.Hosts = uniqueSorted(value.Hosts)
		value.CertificateAuthorities = uniqueSorted(value.CertificateAuthorities)
		key := value.Type + "|" + value.SourceFile + "|" + strings.Join(value.Hosts, ",") + "|" + value.Path + "|" + value.Filename + "|" + value.Topic
		if value.Type != "" && !seen[key] {
			seen[key] = true
			result = append(result, value)
		}
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].Type != result[j].Type {
			return result[i].Type < result[j].Type
		}
		return result[i].SourceFile < result[j].SourceFile
	})
	return result
}

func collectSyslog(services []model.ServiceInfo) (model.SyslogInfo, []string) {
	info := model.SyslogInfo{ConfigFiles: []string{}, RemoteDestinations: []model.SyslogRemote{}}
	warnings := []string{}
	implementation := ""
	binaryPath := ""
	for _, candidate := range []string{"rsyslogd", "syslog-ng"} {
		if path, err := exec.LookPath(candidate); err == nil {
			implementation, binaryPath = candidate, path
			break
		}
	}
	packageName, packageVer := packageVersion("rsyslog", "syslog-ng")
	info.Installed = binaryPath != "" || packageVer != ""
	if implementation == "" {
		if strings.Contains(packageName, "rsyslog") {
			implementation = "rsyslogd"
		}
		if strings.Contains(packageName, "syslog-ng") {
			implementation = "syslog-ng"
		}
	}
	info.Implementation = implementation
	if binaryPath != "" {
		args := []string{"-v"}
		if implementation == "syslog-ng" {
			args = []string{"--version"}
		}
		output, _ := commandOutput(5*time.Second, binaryPath, args...)
		info.Version = normalizeVersionOutput(output)
	}
	if info.Version == "" {
		info.Version = packageVer
	}
	serviceCandidates := []string{"rsyslog", "syslog-ng", "syslog"}
	info.ServiceName, info.ServiceActive, info.ServiceEnabled = serviceState(services, serviceCandidates...)
	info.ConfigFiles = existingFiles(
		"/etc/rsyslog.conf", "/etc/rsyslog.d/*.conf", "/etc/syslog-ng/syslog-ng.conf", "/etc/syslog-ng/conf.d/*.conf", "/etc/syslog.conf",
	)
	for _, path := range info.ConfigFiles {
		destinations, err := parseSyslogDestinations(path)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("syslog: read %s: %v", path, err))
			continue
		}
		info.RemoteDestinations = append(info.RemoteDestinations, destinations...)
	}
	info.RemoteDestinations = uniqueSyslogDestinations(info.RemoteDestinations)
	info.ConfiguredRemote = len(info.RemoteDestinations) > 0
	return info, warnings
}

func parseSyslogDestinations(path string) ([]model.SyslogRemote, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	result := []model.SyslogRemote{}
	legacy := regexp.MustCompile(`(?:^|\s)(@@?)(\[[^\]]+\]|[A-Za-z0-9_.:-]+)(?::([0-9]+))?`)
	target := regexp.MustCompile(`(?i)target\s*=\s*"([^"]+)"`)
	port := regexp.MustCompile(`(?i)port\s*=\s*"?([0-9]+)"?`)
	syslogNG := regexp.MustCompile(`(?i)(tcp|udp|network|syslog)\s*\(\s*"([^"]+)"`)
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		for _, match := range legacy.FindAllStringSubmatch(line, -1) {
			protocol := "udp"
			if match[1] == "@@" {
				protocol = "tcp"
			}
			host := strings.Trim(match[2], "[]")
			if net.ParseIP(host) != nil || strings.ContainsAny(host, ".:") || host == "localhost" {
				result = append(result, model.SyslogRemote{Protocol: protocol, Host: host, Port: match[3], Source: path})
			}
		}
		if strings.Contains(strings.ToLower(line), "omfwd") {
			hostMatch := target.FindStringSubmatch(line)
			if len(hostMatch) == 2 {
				portValue := ""
				if p := port.FindStringSubmatch(line); len(p) == 2 {
					portValue = p[1]
				}
				protocol := "tcp"
				if strings.Contains(strings.ToLower(line), `protocol="udp"`) {
					protocol = "udp"
				}
				result = append(result, model.SyslogRemote{Protocol: protocol, Host: hostMatch[1], Port: portValue, Source: path})
			}
		}
		if match := syslogNG.FindStringSubmatch(line); len(match) == 3 {
			portValue := ""
			if p := port.FindStringSubmatch(line); len(p) == 2 {
				portValue = p[1]
			}
			result = append(result, model.SyslogRemote{Protocol: strings.ToLower(match[1]), Host: match[2], Port: portValue, Source: path})
		}
	}
	return result, nil
}

func uniqueSyslogDestinations(values []model.SyslogRemote) []model.SyslogRemote {
	seen := map[string]bool{}
	result := []model.SyslogRemote{}
	for _, value := range values {
		key := value.Protocol + "|" + value.Host + "|" + value.Port + "|" + value.Source
		if value.Host != "" && !seen[key] {
			seen[key] = true
			result = append(result, value)
		}
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].Host != result[j].Host {
			return result[i].Host < result[j].Host
		}
		if result[i].Port != result[j].Port {
			return result[i].Port < result[j].Port
		}
		return result[i].Source < result[j].Source
	})
	return result
}
