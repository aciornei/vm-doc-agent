package collector

import (
	"fmt"
	"os"
	"regexp"
	"sort"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectNTP(services []model.ServiceInfo) (model.NTPInfo, []string) {
	info := model.NTPInfo{Servers: []model.NTPServerInfo{}, ConfigFiles: []string{}, TrackingSummary: map[string]string{}}
	warnings := []string{}

	implementation, binaryPath := detectNTPImplementation()
	info.Implementation = implementation
	info.Installed = implementation != ""
	if binaryPath != "" {
		args := []string{"--version"}
		if implementation == "ntpd" {
			args = []string{"--version"}
		}
		if implementation == "systemd-timesyncd" {
			args = []string{"--version"}
		}
		output, _ := commandOutput(4*time.Second, binaryPath, args...)
		info.Version = normalizeVersionOutput(output)
	}
	if info.Version == "" {
		_, packageVersion := packageVersion("chrony", "ntp", "ntpsec", "systemd-timesyncd")
		info.Version = packageVersion
	}

	switch implementation {
	case "chrony":
		info.ServiceName, info.ServiceActive, info.ServiceEnabled = serviceState(services, "chronyd", "chrony")
		info.ConfigFiles = existingFiles("/etc/chrony.conf", "/etc/chrony/chrony.conf", "/etc/chrony/conf.d/*.conf", "/etc/chrony/sources.d/*.sources")
		servers, current, synchronized, tracking, collectWarnings := collectChronyStatus()
		info.Servers = append(info.Servers, servers...)
		info.CurrentSource = current
		info.Synchronized = synchronized
		info.TrackingSummary = tracking
		warnings = append(warnings, collectWarnings...)
	case "ntpd", "ntpsec":
		info.ServiceName, info.ServiceActive, info.ServiceEnabled = serviceState(services, "ntpd", "ntp", "ntpsec")
		info.ConfigFiles = existingFiles("/etc/ntp.conf", "/etc/ntpsec/ntp.conf", "/etc/ntp/*.conf")
		servers, current, synchronized, collectWarnings := collectNTPQStatus()
		info.Servers = append(info.Servers, servers...)
		info.CurrentSource = current
		info.Synchronized = synchronized
		warnings = append(warnings, collectWarnings...)
	case "systemd-timesyncd":
		info.ServiceName, info.ServiceActive, info.ServiceEnabled = serviceState(services, "systemd-timesyncd")
		info.ConfigFiles = existingFiles("/etc/systemd/timesyncd.conf", "/etc/systemd/timesyncd.conf.d/*.conf")
	}

	configuredServers := parseNTPConfigFiles(info.ConfigFiles)
	info.Servers = mergeNTPServers(info.Servers, configuredServers)
	if syncValue, ok := timedatectlSynchronized(); ok {
		info.Synchronized = boolPtr(syncValue)
	}
	if info.CurrentSource == "" {
		if output, err := commandOutput(3*time.Second, "timedatectl", "show-timesync", "--property=ServerName", "--value"); err == nil {
			info.CurrentSource = strings.TrimSpace(output)
		}
	}
	return info, warnings
}

func detectNTPImplementation() (string, string) {
	if _, path := firstExecutable("chronyd"); path != "" {
		return "chrony", path
	}
	if _, path := firstExecutable("ntpd"); path != "" {
		if _, packageVersion := packageVersion("ntpsec"); packageVersion != "" {
			return "ntpsec", path
		}
		return "ntpd", path
	}
	if path := firstExisting("/usr/lib/systemd/system/systemd-timesyncd.service", "/lib/systemd/system/systemd-timesyncd.service"); path != "" {
		if _, binary := firstExecutable("systemd-timesyncd"); binary != "" {
			return "systemd-timesyncd", binary
		}
		return "systemd-timesyncd", ""
	}
	return "", ""
}

func collectChronyStatus() ([]model.NTPServerInfo, string, *bool, map[string]string, []string) {
	servers := []model.NTPServerInfo{}
	tracking := map[string]string{}
	warnings := []string{}
	current := ""
	var synchronized *bool
	if _, path := firstExecutable("chronyc"); path == "" {
		return servers, current, synchronized, tracking, warnings
	}
	if output, err := commandOutput(5*time.Second, "chronyc", "tracking"); err == nil || output != "" {
		for _, raw := range strings.Split(output, "\n") {
			parts := strings.SplitN(raw, ":", 2)
			if len(parts) != 2 {
				continue
			}
			key := strings.TrimSpace(parts[0])
			value := strings.TrimSpace(parts[1])
			if key != "" {
				tracking[key] = value
			}
			if key == "Reference ID" || key == "Reference name" {
				if current == "" {
					current = value
				}
			}
			if key == "Leap status" {
				valueLower := strings.ToLower(value)
				synchronized = boolPtr(!strings.Contains(valueLower, "not synchronised") && !strings.Contains(valueLower, "unsynchronised"))
			}
		}
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("ntp: chronyc tracking: %v", err))
		}
	}
	if output, err := commandOutput(5*time.Second, "chronyc", "sources", "-n"); err == nil || output != "" {
		for _, raw := range strings.Split(output, "\n") {
			line := strings.TrimSpace(raw)
			if len(line) < 3 {
				continue
			}
			marker := line[0]
			if marker != '^' && marker != '=' && marker != '#' {
				continue
			}
			state := byte('?')
			if len(line) > 1 {
				state = line[1]
			}
			fields := strings.Fields(line[2:])
			if len(fields) == 0 {
				continue
			}
			address := fields[0]
			selected := state == '*'
			reachable := state != '?' && state != 'x' && state != '~'
			serverType := "server"
			if marker == '=' {
				serverType = "peer"
			}
			servers = append(servers, model.NTPServerInfo{Address: address, Type: serverType, Selected: selected, Reachable: boolPtr(reachable), Source: "chronyc"})
			if selected {
				current = address
				synchronized = boolPtr(true)
			}
		}
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("ntp: chronyc sources: %v", err))
		}
	}
	return servers, current, synchronized, tracking, warnings
}

func collectNTPQStatus() ([]model.NTPServerInfo, string, *bool, []string) {
	servers := []model.NTPServerInfo{}
	warnings := []string{}
	current := ""
	var synchronized *bool
	if _, path := firstExecutable("ntpq"); path == "" {
		return servers, current, synchronized, warnings
	}
	output, err := commandOutput(5*time.Second, "ntpq", "-pn")
	if err != nil && output == "" {
		return servers, current, synchronized, []string{fmt.Sprintf("ntp: ntpq -pn: %v", err)}
	}
	for _, raw := range strings.Split(output, "\n") {
		line := strings.TrimSpace(raw)
		if line == "" || strings.HasPrefix(line, "remote") || strings.HasPrefix(line, "====") {
			continue
		}
		marker := line[0]
		if !strings.ContainsRune("*+#-x.o", rune(marker)) && (marker < '0' || marker > '9') {
			continue
		}
		if marker >= '0' && marker <= '9' {
			marker = ' '
			line = " " + line
		}
		fields := strings.Fields(line[1:])
		if len(fields) < 1 {
			continue
		}
		address := strings.TrimPrefix(fields[0], "o")
		selected := marker == '*' || marker == 'o'
		reachable := marker != ' ' && marker != 'x' && marker != '-'
		servers = append(servers, model.NTPServerInfo{Address: address, Type: "server", Selected: selected, Reachable: boolPtr(reachable), Source: "ntpq"})
		if selected {
			current = address
			synchronized = boolPtr(true)
		}
	}
	if synchronized == nil {
		synchronized = boolPtr(false)
	}
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("ntp: ntpq -pn: %v", err))
	}
	return servers, current, synchronized, warnings
}

func parseNTPConfigFiles(paths []string) []model.NTPServerInfo {
	result := []model.NTPServerInfo{}
	serverPattern := regexp.MustCompile(`(?i)^\s*(server|pool|peer)\s+([^\s#]+)`)
	for _, path := range paths {
		data, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		for _, raw := range strings.Split(string(data), "\n") {
			line := strings.TrimSpace(raw)
			if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
				continue
			}
			if match := serverPattern.FindStringSubmatch(line); len(match) == 3 {
				result = append(result, model.NTPServerInfo{Address: match[2], Type: strings.ToLower(match[1]), Selected: false, Source: path})
			}
			if strings.HasPrefix(strings.ToUpper(line), "NTP=") || strings.HasPrefix(strings.ToUpper(line), "FALLBACKNTP=") {
				parts := strings.SplitN(line, "=", 2)
				if len(parts) == 2 {
					for _, address := range strings.Fields(parts[1]) {
						result = append(result, model.NTPServerInfo{Address: address, Type: "server", Source: path})
					}
				}
			}
		}
	}
	return result
}

func timedatectlSynchronized() (bool, bool) {
	if _, path := firstExecutable("timedatectl"); path == "" {
		return false, false
	}
	output, err := commandOutput(3*time.Second, "timedatectl", "show", "--property=NTPSynchronized", "--value")
	if err != nil {
		return false, false
	}
	switch strings.ToLower(strings.TrimSpace(output)) {
	case "yes", "true", "1":
		return true, true
	case "no", "false", "0":
		return false, true
	default:
		return false, false
	}
}

func mergeNTPServers(groups ...[]model.NTPServerInfo) []model.NTPServerInfo {
	seen := map[string]int{}
	result := []model.NTPServerInfo{}
	for _, group := range groups {
		for _, item := range group {
			key := strings.ToLower(item.Address + "|" + item.Type)
			if index, ok := seen[key]; ok {
				if item.Selected {
					result[index].Selected = true
				}
				if item.Reachable != nil {
					result[index].Reachable = item.Reachable
				}
				if result[index].Source == "" {
					result[index].Source = item.Source
				}
				continue
			}
			seen[key] = len(result)
			result = append(result, item)
		}
	}
	sort.Slice(result, func(i, j int) bool {
		if result[i].Selected != result[j].Selected {
			return result[i].Selected
		}
		return result[i].Address < result[j].Address
	})
	return result
}
