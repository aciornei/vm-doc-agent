package collector

import "testing"

func TestParseProcEndpointIPv4(t *testing.T) {
	address, port, err := parseProcEndpoint("0100007F:2386", "ipv4")
	if err != nil {
		t.Fatal(err)
	}
	if address != "127.0.0.1" || port != 9094 {
		t.Fatalf("got %s:%d, want 127.0.0.1:9094", address, port)
	}
}

func TestParseProcIPAddressIPv6Loopback(t *testing.T) {
	address, err := parseProcIPAddress("00000000000000000000000001000000", "ipv6")
	if err != nil {
		t.Fatal(err)
	}
	if address != "::1" {
		t.Fatalf("got %q, want ::1", address)
	}
}
