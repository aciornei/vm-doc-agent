package collector

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"sort"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

func collectSSSD(services []model.ServiceInfo) (model.SSSDInfo, []string) {
	info := model.SSSDInfo{Domains: []model.SSSDDomainInfo{}, SafeGlobalOptions: map[string]string{}}
	warnings := []string{}
	_, binaryPath := firstExecutable("sssd")
	packageName, packageVersion := packageVersion("sssd", "sssd-common")
	info.BinaryPath = binaryPath
	info.Installed = binaryPath != "" || packageVersion != ""
	if binaryPath != "" {
		output, err := commandOutput(3*time.Second, binaryPath, "--version")
		if err == nil || output != "" {
			info.Version = normalizeVersionOutput(output)
		}
	}
	if info.Version == "" {
		info.Version = packageVersion
	}
	_ = packageName
	info.ServiceName, info.ServiceActive, info.ServiceEnabled = serviceState(services, "sssd", "sssd.service")

	configPath := firstExisting("/etc/sssd/sssd.conf")
	if configPath == "" {
		return info, warnings
	}
	info.ConfigPresent = true
	info.ConfigPath = configPath
	if fileInfo, err := os.Stat(configPath); err == nil {
		info.ConfigPermissions = fileInfo.Mode().Perm().String()
		info.ConfigOwner = fileOwner(fileInfo)
	}
	sections, err := parseINI(configPath)
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("sssd: parse %s: %v", configPath, err))
	} else {
		globalSafe := []string{"services", "domains", "config_file_version", "reconnection_retries", "sbus_timeout", "debug_level"}
		for _, key := range globalSafe {
			if value := sections["sssd"][key]; value != "" {
				info.SafeGlobalOptions[key] = sanitizeConfigLine(value)
			}
		}
		info.Services = splitCSVWords(sections["sssd"]["services"])
		domainNames := splitCSVWords(sections["sssd"]["domains"])
		if len(domainNames) == 0 {
			for section := range sections {
				if strings.HasPrefix(strings.ToLower(section), "domain/") {
					domainNames = append(domainNames, strings.TrimSpace(section[len("domain/"):]))
				}
			}
		}
		domainNames = uniqueSorted(domainNames)
		safeDomainKeys := []string{
			"id_provider", "auth_provider", "access_provider", "chpass_provider", "sudo_provider", "autofs_provider",
			"ad_domain", "krb5_realm", "ldap_uri", "ldap_search_base", "ldap_user_search_base", "ldap_group_search_base",
			"cache_credentials", "enumerate", "use_fully_qualified_names", "fallback_homedir", "override_homedir",
			"default_shell", "shell_fallback", "dyndns_update", "ad_hostname", "simple_allow_groups", "simple_deny_groups",
		}
		for _, domainName := range domainNames {
			section := sections["domain/"+domainName]
			if section == nil {
				for sectionName, values := range sections {
					if strings.EqualFold(sectionName, "domain/"+domainName) {
						section = values
						break
					}
				}
			}
			options := map[string]string{}
			for _, key := range safeDomainKeys {
				if value := section[key]; value != "" {
					options[key] = sanitizeConfigLine(value)
				}
			}
			info.Domains = append(info.Domains, model.SSSDDomainInfo{Name: domainName, SafeOptions: options})
		}
	}

	sortSSSDDomains(info.Domains)
	if path, err := exec.LookPath("sssctl"); err == nil {
		output, commandErr := commandOutput(5*time.Second, path, "config-check")
		valid := commandErr == nil
		info.ConfigValid = boolPtr(valid)
		info.ConfigCheckMessage = truncateString(sanitizeConfigLine(output), 1000)
		if commandErr != nil {
			warnings = append(warnings, fmt.Sprintf("sssd: config-check: %v", commandErr))
		}
	}
	return info, warnings
}

func parseINI(path string) (map[string]map[string]string, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()
	result := map[string]map[string]string{}
	section := ""
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, ";") {
			continue
		}
		if strings.HasPrefix(line, "[") && strings.HasSuffix(line, "]") {
			section = strings.TrimSpace(line[1 : len(line)-1])
			if result[section] == nil {
				result[section] = map[string]string{}
			}
			continue
		}
		parts := strings.SplitN(line, "=", 2)
		if len(parts) != 2 || section == "" {
			continue
		}
		key := strings.ToLower(strings.TrimSpace(parts[0]))
		value := strings.TrimSpace(parts[1])
		if isSensitiveKey(key) {
			continue
		}
		result[section][key] = value
	}
	return result, scanner.Err()
}

func isSensitiveKey(key string) bool {
	lower := strings.ToLower(key)
	for _, marker := range []string{"password", "passwd", "secret", "token", "authtok", "private_key", "bind_pw", "bind_password"} {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}

func splitCSVWords(value string) []string {
	value = strings.ReplaceAll(value, ",", " ")
	return strings.Fields(value)
}

func truncateString(value string, limit int) string {
	value = strings.TrimSpace(value)
	if len(value) <= limit {
		return value
	}
	return value[:limit] + "..."
}

func sortSSSDDomains(domains []model.SSSDDomainInfo) {
	sort.Slice(domains, func(i, j int) bool { return domains[i].Name < domains[j].Name })
}
