package collector

import "testing"

func TestParseInterfaceAddress(t *testing.T) {
	got, ok := parseInterfaceAddress("172.20.7.50/24")
	if !ok {
		t.Fatal("parseInterfaceAddress returned false")
	}
	if got.Address != "172.20.7.50" || got.Family != "ipv4" || got.PrefixLength != 24 || got.Scope != "private" {
		t.Fatalf("unexpected parsed address: %+v", got)
	}
}
