package config

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLoad(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.json")
	content := `{"listen":"127.0.0.1:19078","output_file":"/tmp/inventory.json","state_dir":"/tmp/state","refresh_interval":"30m","auth_token_file":"/tmp/token"}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Listen != "127.0.0.1:19078" || cfg.Refresh != 30*time.Minute {
		t.Fatalf("unexpected config: %+v", cfg)
	}
}

func TestUnknownFieldFails(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.json")
	if err := os.WriteFile(path, []byte(`{"unknown":true}`), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := Load(path); err == nil {
		t.Fatal("expected error")
	}
}

func TestOldConfigurationGetsVersionOneDefaults(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.json")
	content := `{"listen":"127.0.0.1:9078","output_file":"/tmp/inventory.json","state_dir":"/tmp/state","refresh_interval":"15m","auth_token_file":"/tmp/token"}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if !cfg.Collectors.Network || !cfg.Collectors.Integrations || cfg.CollectorTimeout != 20*time.Second {
		t.Fatalf("defaults were not applied: %+v", cfg)
	}
	if cfg.Limits.MaxInventoryBytes != 20*1024*1024 {
		t.Fatalf("unexpected size limit: %d", cfg.Limits.MaxInventoryBytes)
	}
}

func TestCollectorCanBeDisabled(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.json")
	content := `{"output_file":"/tmp/inventory.json","state_dir":"/tmp/state","auth_token_file":"/tmp/token","collectors":{"cron":false,"network":false}}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Collectors.Cron || cfg.Collectors.Network {
		t.Fatalf("collectors should be disabled: %+v", cfg.Collectors)
	}
	if !cfg.Collectors.Storage {
		t.Fatal("unspecified collector should keep default")
	}
}

func TestCentralConfiguration(t *testing.T) {
	path := filepath.Join(t.TempDir(), "config.json")
	content := `{
		"output_file":"/tmp/inventory.json",
		"state_dir":"/tmp/state",
		"auth_token_file":"/tmp/token",
		"central":{
			"enabled":true,
			"url":"http://127.0.0.1:9080",
			"allow_http":true,
			"registration_token_file":"/tmp/registration-token",
			"heartbeat_interval":"5m",
			"retry_interval":"1m",
			"request_timeout":"20s"
		}
	}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if !cfg.Central.Enabled || cfg.Central.URL != "http://127.0.0.1:9080" || cfg.Central.AgentCollectionInterval != cfg.Refresh {
		t.Fatalf("unexpected central config: %+v", cfg.Central)
	}
}

func TestUpdatesDefaultOnWhenCentralEnabledAndSectionMissing(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	content := `{"listen":"127.0.0.1:19078","output_file":"` + filepath.Join(dir, "inventory.json") + `","state_dir":"` + filepath.Join(dir, "state") + `","refresh_interval":"24h","auth_token_file":"` + filepath.Join(dir, "token") + `","central":{"enabled":true,"url":"http://172.20.1.20:9080","registration_token_file":"` + filepath.Join(dir, "registration") + `","allow_http":true}}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if !cfg.Updates.Enabled || !cfg.Updates.AutoInstall {
		t.Fatalf("expected updates enabled by default for central agent: %+v", cfg.Updates)
	}
}

func TestUpdatesRemainDisabledForLegacyStandaloneConfig(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	content := `{"listen":"127.0.0.1:19078","output_file":"` + filepath.Join(dir, "inventory.json") + `","state_dir":"` + filepath.Join(dir, "state") + `","refresh_interval":"24h","auth_token_file":"` + filepath.Join(dir, "token") + `"}`
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load(path)
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Updates.Enabled {
		t.Fatalf("expected updates disabled for standalone legacy config: %+v", cfg.Updates)
	}
}
