package config

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const DefaultPath = "/etc/vm-doc-agent/config.json"

type FileConfig struct {
	Listen            string                `json:"listen"`
	OutputFile        string                `json:"output_file"`
	StateDir          string                `json:"state_dir"`
	Refresh           string                `json:"refresh_interval"`
	AuthTokenFile     string                `json:"auth_token_file"`
	PolicyPaths       []string              `json:"policy_paths,omitempty"`
	CollectorTimeout  string                `json:"collector_timeout,omitempty"`
	OutputTestTimeout string                `json:"output_test_timeout,omitempty"`
	Collectors        *FileCollectorToggles `json:"collectors,omitempty"`
	Limits            *FileLimits           `json:"limits,omitempty"`
	Central           *FileCentralConfig    `json:"central,omitempty"`
	Updates           *FileUpdateConfig     `json:"updates,omitempty"`
}

type FileCentralConfig struct {
	Enabled               *bool  `json:"enabled,omitempty"`
	URL                   string `json:"url,omitempty"`
	RegistrationTokenFile string `json:"registration_token_file,omitempty"`
	HeartbeatInterval     string `json:"heartbeat_interval,omitempty"`
	RetryInterval         string `json:"retry_interval,omitempty"`
	RequestTimeout        string `json:"request_timeout,omitempty"`
	AdvertiseURL          string `json:"advertise_url,omitempty"`
	CAFile                string `json:"ca_file,omitempty"`
	TLSServerName         string `json:"tls_server_name,omitempty"`
	InsecureSkipVerify    *bool  `json:"insecure_skip_verify,omitempty"`
	AllowHTTP             *bool  `json:"allow_http,omitempty"`
}

type FileUpdateConfig struct {
	Enabled          *bool  `json:"enabled,omitempty"`
	Channel          string `json:"channel,omitempty"`
	CheckInterval    string `json:"check_interval,omitempty"`
	AutoInstall      *bool  `json:"auto_install,omitempty"`
	Endpoint         string `json:"endpoint,omitempty"`
	DownloadDir      string `json:"download_dir,omitempty"`
	HealthTimeout    string `json:"health_timeout,omitempty"`
	MaxDownloadBytes *int64 `json:"max_download_bytes,omitempty"`
}

type FileCollectorToggles struct {
	System         *bool `json:"system,omitempty"`
	Storage        *bool `json:"storage,omitempty"`
	Network        *bool `json:"network,omitempty"`
	Proxy          *bool `json:"proxy,omitempty"`
	Services       *bool `json:"services,omitempty"`
	ListeningPorts *bool `json:"listening_ports,omitempty"`
	Firewall       *bool `json:"firewall,omitempty"`
	Accounts       *bool `json:"accounts,omitempty"`
	SSSD           *bool `json:"sssd,omitempty"`
	Integrations   *bool `json:"integrations,omitempty"`
	Policies       *bool `json:"policies,omitempty"`
	Cron           *bool `json:"cron,omitempty"`
	NTP            *bool `json:"ntp,omitempty"`
}

type FileLimits struct {
	MaxPartitions     *int `json:"max_partitions,omitempty"`
	MaxRoutes         *int `json:"max_routes,omitempty"`
	MaxServices       *int `json:"max_services,omitempty"`
	MaxPorts          *int `json:"max_ports,omitempty"`
	MaxFirewallRules  *int `json:"max_firewall_rules,omitempty"`
	MaxFirewallZones  *int `json:"max_firewall_zones,omitempty"`
	MaxAccounts       *int `json:"max_accounts,omitempty"`
	MaxCronEntries    *int `json:"max_cron_entries,omitempty"`
	MaxCronScripts    *int `json:"max_cron_scripts,omitempty"`
	MaxPolicyFiles    *int `json:"max_policy_files,omitempty"`
	MaxInventoryBytes *int `json:"max_inventory_bytes,omitempty"`
}

type CollectorToggles struct {
	System         bool `json:"system"`
	Storage        bool `json:"storage"`
	Network        bool `json:"network"`
	Proxy          bool `json:"proxy"`
	Services       bool `json:"services"`
	ListeningPorts bool `json:"listening_ports"`
	Firewall       bool `json:"firewall"`
	Accounts       bool `json:"accounts"`
	SSSD           bool `json:"sssd"`
	Integrations   bool `json:"integrations"`
	Policies       bool `json:"policies"`
	Cron           bool `json:"cron"`
	NTP            bool `json:"ntp"`
}

type Limits struct {
	MaxPartitions     int `json:"max_partitions"`
	MaxRoutes         int `json:"max_routes"`
	MaxServices       int `json:"max_services"`
	MaxPorts          int `json:"max_ports"`
	MaxFirewallRules  int `json:"max_firewall_rules"`
	MaxFirewallZones  int `json:"max_firewall_zones"`
	MaxAccounts       int `json:"max_accounts"`
	MaxCronEntries    int `json:"max_cron_entries"`
	MaxCronScripts    int `json:"max_cron_scripts"`
	MaxPolicyFiles    int `json:"max_policy_files"`
	MaxInventoryBytes int `json:"max_inventory_bytes"`
}

type Config struct {
	Listen            string
	OutputFile        string
	StateDir          string
	Refresh           time.Duration
	AuthTokenFile     string
	PolicyPaths       []string
	CollectorTimeout  time.Duration
	OutputTestTimeout time.Duration
	Collectors        CollectorToggles
	Limits            Limits
	Central           CentralConfig
	Updates           UpdateConfig
}

type CentralConfig struct {
	Enabled                 bool
	URL                     string
	RegistrationTokenFile   string
	HeartbeatInterval       time.Duration
	RetryInterval           time.Duration
	RequestTimeout          time.Duration
	AdvertiseURL            string
	CAFile                  string
	TLSServerName           string
	InsecureSkipVerify      bool
	AllowHTTP               bool
	AgentCollectionInterval time.Duration
}

type UpdateConfig struct {
	Enabled          bool
	Channel          string
	CheckInterval    time.Duration
	AutoInstall      bool
	Endpoint         string
	DownloadDir      string
	HealthTimeout    time.Duration
	MaxDownloadBytes int64
}

func Defaults() Config {
	return Config{
		Listen:            "0.0.0.0:9078",
		OutputFile:        "/var/lib/vm-doc-agent/inventory.json",
		StateDir:          "/var/lib/vm-doc-agent",
		Refresh:           24 * time.Hour,
		AuthTokenFile:     "/etc/vm-doc-agent/token",
		PolicyPaths:       []string{},
		CollectorTimeout:  20 * time.Second,
		OutputTestTimeout: 12 * time.Second,
		Collectors: CollectorToggles{
			System: true, Storage: true, Network: true, Proxy: true,
			Services: true, ListeningPorts: true, Firewall: true,
			Accounts: true, SSSD: true, Integrations: true,
			Policies: true, Cron: true, NTP: true,
		},
		Limits: Limits{
			MaxPartitions: 1000, MaxRoutes: 5000, MaxServices: 5000,
			MaxPorts: 5000, MaxFirewallRules: 10000, MaxFirewallZones: 1000,
			MaxAccounts: 10000, MaxCronEntries: 5000, MaxCronScripts: 5000,
			MaxPolicyFiles: 10000, MaxInventoryBytes: 20 * 1024 * 1024,
		},
		Central: CentralConfig{
			RegistrationTokenFile: "/etc/vm-doc-agent/central-registration-token",
			HeartbeatInterval:     5 * time.Minute, RetryInterval: time.Minute,
			RequestTimeout: 60 * time.Second, AgentCollectionInterval: 24 * time.Hour,
		},
		Updates: UpdateConfig{Enabled: true, Channel: "stable", CheckInterval: 6 * time.Hour, AutoInstall: true, Endpoint: "/api/v1/agent-updates/latest", HealthTimeout: 45 * time.Second, MaxDownloadBytes: 64 << 20},
	}
}

func Load(path string) (Config, error) {
	cfg := Defaults()
	path = strings.TrimSpace(path)
	if path == "" {
		return cfg, nil
	}

	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return Config{}, fmt.Errorf("configuration file does not exist: %s", path)
		}
		return Config{}, fmt.Errorf("read configuration: %w", err)
	}

	var fileCfg FileConfig
	decoder := json.NewDecoder(strings.NewReader(string(data)))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&fileCfg); err != nil {
		return Config{}, fmt.Errorf("parse configuration %s: %w", path, err)
	}
	var trailing any
	if err := decoder.Decode(&trailing); err != io.EOF {
		if err == nil {
			return Config{}, fmt.Errorf("parse configuration %s: multiple JSON values", path)
		}
		return Config{}, fmt.Errorf("parse configuration %s: trailing data: %w", path, err)
	}

	if value := strings.TrimSpace(fileCfg.Listen); value != "" {
		cfg.Listen = value
	}
	if value := strings.TrimSpace(fileCfg.OutputFile); value != "" {
		cfg.OutputFile = value
	}
	if value := strings.TrimSpace(fileCfg.StateDir); value != "" {
		cfg.StateDir = value
	}
	if value := strings.TrimSpace(fileCfg.AuthTokenFile); value != "" {
		cfg.AuthTokenFile = value
	}
	if fileCfg.PolicyPaths != nil {
		cfg.PolicyPaths = append([]string{}, fileCfg.PolicyPaths...)
	}
	if value := strings.TrimSpace(fileCfg.Refresh); value != "" {
		duration, err := time.ParseDuration(value)
		if err != nil {
			return Config{}, fmt.Errorf("invalid refresh_interval %q: %w", value, err)
		}
		cfg.Refresh = duration
	}
	if value := strings.TrimSpace(fileCfg.CollectorTimeout); value != "" {
		duration, err := time.ParseDuration(value)
		if err != nil {
			return Config{}, fmt.Errorf("invalid collector_timeout %q: %w", value, err)
		}
		cfg.CollectorTimeout = duration
	}
	if value := strings.TrimSpace(fileCfg.OutputTestTimeout); value != "" {
		duration, err := time.ParseDuration(value)
		if err != nil {
			return Config{}, fmt.Errorf("invalid output_test_timeout %q: %w", value, err)
		}
		cfg.OutputTestTimeout = duration
	}
	mergeCollectors(&cfg.Collectors, fileCfg.Collectors)
	mergeLimits(&cfg.Limits, fileCfg.Limits)
	if err := mergeCentral(&cfg.Central, fileCfg.Central); err != nil {
		return Config{}, err
	}
	if err := mergeUpdates(&cfg.Updates, fileCfg.Updates); err != nil {
		return Config{}, err
	}
	// 1.3.0 enables auto-update by default for centrally managed agents.
	// Preserve compatibility for legacy standalone configurations that have central disabled
	// and do not contain an explicit updates section.
	if fileCfg.Updates == nil && !cfg.Central.Enabled {
		cfg.Updates.Enabled = false
	}
	cfg.Central.AgentCollectionInterval = cfg.Refresh
	if strings.TrimSpace(cfg.Updates.DownloadDir) == "" {
		cfg.Updates.DownloadDir = filepath.Join(cfg.StateDir, "updates")
	}

	if err := cfg.Validate(); err != nil {
		return Config{}, err
	}
	return cfg, nil
}

func mergeCentral(target *CentralConfig, source *FileCentralConfig) error {
	if source == nil {
		return nil
	}
	setBool(&target.Enabled, source.Enabled)
	setBool(&target.InsecureSkipVerify, source.InsecureSkipVerify)
	setBool(&target.AllowHTTP, source.AllowHTTP)
	if value := strings.TrimSpace(source.URL); value != "" {
		target.URL = strings.TrimRight(value, "/")
	}
	if value := strings.TrimSpace(source.RegistrationTokenFile); value != "" {
		target.RegistrationTokenFile = value
	}
	if value := strings.TrimSpace(source.AdvertiseURL); value != "" {
		target.AdvertiseURL = strings.TrimRight(value, "/")
	}
	if value := strings.TrimSpace(source.CAFile); value != "" {
		target.CAFile = value
	}
	if value := strings.TrimSpace(source.TLSServerName); value != "" {
		target.TLSServerName = value
	}
	for name, value := range map[string]string{
		"heartbeat_interval": source.HeartbeatInterval,
		"retry_interval":     source.RetryInterval,
		"request_timeout":    source.RequestTimeout,
	} {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		duration, err := time.ParseDuration(value)
		if err != nil {
			return fmt.Errorf("invalid central.%s %q: %w", name, value, err)
		}
		switch name {
		case "heartbeat_interval":
			target.HeartbeatInterval = duration
		case "retry_interval":
			target.RetryInterval = duration
		case "request_timeout":
			target.RequestTimeout = duration
		}
	}
	return nil
}

func mergeUpdates(target *UpdateConfig, source *FileUpdateConfig) error {
	if source == nil {
		return nil
	}
	setBool(&target.Enabled, source.Enabled)
	setBool(&target.AutoInstall, source.AutoInstall)
	if value := strings.TrimSpace(source.Channel); value != "" {
		target.Channel = strings.ToLower(value)
	}
	if value := strings.TrimSpace(source.Endpoint); value != "" {
		target.Endpoint = value
	}
	if value := strings.TrimSpace(source.DownloadDir); value != "" {
		target.DownloadDir = value
	}
	if source.MaxDownloadBytes != nil {
		target.MaxDownloadBytes = *source.MaxDownloadBytes
	}
	for name, value := range map[string]string{"check_interval": source.CheckInterval, "health_timeout": source.HealthTimeout} {
		value = strings.TrimSpace(value)
		if value == "" {
			continue
		}
		duration, err := time.ParseDuration(value)
		if err != nil {
			return fmt.Errorf("invalid updates.%s %q: %w", name, value, err)
		}
		if name == "check_interval" {
			target.CheckInterval = duration
		} else {
			target.HealthTimeout = duration
		}
	}
	return nil
}

func mergeCollectors(target *CollectorToggles, source *FileCollectorToggles) {
	if source == nil {
		return
	}
	setBool(&target.System, source.System)
	setBool(&target.Storage, source.Storage)
	setBool(&target.Network, source.Network)
	setBool(&target.Proxy, source.Proxy)
	setBool(&target.Services, source.Services)
	setBool(&target.ListeningPorts, source.ListeningPorts)
	setBool(&target.Firewall, source.Firewall)
	setBool(&target.Accounts, source.Accounts)
	setBool(&target.SSSD, source.SSSD)
	setBool(&target.Integrations, source.Integrations)
	setBool(&target.Policies, source.Policies)
	setBool(&target.Cron, source.Cron)
	setBool(&target.NTP, source.NTP)
}

func mergeLimits(target *Limits, source *FileLimits) {
	if source == nil {
		return
	}
	setInt(&target.MaxPartitions, source.MaxPartitions)
	setInt(&target.MaxRoutes, source.MaxRoutes)
	setInt(&target.MaxServices, source.MaxServices)
	setInt(&target.MaxPorts, source.MaxPorts)
	setInt(&target.MaxFirewallRules, source.MaxFirewallRules)
	setInt(&target.MaxFirewallZones, source.MaxFirewallZones)
	setInt(&target.MaxAccounts, source.MaxAccounts)
	setInt(&target.MaxCronEntries, source.MaxCronEntries)
	setInt(&target.MaxCronScripts, source.MaxCronScripts)
	setInt(&target.MaxPolicyFiles, source.MaxPolicyFiles)
	setInt(&target.MaxInventoryBytes, source.MaxInventoryBytes)
}

func setBool(target *bool, source *bool) {
	if source != nil {
		*target = *source
	}
}

func setInt(target *int, source *int) {
	if source != nil {
		*target = *source
	}
}

func (c Config) Validate() error {
	if strings.TrimSpace(c.Listen) == "" {
		return errors.New("listen address is required")
	}
	if !filepath.IsAbs(c.OutputFile) {
		return errors.New("output_file must be an absolute path")
	}
	if !filepath.IsAbs(c.StateDir) {
		return errors.New("state_dir must be an absolute path")
	}
	if !filepath.IsAbs(c.AuthTokenFile) {
		return errors.New("auth_token_file must be an absolute path")
	}
	if c.Refresh < time.Minute {
		return errors.New("refresh_interval must be at least 1 minute")
	}
	if c.CollectorTimeout < time.Second || c.CollectorTimeout > 10*time.Minute {
		return errors.New("collector_timeout must be between 1 second and 10 minutes")
	}
	if c.OutputTestTimeout < time.Second || c.OutputTestTimeout > 2*time.Minute {
		return errors.New("output_test_timeout must be between 1 second and 2 minutes")
	}
	if c.Central.Enabled {
		centralURL, err := url.Parse(c.Central.URL)
		if err != nil || centralURL.Hostname() == "" {
			return errors.New("central.url must be an absolute URL when central is enabled")
		}
		if centralURL.Scheme != "https" && !(c.Central.AllowHTTP && centralURL.Scheme == "http") {
			return errors.New("central.url must use HTTPS unless central.allow_http is true")
		}
		if !filepath.IsAbs(c.Central.RegistrationTokenFile) {
			return errors.New("central.registration_token_file must be an absolute path")
		}
		if c.Central.CAFile != "" && !filepath.IsAbs(c.Central.CAFile) {
			return errors.New("central.ca_file must be an absolute path")
		}
		if c.Central.HeartbeatInterval < 30*time.Second || c.Central.HeartbeatInterval > 24*time.Hour {
			return errors.New("central.heartbeat_interval must be between 30 seconds and 24 hours")
		}
		if c.Central.RetryInterval < 5*time.Second || c.Central.RetryInterval > time.Hour {
			return errors.New("central.retry_interval must be between 5 seconds and 1 hour")
		}
		if c.Central.RequestTimeout < time.Second || c.Central.RequestTimeout > 10*time.Minute {
			return errors.New("central.request_timeout must be between 1 second and 10 minutes")
		}
		if c.Central.AdvertiseURL != "" {
			u, err := url.Parse(c.Central.AdvertiseURL)
			if err != nil || u.Hostname() == "" || (u.Scheme != "http" && u.Scheme != "https") {
				return errors.New("central.advertise_url must be an absolute HTTP or HTTPS URL")
			}
		}
	}

	if c.Updates.Enabled {
		if !c.Central.Enabled {
			return errors.New("updates.enabled requires central.enabled=true")
		}
		if c.Updates.Channel != "stable" && c.Updates.Channel != "testing" {
			return errors.New("updates.channel must be stable or testing")
		}
		if c.Updates.CheckInterval < 5*time.Minute || c.Updates.CheckInterval > 7*24*time.Hour {
			return errors.New("updates.check_interval must be between 5 minutes and 7 days")
		}
		if c.Updates.HealthTimeout < 10*time.Second || c.Updates.HealthTimeout > 5*time.Minute {
			return errors.New("updates.health_timeout must be between 10 seconds and 5 minutes")
		}
		if !strings.HasPrefix(c.Updates.Endpoint, "/") || strings.Contains(c.Updates.Endpoint, "://") {
			return errors.New("updates.endpoint must be a relative absolute-path such as /api/v1/agent-updates/latest")
		}
		if !filepath.IsAbs(c.Updates.DownloadDir) {
			return errors.New("updates.download_dir must be an absolute path")
		}
		if c.Updates.MaxDownloadBytes < 1<<20 || c.Updates.MaxDownloadBytes > 512<<20 {
			return errors.New("updates.max_download_bytes must be between 1 MiB and 512 MiB")
		}
	}

	for _, path := range c.PolicyPaths {
		if strings.TrimSpace(path) == "" {
			return errors.New("policy_paths cannot contain empty values")
		}
	}
	limits := []struct {
		name  string
		value int
	}{
		{"max_partitions", c.Limits.MaxPartitions}, {"max_routes", c.Limits.MaxRoutes},
		{"max_services", c.Limits.MaxServices}, {"max_ports", c.Limits.MaxPorts},
		{"max_firewall_rules", c.Limits.MaxFirewallRules}, {"max_firewall_zones", c.Limits.MaxFirewallZones},
		{"max_accounts", c.Limits.MaxAccounts}, {"max_cron_entries", c.Limits.MaxCronEntries},
		{"max_cron_scripts", c.Limits.MaxCronScripts}, {"max_policy_files", c.Limits.MaxPolicyFiles},
	}
	for _, limit := range limits {
		if limit.value < 1 || limit.value > 1_000_000 {
			return fmt.Errorf("limits.%s must be between 1 and 1000000", limit.name)
		}
	}
	if c.Limits.MaxInventoryBytes < 1024*1024 || c.Limits.MaxInventoryBytes > 1024*1024*1024 {
		return errors.New("limits.max_inventory_bytes must be between 1 MiB and 1 GiB")
	}
	return nil
}

func (c Config) SafeView() map[string]any {
	return map[string]any{
		"listen":              c.Listen,
		"output_file":         c.OutputFile,
		"state_dir":           c.StateDir,
		"refresh_interval":    c.Refresh.String(),
		"auth_token_file":     c.AuthTokenFile,
		"policy_paths":        append([]string{}, c.PolicyPaths...),
		"collector_timeout":   c.CollectorTimeout.String(),
		"output_test_timeout": c.OutputTestTimeout.String(),
		"collectors":          c.Collectors,
		"limits":              c.Limits,
		"central": map[string]any{
			"enabled": c.Central.Enabled, "url": c.Central.URL,
			"registration_token_file": c.Central.RegistrationTokenFile,
			"heartbeat_interval":      c.Central.HeartbeatInterval.String(),
			"retry_interval":          c.Central.RetryInterval.String(),
			"request_timeout":         c.Central.RequestTimeout.String(),
			"advertise_url":           c.Central.AdvertiseURL, "ca_file": c.Central.CAFile,
			"tls_server_name":      c.Central.TLSServerName,
			"insecure_skip_verify": c.Central.InsecureSkipVerify, "allow_http": c.Central.AllowHTTP,
		},
		"updates": map[string]any{
			"enabled": c.Updates.Enabled, "channel": c.Updates.Channel, "check_interval": c.Updates.CheckInterval.String(),
			"auto_install": c.Updates.AutoInstall, "endpoint": c.Updates.Endpoint, "download_dir": c.Updates.DownloadDir,
			"health_timeout": c.Updates.HealthTimeout.String(), "max_download_bytes": c.Updates.MaxDownloadBytes,
		},
	}
}
