package inventoryfile

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"vm-doc-agent/internal/model"
)

func Marshal(inventory model.Inventory) ([]byte, error) {
	data, err := json.MarshalIndent(inventory, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("encode inventory: %w", err)
	}
	return append(data, '\n'), nil
}

func WriteAtomic(path string, inventory model.Inventory, maxBytes int) (int64, error) {
	data, err := Marshal(inventory)
	if err != nil {
		return 0, err
	}
	if maxBytes > 0 && len(data) > maxBytes {
		return 0, fmt.Errorf("inventory size %d exceeds configured maximum %d bytes", len(data), maxBytes)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0750); err != nil {
		return 0, fmt.Errorf("create output directory: %w", err)
	}
	if err := preservePrevious(path); err != nil {
		return 0, err
	}
	temporary := path + ".tmp"
	file, err := os.OpenFile(temporary, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0640)
	if err != nil {
		return 0, fmt.Errorf("open temporary inventory: %w", err)
	}
	cleanup := func() { _ = file.Close(); _ = os.Remove(temporary) }
	if _, err := file.Write(data); err != nil {
		cleanup()
		return 0, fmt.Errorf("write temporary inventory: %w", err)
	}
	if err := file.Sync(); err != nil {
		cleanup()
		return 0, fmt.Errorf("sync temporary inventory: %w", err)
	}
	if err := file.Close(); err != nil {
		_ = os.Remove(temporary)
		return 0, fmt.Errorf("close temporary inventory: %w", err)
	}
	if err := os.Chmod(temporary, 0640); err != nil {
		_ = os.Remove(temporary)
		return 0, fmt.Errorf("set temporary inventory permissions: %w", err)
	}
	if err := os.Rename(temporary, path); err != nil {
		_ = os.Remove(temporary)
		return 0, fmt.Errorf("replace inventory file: %w", err)
	}
	if directory, err := os.Open(filepath.Dir(path)); err == nil {
		_ = directory.Sync()
		_ = directory.Close()
	}
	return int64(len(data)), nil
}

func preservePrevious(path string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return nil
		}
		return fmt.Errorf("read current inventory before replacement: %w", err)
	}
	if !json.Valid(data) {
		return nil
	}
	previous := path + ".previous"
	temporary := previous + ".tmp"
	if err := os.WriteFile(temporary, data, 0640); err != nil {
		return fmt.Errorf("write previous inventory: %w", err)
	}
	if err := os.Rename(temporary, previous); err != nil {
		_ = os.Remove(temporary)
		return fmt.Errorf("replace previous inventory: %w", err)
	}
	return nil
}
