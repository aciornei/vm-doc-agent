package inventoryfile

import (
	"os"
	"path/filepath"
	"testing"

	"vm-doc-agent/internal/model"
)

func TestWriteAtomicPreservesPreviousValidInventory(t *testing.T) {
	path := filepath.Join(t.TempDir(), "inventory.json")
	first := model.Inventory{SchemaVersion: "one"}
	second := model.Inventory{SchemaVersion: "two"}
	if _, err := WriteAtomic(path, first, 1024*1024); err != nil {
		t.Fatal(err)
	}
	if _, err := WriteAtomic(path, second, 1024*1024); err != nil {
		t.Fatal(err)
	}
	previous, err := os.ReadFile(path + ".previous")
	if err != nil {
		t.Fatal(err)
	}
	if string(previous) == "" || !contains(string(previous), `"schema_version": "one"`) {
		t.Fatalf("unexpected previous: %s", previous)
	}
}

func contains(value, part string) bool {
	for i := 0; i+len(part) <= len(value); i++ {
		if value[i:i+len(part)] == part {
			return true
		}
	}
	return false
}
