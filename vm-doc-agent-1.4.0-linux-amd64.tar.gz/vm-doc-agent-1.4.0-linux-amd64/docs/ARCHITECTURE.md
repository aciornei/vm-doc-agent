# Arhitectură

```text
vm-doc-agent
├── config JSON
├── platform detection
├── persistent agent identity
├── collector orchestrator
│   ├── timeout per collector
│   ├── status per collector
│   ├── enable/disable per collector
│   └── best-effort isolation
├── collectors
│   ├── host identity and UUID correlation
│   ├── system/timezone/boot
│   ├── storage
│   ├── network/DNS/routes
│   ├── proxy
│   ├── services and listening ports
│   ├── firewall and accounts
│   ├── SSSD and integrations
│   ├── policies and cron
│   └── NTP
├── limits and truncation metadata
├── atomic inventory writer
│   ├── inventory.json.tmp
│   ├── inventory.json
│   └── inventory.json.previous
└── HTTP API with Bearer token
```

## Principii

- un singur binar și un singur installer pentru toate distribuțiile suportate;
- același model JSON pe toate sistemele;
- un colector defect nu oprește celelalte colectoare;
- lipsa unei comenzi sau a unui fișier produce avertisment, nu oprirea agentului;
- secretele sunt excluse sau mascate;
- datele locale sunt separate de datele ce vor veni din vCenter, GLPI, AD/LDAP și Veeam;
- schema inventarului și versiunea binarului sunt versionate separat.

## Dependențe între colectoare

SSSD, NTP și integrările folosesc lista de servicii pentru a raporta starea serviciilor. Node Exporter folosește și porturile ascultate pentru descoperirea endpoint-ului. Dacă `services` sau `listening_ports` sunt dezactivate, colectoarele dependente continuă, dar raportează `partial`.

## Flux outbound către nodul central

```text
colectare locală
    -> POST /api/v1/agent-registration/register
    -> POST /api/v1/agent-registration/inventory
    -> POST /api/v1/agent-registration/heartbeat (periodic)
```

Agentul inițiază conexiunea. Serverul central nu trebuie să scaneze rețeaua pentru
a descoperi instalările. Tokenul API local este transmis numai în cererea de
înregistrare și este criptat de server înainte de stocare.
