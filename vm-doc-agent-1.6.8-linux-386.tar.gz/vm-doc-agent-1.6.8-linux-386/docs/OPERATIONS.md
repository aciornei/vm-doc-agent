# Operațiuni și diagnostic

## Versiune

```bash
vm-doc-agent -version
```

## Validarea configurației

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -check-config
```

## Colectare unică și salvare

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -collect-once
```

## Colectare unică și afișare pe stdout

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -print-inventory
```

## Diagnostic sigur

```bash
vm-doc-agent -config /etc/vm-doc-agent/config.json -diagnostics
```

Raportul de diagnostic conține configurația fără token, metadata fișierelor, identificarea hostului, statusul colectoarelor și avertismentele.

## Inventar curent și anterior

```text
/var/lib/vm-doc-agent/inventory.json
/var/lib/vm-doc-agent/inventory.json.previous
```

Fișierul anterior este actualizat numai dacă inventarul curent este JSON valid.

## Loguri

Systemd:

```bash
journalctl -u vm-doc-agent --since today
```

SysV:

```bash
tail -f /var/log/vm-doc-agent.log
```

Evenimentele includ `collection_started`, `collection_completed`, `http_request`, `unauthorized_request` și erorile de scriere.

## Auto-update

Status:

```bash
TOKEN=$(cat /etc/vm-doc-agent/token)
curl -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update
```

Forțare verificare și instalare, dacă serverul publică o versiune mai nouă:

```bash
curl -X POST -H "Authorization: Bearer $TOKEN" http://127.0.0.1:9078/v1/update/check
```

Helperul de update este `/usr/local/sbin/vm-doc-updater`. Binarul anterior al agentului este păstrat ca `vm-doc-agent.previous`; dacă health check-ul noii versiuni eșuează, helperul revine automat la versiunea anterioară.


### Log propriu (1.3.6+)

Agentul și updaterul scriu direct în `/var/log/vm-doc-agent.log`. Pe systemd mesajele sunt păstrate și în journal. Pentru urmărire în timp real: `tail -f /var/log/vm-doc-agent.log`.


## MySQL/MariaDB inventory fără parolă (1.6.6+)

Pe serverele unde `vm-doc-agent` rulează ca root, recomandarea este să păstrați serviciul neschimbat și să creați separat userul Linux `vm-doc-inventory`. Pentru MariaDB cu pluginul `unix_socket`, creați userul DB cu același nume și acordați numai `SHOW DATABASES`. Agentul detectează userul și rulează discovery prin `runuser`, clientul `mysql` fiind preferat înainte de `mariadb`. Dacă instanța raportează un socket explicit, agentul îl pasează clientului. Nu sunt necesare parole în `config.json`.
