#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
VERSION=${VERSION:-1.6.1}
COMMIT=${COMMIT:-unknown}
BUILD_DATE=${BUILD_DATE:-$(date -u +%Y-%m-%dT%H:%M:%SZ)}
mkdir -p dist

echo "Running tests..."
go test ./...

echo "Building universal static linux/amd64 agent..."
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 GOAMD64=v1 \
    go build -buildvcs=false -trimpath \
    -ldflags="-s -w -X vm-doc-agent/internal/version.Version=$VERSION -X vm-doc-agent/internal/version.Commit=$COMMIT -X vm-doc-agent/internal/version.BuildDate=$BUILD_DATE" \
    -o dist/vm-doc-agent ./cmd/vm-doc-agent

CGO_ENABLED=0 GOOS=linux GOARCH=amd64 GOAMD64=v1 \
    go build -buildvcs=false -trimpath \
    -ldflags="-s -w -X vm-doc-agent/internal/version.Version=$VERSION -X vm-doc-agent/internal/version.Commit=$COMMIT -X vm-doc-agent/internal/version.BuildDate=$BUILD_DATE" \
    -o dist/vm-doc-updater ./cmd/vm-doc-updater

file dist/vm-doc-agent dist/vm-doc-updater || true
echo "Built: dist/vm-doc-agent and dist/vm-doc-updater"
