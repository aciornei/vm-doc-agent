//go:build !windows

package updater

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

func launchHelper(path string, args []string) error {
	if _, err := os.Stat("/run/systemd/system"); err == nil {
		if systemdRun, lookErr := exec.LookPath("systemd-run"); lookErr == nil {
			unit := fmt.Sprintf("vm-doc-agent-update-%d", os.Getpid())

			// systemd-run gained options at different times, and enterprise
			// distributions may backport only some of them. Build the command
			// from capabilities advertised by the installed systemd-run instead
			// of assuming a systemd version. The minimal form (--unit + command)
			// works with old systemd releases such as CentOS 7/systemd 219.
			help := ""
			if out, helpErr := exec.Command(systemdRun, "--help").CombinedOutput(); helpErr == nil {
				help = string(out)
			}
			runArgs := buildSystemdRunArgs(unit, path, args, help)
			cmd := exec.Command(systemdRun, runArgs...)
			cmd.Stdout = os.Stdout
			cmd.Stderr = os.Stderr
			return cmd.Run()
		}
	}

	cmd := exec.Command(path, args...)
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Start()
}

func buildSystemdRunArgs(unit, path string, args []string, help string) []string {
	runArgs := []string{"--unit", unit}
	if strings.Contains(help, "--collect") {
		runArgs = append(runArgs, "--collect")
	}
	if strings.Contains(help, "--no-block") {
		runArgs = append(runArgs, "--no-block")
	}
	// Do not force Type=exec here. It was added after systemd 219 and is
	// not universally backported. systemd-run defaults to Type=simple,
	// which is sufficient because the updater helper is intentionally
	// detached into its own transient unit before the agent exits.
	runArgs = append(runArgs, path)
	runArgs = append(runArgs, args...)
	return runArgs
}
