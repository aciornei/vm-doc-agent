//go:build !windows

package updater

import (
	"reflect"
	"testing"
)

func TestBuildSystemdRunArgsLegacy(t *testing.T) {
	got := buildSystemdRunArgs(
		"vm-doc-agent-update-123",
		"/usr/local/sbin/vm-doc-updater",
		[]string{"-pid", "123"},
		"systemd-run options: --unit --collect --quiet",
	)
	want := []string{
		"--unit", "vm-doc-agent-update-123",
		"--collect",
		"/usr/local/sbin/vm-doc-updater",
		"-pid", "123",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("legacy args = %#v, want %#v", got, want)
	}
}

func TestBuildSystemdRunArgsMinimal(t *testing.T) {
	got := buildSystemdRunArgs(
		"vm-doc-agent-update-123",
		"/usr/local/sbin/vm-doc-updater",
		[]string{"-pid", "123"},
		"",
	)
	want := []string{
		"--unit", "vm-doc-agent-update-123",
		"/usr/local/sbin/vm-doc-updater",
		"-pid", "123",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("minimal args = %#v, want %#v", got, want)
	}
}

func TestBuildSystemdRunArgsModern(t *testing.T) {
	got := buildSystemdRunArgs(
		"vm-doc-agent-update-123",
		"/usr/local/sbin/vm-doc-updater",
		[]string{"-pid", "123"},
		"systemd-run options: --unit --collect --no-block --wait",
	)
	want := []string{
		"--unit", "vm-doc-agent-update-123",
		"--collect", "--no-block",
		"/usr/local/sbin/vm-doc-updater",
		"-pid", "123",
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("modern args = %#v, want %#v", got, want)
	}
}
