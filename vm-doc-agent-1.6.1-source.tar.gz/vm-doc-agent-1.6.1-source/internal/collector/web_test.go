package collector

import (
	"os"
	"path/filepath"
	"testing"
)

func TestParseNginxSite(t *testing.T) {
	raw := `server {
  listen 80 default_server;
  listen 443 ssl;
  server_name portal.example.ro www.portal.example.ro;
  root /srv/portal;
  location /api { proxy_pass http://127.0.0.1:8080; }
}`
	blocks := extractBraceBlocks(raw, nginxServerStart)
	if len(blocks) != 1 {
		t.Fatalf("blocks=%d", len(blocks))
	}
	d := parseSemicolonDirectives(blocks[0])
	if got := firstDirectiveValue(d["root"]); got != "/srv/portal" {
		t.Fatalf("root=%q", got)
	}
	if len(d["listen"]) != 2 {
		t.Fatalf("listen=%#v", d["listen"])
	}
	b, def := parseNginxListen(d["listen"][0])
	if b.Port != 80 || !def {
		t.Fatalf("binding=%+v default=%v", b, def)
	}
}

func TestParseApacheVHostBinding(t *testing.T) {
	addr, port, wildcard := parseHostPortLoose("*:443", 80)
	if addr != "" || port != 443 || !wildcard {
		t.Fatalf("%q %d %v", addr, port, wildcard)
	}
}

func TestHAProxyHostACLValues(t *testing.T) {
	got := haproxyHostACLValues([]string{"acl", "host_portal", "hdr(host)", "-i", "portal.example.ro", "www.portal.example.ro"})
	if len(got) != 2 || got[0] != "portal.example.ro" {
		t.Fatalf("%#v", got)
	}
}

func TestSafeTargetsRejectCredentials(t *testing.T) {
	got := safeTargets([]string{"http://127.0.0.1:8080", "http://user:pass@db:8080"})
	if len(got) != 1 || got[0] != "http://127.0.0.1:8080" {
		t.Fatalf("%#v", got)
	}
}

func TestNginxProcessPaths(t *testing.T) {
	prefix, conf := nginxProcessPaths([]string{"/opt/nginx/sbin/nginx", "-p", "/opt/nginx/", "-c", "conf/custom.conf"})
	if prefix != "/opt/nginx/" || conf != "conf/custom.conf" {
		t.Fatalf("prefix=%q conf=%q", prefix, conf)
	}
}

func TestNginxPathsFromVersionOutput(t *testing.T) {
	prefix, conf := nginxPathsFromVersionOutput(`nginx version: nginx/1.29.4
configure arguments: --prefix=/opt/nginx --conf-path=/opt/nginx/conf/nginx.conf --with-http_ssl_module`)
	if prefix != "/opt/nginx" || conf != "/opt/nginx/conf/nginx.conf" {
		t.Fatalf("prefix=%q conf=%q", prefix, conf)
	}
}

func TestExpandNginxConfigIncludesUnderOptLayout(t *testing.T) {
	dir := t.TempDir()
	prefix := filepath.Join(dir, "opt", "nginx")
	confDir := filepath.Join(prefix, "conf")
	sitesDir := filepath.Join(confDir, "sites-enabled")
	if err := os.MkdirAll(sitesDir, 0755); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(confDir, "nginx.conf")
	site := filepath.Join(sitesDir, "portal.conf")
	if err := os.WriteFile(root, []byte("events {}\nhttp { include conf/sites-enabled/*.conf; }\n"), 0644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(site, []byte("server { listen 80; server_name portal.example.ro; }\n"), 0644); err != nil {
		t.Fatal(err)
	}
	got := expandNginxConfigIncludes(root, prefix, 20)
	seen := map[string]bool{}
	for _, path := range got {
		seen[filepath.Clean(path)] = true
	}
	if !seen[filepath.Clean(root)] || !seen[filepath.Clean(site)] {
		t.Fatalf("expanded configs=%#v", got)
	}
}
