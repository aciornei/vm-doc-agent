package collector

import (
	"testing"
	"vm-doc-agent/internal/model"
)

func TestDatabaseSystemCatalog(t *testing.T) {
	if !databaseSystemCatalog("postgresql", "postgres") || databaseSystemCatalog("postgresql", "appdb") {
		t.Fatal("postgres system catalog classification")
	}
	if !databaseSystemCatalog("mariadb", "information_schema") || databaseSystemCatalog("mariadb", "business") {
		t.Fatal("mysql system catalog classification")
	}
}

func TestDatabaseArgsMetadata(t *testing.T) {
	data, configs, sockets, _ := databaseArgsMetadata("mariadb", []string{"mariadbd", "--datadir=/srv/mysql", "--defaults-file=/etc/mysql/my.cnf", "--socket=/run/mysqld/mysqld.sock"})
	if data != "/srv/mysql" || len(configs) != 1 || len(sockets) != 1 {
		t.Fatalf("unexpected metadata: %q %#v %#v", data, configs, sockets)
	}
}

func TestDatabaseInstanceKey(t *testing.T) {
	v := model.DatabaseInstance{Engine: "postgresql", InstanceName: "main", DataDir: "/var/lib/postgresql/16/main", Endpoints: []model.DatabaseEndpoint{{Port: 5432}}}
	if databaseInstanceKey(v) != "postgresql|main|/var/lib/postgresql/16/main|5432" {
		t.Fatal(databaseInstanceKey(v))
	}
}

func TestTruncateDatabasesCapsAggregateCatalogs(t *testing.T) {
	inventory := model.Inventory{
		Collection: model.CollectionInfo{Collectors: map[string]model.CollectorStatus{"databases": {Status: "success"}}},
		Databases: model.DatabaseInfo{Instances: []model.DatabaseInstance{
			{Engine: "postgresql", Catalogs: []model.DatabaseCatalog{{Name: "a"}, {Name: "b"}, {Name: "c"}}},
			{Engine: "mysql", Catalogs: []model.DatabaseCatalog{{Name: "d"}, {Name: "e"}, {Name: "f"}}},
		}},
		Truncations: map[string]model.TruncationInfo{},
	}
	truncateDatabases(&inventory, Limits{MaxDatabaseInstances: 10, MaxDatabaseCatalogs: 4})
	if got := len(inventory.Databases.Instances[0].Catalogs) + len(inventory.Databases.Instances[1].Catalogs); got != 4 {
		t.Fatalf("expected 4 catalogs after truncation, got %d", got)
	}
	if inventory.Collection.Collectors["databases"].Status != "partial" {
		t.Fatalf("database collector not marked partial: %+v", inventory.Collection.Collectors["databases"])
	}
	if _, ok := inventory.Truncations["databases.catalogs"]; !ok {
		t.Fatal("missing databases.catalogs truncation metadata")
	}
}

func TestDatabaseDefinitionsDoNotTreatClientOnlyBinariesAsServerInstall(t *testing.T) {
	for _, def := range databaseDefinitions {
		for _, client := range def.VersionBinaries {
			if client == "psql" || client == "mysql" || client == "mariadb" || client == "mongosh" || client == "mongo" || client == "sqlcmd" || client == "isql-fb" {
				for _, server := range def.ServerBinaries {
					if client == server {
						t.Fatalf("client-only binary %q for %s is also marked as server binary", client, def.Engine)
					}
				}
			}
		}
	}
}

func TestBestDatabaseServicePrefersActivePostgresInstanceUnit(t *testing.T) {
	def := definitionByEngine("postgresql")
	services := []model.ServiceInfo{
		{Name: "postgresql.service", ActiveState: "inactive"},
		{Name: "postgresql@16-main.service", ActiveState: "active"},
	}
	svc, ok := bestDatabaseService(instanceServiceContext{Engine: "postgresql", InstanceName: "main", DataDir: "/var/lib/postgresql/16/main"}, services, def)
	if !ok || svc.Name != "postgresql@16-main.service" {
		t.Fatalf("unexpected service: %+v ok=%v", svc, ok)
	}
}

func TestDatabaseProcessStatusNotDowngradedByInactiveMetaService(t *testing.T) {
	def := definitionByEngine("postgresql")
	proc := procDatabase{PID: 123, Name: "postgres", Executable: "/usr/lib/postgresql/16/bin/postgres", Args: []string{"postgres", "-D", "/var/lib/postgresql/16/main"}}
	services := []model.ServiceInfo{{Name: "postgresql.service", ActiveState: "inactive"}}
	instance := databaseInstanceFromProcess(proc, def, services, nil)
	if instance.Status != "running" {
		t.Fatalf("running process was downgraded to %q", instance.Status)
	}
}
