package collector

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

type databaseDefinition struct {
	Engine          string
	Product         string
	ProcessNames    []string
	ServerBinaries  []string
	VersionBinaries []string
	ServiceHints    []string
	DefaultPort     uint16
}

var databaseDefinitions = []databaseDefinition{
	{Engine: "postgresql", Product: "PostgreSQL", ProcessNames: []string{"postgres"}, ServerBinaries: []string{"postgres"}, VersionBinaries: []string{"postgres", "psql"}, ServiceHints: []string{"postgresql", "postgres"}, DefaultPort: 5432},
	{Engine: "mariadb", Product: "MariaDB", ProcessNames: []string{"mariadbd"}, ServerBinaries: []string{"mariadbd"}, VersionBinaries: []string{"mariadbd", "mariadb"}, ServiceHints: []string{"mariadb"}, DefaultPort: 3306},
	{Engine: "mysql", Product: "MySQL", ProcessNames: []string{"mysqld"}, ServerBinaries: []string{"mysqld"}, VersionBinaries: []string{"mysqld", "mysql"}, ServiceHints: []string{"mysql", "mysqld"}, DefaultPort: 3306},
	{Engine: "mongodb", Product: "MongoDB", ProcessNames: []string{"mongod"}, ServerBinaries: []string{"mongod"}, VersionBinaries: []string{"mongod", "mongosh", "mongo"}, ServiceHints: []string{"mongod", "mongodb"}, DefaultPort: 27017},
	{Engine: "oracle", Product: "Oracle Database", ProcessNames: []string{"oracle"}, ServerBinaries: []string{}, VersionBinaries: []string{"sqlplus", "lsnrctl"}, ServiceHints: []string{"oracle", "oracledb"}, DefaultPort: 1521},
	{Engine: "mssql", Product: "Microsoft SQL Server", ProcessNames: []string{"sqlservr"}, ServerBinaries: []string{"sqlservr"}, VersionBinaries: []string{"sqlservr", "sqlcmd"}, ServiceHints: []string{"mssql-server", "sqlservr"}, DefaultPort: 1433},
	{Engine: "db2", Product: "IBM Db2", ProcessNames: []string{"db2sysc"}, ServerBinaries: []string{"db2sysc"}, VersionBinaries: []string{"db2level", "db2"}, ServiceHints: []string{"db2"}, DefaultPort: 50000},
	{Engine: "redis", Product: "Redis", ProcessNames: []string{"redis-server"}, ServerBinaries: []string{"redis-server"}, VersionBinaries: []string{"redis-server", "redis-cli"}, ServiceHints: []string{"redis", "redis-server"}, DefaultPort: 6379},
	{Engine: "firebird", Product: "Firebird", ProcessNames: []string{"firebird", "fbserver"}, ServerBinaries: []string{"firebird", "fbserver"}, VersionBinaries: []string{"firebird", "fbserver", "isql-fb"}, ServiceHints: []string{"firebird"}, DefaultPort: 3050},
	{Engine: "cockroachdb", Product: "CockroachDB", ProcessNames: []string{"cockroach"}, ServerBinaries: []string{"cockroach"}, VersionBinaries: []string{"cockroach"}, ServiceHints: []string{"cockroach"}, DefaultPort: 26257},
}

type procDatabase struct {
	PID        int
	PPID       int
	Name       string
	Executable string
	Args       []string
}

func collectDatabases(services []model.ServiceInfo, sockets []model.ListeningSocket, limits Limits) (model.DatabaseInfo, []string) {
	result := model.DatabaseInfo{Engines: []model.DatabaseEngine{}, Instances: []model.DatabaseInstance{}}
	warnings := []string{}
	processes := databaseProcesses()

	for _, def := range databaseDefinitions {
		engine := detectDatabaseEngine(def, services, processes)
		if engine.Installed {
			result.Engines = append(result.Engines, engine)
		}
	}

	seen := map[string]bool{}
	for _, proc := range processes {
		def, ok := databaseDefinitionForProcess(proc)
		if !ok || !databasePrimaryProcess(proc, def, processes) {
			continue
		}
		instance := databaseInstanceFromProcess(proc, def, services, sockets)
		key := databaseInstanceKey(instance)
		if seen[key] {
			continue
		}
		seen[key] = true
		instance.Catalogs, instance.CatalogDiscoveryStatus = discoverDatabaseCatalogs(instance, limits.MaxDatabaseCatalogs)
		result.Instances = append(result.Instances, instance)
	}

	// Oracle PMON processes commonly expose the SID only in argv[0], while the
	// executable itself may be named oracle. Add them explicitly when visible.
	for _, proc := range processes {
		if !strings.HasPrefix(strings.ToLower(proc.Name), "ora_pmon_") {
			continue
		}
		def := definitionByEngine("oracle")
		instance := databaseInstanceFromProcess(proc, def, services, sockets)
		instance.InstanceName = strings.TrimPrefix(proc.Name, "ora_pmon_")
		key := databaseInstanceKey(instance)
		if !seen[key] {
			seen[key] = true
			instance.CatalogDiscoveryStatus = "metadata_only"
			result.Instances = append(result.Instances, instance)
		}
	}

	if limits.MaxDatabaseInstances > 0 && len(result.Instances) > limits.MaxDatabaseInstances {
		detected := len(result.Instances)
		result.Instances = result.Instances[:limits.MaxDatabaseInstances]
		warnings = append(warnings, fmt.Sprintf("databases: instances limited: detected=%d collected=%d", detected, len(result.Instances)))
	}
	sort.Slice(result.Engines, func(i, j int) bool { return result.Engines[i].Product < result.Engines[j].Product })
	sort.Slice(result.Instances, func(i, j int) bool {
		if result.Instances[i].Engine == result.Instances[j].Engine {
			return strings.ToLower(result.Instances[i].InstanceName) < strings.ToLower(result.Instances[j].InstanceName)
		}
		return result.Instances[i].Engine < result.Instances[j].Engine
	})
	return result, uniqueSorted(warnings)
}

func detectDatabaseEngine(def databaseDefinition, services []model.ServiceInfo, processes []procDatabase) model.DatabaseEngine {
	value := model.DatabaseEngine{Engine: def.Engine, Product: def.Product, Sources: []string{}}
	for _, binary := range def.ServerBinaries {
		if path, err := exec.LookPath(binary); err == nil {
			value.Installed = true
			if value.Executable == "" {
				value.Executable = path
			}
			value.Sources = append(value.Sources, "binary:"+binary)
		}
	}
	for _, svc := range services {
		if databaseServiceMatches(svc.Name, def) {
			value.Installed = true
			value.Sources = append(value.Sources, "service:"+svc.Name)
		}
	}
	for _, proc := range processes {
		if _, ok := databaseDefinitionForProcessSpecific(proc, def); ok {
			value.Installed = true
			value.Sources = append(value.Sources, "process:"+proc.Name)
		}
	}
	if value.Installed {
		value.Version = databaseEngineVersion(def, value.Executable)
	}
	value.Sources = uniqueSorted(value.Sources)
	return value
}

func databaseProcesses() []procDatabase {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	out := []procDatabase{}
	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil || pid < 1 {
			continue
		}
		name := strings.TrimSpace(readFirstLine(filepath.Join("/proc", entry.Name(), "comm")))
		cmdline, _ := os.ReadFile(filepath.Join("/proc", entry.Name(), "cmdline"))
		args := splitNullStrings(cmdline)
		exe, _ := os.Readlink(filepath.Join("/proc", entry.Name(), "exe"))
		ppid := processPPID(filepath.Join("/proc", entry.Name(), "status"))
		if name == "" && len(args) > 0 {
			name = filepath.Base(args[0])
		}
		out = append(out, procDatabase{PID: pid, PPID: ppid, Name: name, Executable: exe, Args: args})
	}
	return out
}

func readFirstLine(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	s := bufio.NewScanner(f)
	if s.Scan() {
		return s.Text()
	}
	return ""
}

func splitNullStrings(raw []byte) []string {
	parts := strings.Split(string(raw), "\x00")
	out := make([]string, 0, len(parts))
	for _, part := range parts {
		if strings.TrimSpace(part) != "" {
			out = append(out, part)
		}
	}
	return out
}

func processPPID(path string) int {
	f, err := os.Open(path)
	if err != nil {
		return 0
	}
	defer f.Close()
	s := bufio.NewScanner(f)
	for s.Scan() {
		fields := strings.Fields(s.Text())
		if len(fields) == 2 && fields[0] == "PPid:" {
			v, _ := strconv.Atoi(fields[1])
			return v
		}
	}
	return 0
}

func databaseDefinitionForProcess(proc procDatabase) (databaseDefinition, bool) {
	for _, def := range databaseDefinitions {
		if _, ok := databaseDefinitionForProcessSpecific(proc, def); ok {
			return def, true
		}
	}
	return databaseDefinition{}, false
}

func databaseDefinitionForProcessSpecific(proc procDatabase, def databaseDefinition) (databaseDefinition, bool) {
	name := strings.ToLower(strings.TrimSpace(proc.Name))
	base := strings.ToLower(filepath.Base(proc.Executable))
	for _, candidate := range def.ProcessNames {
		candidate = strings.ToLower(candidate)
		if name == candidate || base == candidate || (def.Engine == "oracle" && strings.HasPrefix(name, "ora_pmon_")) {
			return def, true
		}
	}
	return databaseDefinition{}, false
}

func databasePrimaryProcess(proc procDatabase, def databaseDefinition, all []procDatabase) bool {
	if def.Engine != "postgresql" {
		return true
	}
	// PostgreSQL child processes normally have a postgres parent. Keep only the
	// postmaster/master for each cluster.
	for _, parent := range all {
		if parent.PID == proc.PPID {
			if pdef, ok := databaseDefinitionForProcess(parent); ok && pdef.Engine == "postgresql" {
				return false
			}
		}
	}
	return true
}

func databaseInstanceFromProcess(proc procDatabase, def databaseDefinition, services []model.ServiceInfo, sockets []model.ListeningSocket) model.DatabaseInstance {
	item := model.DatabaseInstance{Engine: def.Engine, Product: def.Product, Status: "running", PID: proc.PID, Executable: proc.Executable, DetectionSources: []string{"process"}}
	item.Version = databaseEngineVersion(def, proc.Executable)
	item.DataDir, item.ConfigFiles, item.SocketPaths, item.InstanceName = databaseArgsMetadata(def.Engine, proc.Args)
	if item.InstanceName == "" {
		item.InstanceName = databaseDefaultInstanceName(def.Engine, proc, item.DataDir)
	}
	if svc, ok := bestDatabaseService(instanceServiceContext{Engine: def.Engine, InstanceName: item.InstanceName, DataDir: item.DataDir}, services, def); ok {
		item.ServiceName = svc.Name
		// A live database process is authoritative. An inactive generic/meta unit
		// (notably postgresql.service on Debian/Ubuntu) must never downgrade it.
		if strings.EqualFold(svc.ActiveState, "active") || strings.EqualFold(svc.ActiveState, "running") {
			item.Status = svc.ActiveState
		}
	}
	for _, socket := range sockets {
		matched := false
		for _, p := range socket.Processes {
			if p.PID == proc.PID {
				matched = true
				break
			}
		}
		if !matched {
			continue
		}
		item.Endpoints = append(item.Endpoints, model.DatabaseEndpoint{Protocol: socket.Protocol, Address: socket.Address, Port: socket.Port, Wildcard: socket.Wildcard})
	}
	if len(item.Endpoints) == 0 && def.DefaultPort != 0 {
		// Do not invent a listening address; keep the conventional port only as a
		// weak fallback when the listening-port collector cannot map the PID.
		item.Endpoints = []model.DatabaseEndpoint{{Port: def.DefaultPort}}
	}
	item.ConfigFiles = uniqueSorted(item.ConfigFiles)
	item.SocketPaths = uniqueSorted(item.SocketPaths)
	item.DetectionSources = uniqueSorted(item.DetectionSources)
	return item
}

type instanceServiceContext struct {
	Engine       string
	InstanceName string
	DataDir      string
}

func bestDatabaseService(ctx instanceServiceContext, services []model.ServiceInfo, def databaseDefinition) (model.ServiceInfo, bool) {
	best := model.ServiceInfo{}
	bestScore := -1
	versionCluster := ""
	if ctx.Engine == "postgresql" && ctx.DataDir != "" {
		clean := filepath.Clean(ctx.DataDir)
		parts := strings.Split(strings.Trim(clean, "/"), "/")
		if len(parts) >= 2 {
			versionCluster = parts[len(parts)-2] + "-" + parts[len(parts)-1]
		}
	}
	for _, svc := range services {
		if !databaseServiceMatches(svc.Name, def) {
			continue
		}
		name := strings.ToLower(strings.TrimSpace(svc.Name))
		state := strings.ToLower(strings.TrimSpace(svc.ActiveState))
		score := 10
		if state == "active" || state == "running" {
			score += 100
		}
		if ctx.Engine == "postgresql" {
			if versionCluster != "" && strings.Contains(name, strings.ToLower(versionCluster)) {
				score += 80
			}
			if ctx.InstanceName != "" && strings.Contains(name, strings.ToLower(ctx.InstanceName)) {
				score += 30
			}
			if name == "postgresql.service" || name == "postgresql" {
				score -= 20
			}
		}
		if score > bestScore {
			best = svc
			bestScore = score
		}
	}
	return best, bestScore >= 0
}

func databaseArgsMetadata(engine string, args []string) (dataDir string, configs []string, sockets []string, instance string) {
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() string {
			if i+1 < len(args) {
				return args[i+1]
			}
			return ""
		}
		switch engine {
		case "postgresql":
			if a == "-D" {
				dataDir = next()
			}
			if strings.HasPrefix(a, "--data-directory=") {
				dataDir = strings.TrimPrefix(a, "--data-directory=")
			}
			if strings.HasPrefix(a, "config_file=") {
				configs = append(configs, strings.TrimPrefix(a, "config_file="))
			}
			if a == "-c" && strings.HasPrefix(next(), "config_file=") {
				configs = append(configs, strings.TrimPrefix(next(), "config_file="))
			}
		case "mysql", "mariadb":
			if strings.HasPrefix(a, "--datadir=") {
				dataDir = strings.TrimPrefix(a, "--datadir=")
			}
			if strings.HasPrefix(a, "--defaults-file=") {
				configs = append(configs, strings.TrimPrefix(a, "--defaults-file="))
			}
			if strings.HasPrefix(a, "--socket=") {
				sockets = append(sockets, strings.TrimPrefix(a, "--socket="))
			}
		case "mongodb":
			if a == "--dbpath" {
				dataDir = next()
			}
			if a == "--config" || a == "-f" {
				configs = append(configs, next())
			}
		case "redis":
			if strings.HasSuffix(strings.ToLower(a), ".conf") {
				configs = append(configs, a)
			}
		case "cockroachdb":
			if strings.HasPrefix(a, "--store=") {
				dataDir = strings.TrimPrefix(a, "--store=")
			}
		}
	}
	return strings.TrimSpace(dataDir), cleanPathList(configs), cleanPathList(sockets), strings.TrimSpace(instance)
}

func cleanPathList(values []string) []string {
	out := []string{}
	for _, value := range values {
		value = strings.TrimSpace(strings.Trim(value, "'\""))
		if value != "" {
			out = append(out, value)
		}
	}
	return out
}

func databaseDefaultInstanceName(engine string, proc procDatabase, dataDir string) string {
	if engine == "oracle" && strings.HasPrefix(strings.ToLower(proc.Name), "ora_pmon_") {
		return strings.TrimPrefix(proc.Name, "ora_pmon_")
	}
	if dataDir != "" {
		return filepath.Base(filepath.Clean(dataDir))
	}
	return engine
}

func databaseServiceMatches(name string, def databaseDefinition) bool {
	name = strings.ToLower(strings.TrimSpace(name))
	for _, hint := range def.ServiceHints {
		if strings.Contains(name, strings.ToLower(hint)) {
			return true
		}
	}
	return false
}

func databaseEngineVersion(def databaseDefinition, executable string) string {
	candidates := []string{}
	if executable != "" {
		candidates = append(candidates, executable)
	}
	candidates = append(candidates, def.VersionBinaries...)
	seen := map[string]bool{}
	for _, candidate := range candidates {
		if candidate == "" || seen[candidate] {
			continue
		}
		seen[candidate] = true
		path := candidate
		if !strings.Contains(path, "/") {
			if p, err := exec.LookPath(candidate); err == nil {
				path = p
			} else {
				continue
			}
		}
		args := []string{"--version"}
		if def.Engine == "oracle" && strings.Contains(strings.ToLower(filepath.Base(path)), "sqlplus") {
			args = []string{"-V"}
		}
		if def.Engine == "db2" && strings.Contains(strings.ToLower(filepath.Base(path)), "db2level") {
			args = nil
		}
		out, err := commandOutput(3*time.Second, path, args...)
		if err == nil && strings.TrimSpace(out) != "" {
			return normalizeDatabaseVersion(out)
		}
	}
	return ""
}

func normalizeDatabaseVersion(raw string) string {
	line := strings.TrimSpace(strings.Split(raw, "\n")[0])
	if len(line) > 240 {
		line = line[:240]
	}
	return line
}

func discoverDatabaseCatalogs(instance model.DatabaseInstance, limit int) ([]model.DatabaseCatalog, string) {
	if limit <= 0 {
		limit = 500
	}
	port := 0
	for _, ep := range instance.Endpoints {
		if ep.Port != 0 {
			port = int(ep.Port)
			break
		}
	}
	var names []string
	var err error
	switch instance.Engine {
	case "postgresql":
		names, err = discoverPostgresCatalogs(port, limit)
	case "mysql", "mariadb":
		names, err = discoverMySQLCatalogs(instance.Engine, port, limit)
	case "mongodb":
		names, err = discoverMongoCatalogs(port, limit)
	default:
		return []model.DatabaseCatalog{}, "metadata_only"
	}
	if err != nil {
		return []model.DatabaseCatalog{}, "metadata_only"
	}
	out := make([]model.DatabaseCatalog, 0, len(names))
	for _, name := range names {
		out = append(out, model.DatabaseCatalog{Name: name, Kind: "database", System: databaseSystemCatalog(instance.Engine, name)})
	}
	return out, "discovered"
}

func discoverPostgresCatalogs(port, limit int) ([]string, error) {
	psql, err := exec.LookPath("psql")
	if err != nil {
		return nil, err
	}
	args := []string{"-AtX", "-d", "postgres", "-c", "SELECT datname FROM pg_database WHERE datistemplate=false ORDER BY datname"}
	if port > 0 {
		args = append([]string{"-p", strconv.Itoa(port)}, args...)
	}
	if runuser, err := exec.LookPath("runuser"); err == nil {
		return databaseQueryLines(4*time.Second, limit, runuser, append([]string{"-u", "postgres", "--", psql}, args...)...)
	}
	return databaseQueryLines(4*time.Second, limit, psql, args...)
}

func discoverMySQLCatalogs(engine string, port, limit int) ([]string, error) {
	clientNames := []string{"mariadb", "mysql"}
	if engine == "mysql" {
		clientNames = []string{"mysql", "mariadb"}
	}
	for _, name := range clientNames {
		client, err := exec.LookPath(name)
		if err != nil {
			continue
		}
		args := []string{"--no-defaults", "--protocol=socket", "--batch", "--skip-column-names", "-e", "SHOW DATABASES"}
		lines, err := databaseQueryLines(4*time.Second, limit, client, args...)
		if err == nil {
			return lines, nil
		}
	}
	return nil, fmt.Errorf("local passwordless catalog discovery unavailable")
}

func discoverMongoCatalogs(port, limit int) ([]string, error) {
	for _, name := range []string{"mongosh", "mongo"} {
		client, err := exec.LookPath(name)
		if err != nil {
			continue
		}
		args := []string{"--quiet"}
		if port > 0 {
			args = append(args, "--port", strconv.Itoa(port))
		}
		if name == "mongosh" {
			args = append(args, "--eval", `db.adminCommand({listDatabases:1,nameOnly:true}).databases.map(x=>x.name).join("\n")`)
		} else {
			args = append(args, "--eval", `db.adminCommand({listDatabases:1,nameOnly:true}).databases.forEach(function(x){print(x.name)})`)
		}
		lines, err := databaseQueryLines(4*time.Second, limit, client, args...)
		if err == nil {
			return lines, nil
		}
	}
	return nil, fmt.Errorf("local unauthenticated catalog discovery unavailable")
}

func databaseQueryLines(timeout time.Duration, limit int, binary string, args ...string) ([]string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, args...)
	// Do not inherit common database credential environment variables. Discovery
	// is intentionally limited to local OS/socket access that works without
	// credentials supplied or stored by vm-doc-agent.
	env := make([]string, 0, len(os.Environ())+3)
	for _, item := range os.Environ() {
		key := strings.ToUpper(strings.SplitN(item, "=", 2)[0])
		switch key {
		case "PGPASSWORD", "PGPASSFILE", "PGSERVICE", "PGSERVICEFILE", "MYSQL_PWD":
			continue
		}
		env = append(env, item)
	}
	cmd.Env = append(env, "PGCONNECT_TIMEOUT=2", "PGPASSFILE=/dev/null", "MYSQL_OPT_CONNECT_TIMEOUT=2")
	out, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	values := []string{}
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		values = append(values, line)
		if limit > 0 && len(values) >= limit {
			break
		}
	}
	return uniqueSorted(values), nil
}

func databaseSystemCatalog(engine, name string) bool {
	name = strings.ToLower(strings.TrimSpace(name))
	switch engine {
	case "postgresql":
		return name == "postgres"
	case "mysql", "mariadb":
		return name == "mysql" || name == "information_schema" || name == "performance_schema" || name == "sys"
	case "mongodb":
		return name == "admin" || name == "config" || name == "local"
	default:
		return false
	}
}

func databaseInstanceKey(v model.DatabaseInstance) string {
	parts := []string{v.Engine, v.InstanceName, v.DataDir}
	for _, ep := range v.Endpoints {
		if ep.Port != 0 {
			parts = append(parts, strconv.Itoa(int(ep.Port)))
			break
		}
	}
	return strings.ToLower(strings.Join(parts, "|"))
}

func definitionByEngine(engine string) databaseDefinition {
	for _, def := range databaseDefinitions {
		if def.Engine == engine {
			return def
		}
	}
	return databaseDefinition{Engine: engine, Product: engine}
}
