package collector

import (
	"encoding/json"
	"fmt"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

type dockerInspectObject map[string]any

func collectDocker(limits Limits) (model.DockerInfo, []string) {
	result := model.DockerInfo{Containers: []model.DockerContainer{}, Images: []model.DockerImage{}, Networks: []model.DockerNetwork{}, Volumes: []model.DockerVolume{}, ComposeProjects: []model.DockerComposeProject{}}
	warnings := []string{}
	path, err := exec.LookPath("docker")
	if err != nil {
		return result, warnings
	}
	result.Installed = true
	result.Executable = path
	result.ServiceState = dockerServiceState()

	versionOut, versionErr := commandOutput(5*time.Second, "docker", "version", "--format", "{{.Server.Version}}\t{{.Server.APIVersion}}\t{{.Server.Os}}\t{{.Server.Arch}}")
	if versionErr != nil {
		client, _ := commandOutput(3*time.Second, "docker", "--version")
		result.Version = normalizeDockerClientVersion(client)
		warnings = append(warnings, fmt.Sprintf("docker: engine is not reachable: %v", versionErr))
		return result, warnings
	}
	result.Available = true
	parts := strings.Split(versionOut, "\t")
	if len(parts) > 0 {
		result.Version = cleanDockerValue(parts[0])
	}
	if len(parts) > 1 {
		result.APIVersion = cleanDockerValue(parts[1])
	}
	if len(parts) > 2 {
		result.OS = cleanDockerValue(parts[2])
	}
	if len(parts) > 3 {
		result.Architecture = cleanDockerValue(parts[3])
	}

	if infoOut, infoErr := commandOutput(5*time.Second, "docker", "info"); infoErr == nil {
		parseDockerInfo(infoOut, &result)
	} else {
		warnings = append(warnings, fmt.Sprintf("docker: docker info: %v", infoErr))
	}

	containerIDs, detectedContainers, err := dockerIDs("container", limits.MaxDockerContainers)
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("docker: list containers: %v", err))
	} else {
		if detectedContainers > len(containerIDs) {
			warnings = append(warnings, fmt.Sprintf("docker: containers limited: detected=%d collected=%d", detectedContainers, len(containerIDs)))
		}
		objects, errs := dockerInspectBatches("inspect", containerIDs, 40)
		warnings = append(warnings, errs...)
		for _, object := range objects {
			result.Containers = append(result.Containers, parseDockerContainer(object))
		}
	}

	imageIDs, detectedImages, err := dockerIDs("image", limits.MaxDockerImages)
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("docker: list images: %v", err))
	} else {
		if detectedImages > len(imageIDs) {
			warnings = append(warnings, fmt.Sprintf("docker: images limited: detected=%d collected=%d", detectedImages, len(imageIDs)))
		}
		objects, errs := dockerInspectBatches("image", imageIDs, 40)
		warnings = append(warnings, errs...)
		for _, object := range objects {
			result.Images = append(result.Images, parseDockerImage(object))
		}
	}

	networkIDs, detectedNetworks, err := dockerIDs("network", limits.MaxDockerNetworks)
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("docker: list networks: %v", err))
	} else {
		if detectedNetworks > len(networkIDs) {
			warnings = append(warnings, fmt.Sprintf("docker: networks limited: detected=%d collected=%d", detectedNetworks, len(networkIDs)))
		}
		objects, errs := dockerInspectBatches("network", networkIDs, 40)
		warnings = append(warnings, errs...)
		for _, object := range objects {
			result.Networks = append(result.Networks, parseDockerNetwork(object))
		}
	}

	volumeNames, detectedVolumes, err := dockerIDs("volume", limits.MaxDockerVolumes)
	if err != nil {
		warnings = append(warnings, fmt.Sprintf("docker: list volumes: %v", err))
	} else {
		if detectedVolumes > len(volumeNames) {
			warnings = append(warnings, fmt.Sprintf("docker: volumes limited: detected=%d collected=%d", detectedVolumes, len(volumeNames)))
		}
		objects, errs := dockerInspectBatches("volume", volumeNames, 40)
		warnings = append(warnings, errs...)
		for _, object := range objects {
			result.Volumes = append(result.Volumes, parseDockerVolume(object))
		}
	}

	result.ComposeProjects = dockerComposeProjects(result.Containers)
	sort.Slice(result.Containers, func(i, j int) bool {
		return strings.ToLower(result.Containers[i].Name) < strings.ToLower(result.Containers[j].Name)
	})
	sort.Slice(result.Images, func(i, j int) bool { return dockerImageLabel(result.Images[i]) < dockerImageLabel(result.Images[j]) })
	sort.Slice(result.Networks, func(i, j int) bool {
		return strings.ToLower(result.Networks[i].Name) < strings.ToLower(result.Networks[j].Name)
	})
	sort.Slice(result.Volumes, func(i, j int) bool {
		return strings.ToLower(result.Volumes[i].Name) < strings.ToLower(result.Volumes[j].Name)
	})
	return result, uniqueSorted(warnings)
}

func dockerServiceState() string {
	if _, err := exec.LookPath("systemctl"); err == nil {
		if out, err := commandOutput(2*time.Second, "systemctl", "is-active", "docker"); err == nil || strings.TrimSpace(out) != "" {
			return strings.TrimSpace(out)
		}
	}
	if _, err := exec.LookPath("service"); err == nil {
		if _, err := commandOutput(2*time.Second, "service", "docker", "status"); err == nil {
			return "active"
		}
	}
	return "unknown"
}

func dockerIDs(kind string, limit int) ([]string, int, error) {
	var args []string
	switch kind {
	case "container":
		args = []string{"ps", "-aq", "--no-trunc"}
	case "image":
		args = []string{"image", "ls", "-aq", "--no-trunc"}
	case "network":
		args = []string{"network", "ls", "-q", "--no-trunc"}
	case "volume":
		args = []string{"volume", "ls", "-q"}
	default:
		return nil, 0, fmt.Errorf("unsupported Docker object %s", kind)
	}
	out, err := commandOutput(5*time.Second, "docker", args...)
	if err != nil {
		return nil, 0, err
	}
	values := uniqueSorted(strings.Fields(out))
	detected := len(values)
	if limit > 0 && len(values) > limit {
		values = values[:limit]
	}
	return values, detected, nil
}

func dockerInspectBatches(kind string, ids []string, batchSize int) ([]dockerInspectObject, []string) {
	objects := []dockerInspectObject{}
	warnings := []string{}
	if batchSize < 1 {
		batchSize = 40
	}
	for start := 0; start < len(ids); start += batchSize {
		end := start + batchSize
		if end > len(ids) {
			end = len(ids)
		}
		args := []string{}
		switch kind {
		case "image":
			args = append(args, "image", "inspect")
		case "network":
			args = append(args, "network", "inspect")
		case "volume":
			args = append(args, "volume", "inspect")
		default:
			args = append(args, "inspect")
		}
		args = append(args, ids[start:end]...)
		out, err := commandOutput(8*time.Second, "docker", args...)
		if err != nil {
			warnings = append(warnings, fmt.Sprintf("docker: %s inspect batch %d-%d: %v", kind, start+1, end, err))
			continue
		}
		var batch []dockerInspectObject
		if err := json.Unmarshal([]byte(out), &batch); err != nil {
			warnings = append(warnings, fmt.Sprintf("docker: decode %s inspect batch %d-%d: %v", kind, start+1, end, err))
			continue
		}
		objects = append(objects, batch...)
	}
	return objects, warnings
}

func parseDockerInfo(raw string, out *model.DockerInfo) {
	for _, line := range strings.Split(raw, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		parts := strings.SplitN(line, ":", 2)
		if len(parts) != 2 {
			continue
		}
		key, value := strings.TrimSpace(parts[0]), strings.TrimSpace(parts[1])
		switch key {
		case "Storage Driver":
			out.StorageDriver = value
		case "Logging Driver":
			out.LoggingDriver = value
		case "Cgroup Driver":
			out.CgroupDriver = value
		case "Cgroup Version":
			out.CgroupVersion = value
		case "Docker Root Dir":
			out.DockerRootDir = value
		}
	}
}

func parseDockerContainer(v dockerInspectObject) model.DockerContainer {
	config := mapAt(v, "Config")
	host := mapAt(v, "HostConfig")
	state := mapAt(v, "State")
	networkSettings := mapAt(v, "NetworkSettings")
	labels := safeDockerLabels(stringMapAt(config, "Labels"))
	name := strings.TrimPrefix(stringAt(v, "Name"), "/")
	item := model.DockerContainer{
		ID:                       stringAt(v, "Id"),
		Name:                     name,
		Image:                    stringAt(config, "Image"),
		ImageID:                  stringAt(v, "Image"),
		State:                    stringAt(state, "Status"),
		Status:                   dockerContainerStatus(state),
		Health:                   stringAt(mapAt(state, "Health"), "Status"),
		CreatedAt:                dockerTime(stringAt(v, "Created")),
		StartedAt:                dockerTime(stringAt(state, "StartedAt")),
		FinishedAt:               dockerTime(stringAt(state, "FinishedAt")),
		RestartPolicy:            stringAt(mapAt(host, "RestartPolicy"), "Name"),
		RestartMaximumRetryCount: int(numberAt(mapAt(host, "RestartPolicy"), "MaximumRetryCount")),
		Privileged:               boolAt(host, "Privileged"),
		ReadonlyRootFS:           boolAt(host, "ReadonlyRootfs"),
		NetworkMode:              stringAt(host, "NetworkMode"),
		User:                     stringAt(config, "User"),
		WorkingDir:               stringAt(config, "WorkingDir"),
		MemoryLimitBytes:         int64(numberAt(host, "Memory")),
		NanoCPUs:                 int64(numberAt(host, "NanoCpus")),
		CPUQuota:                 int64(numberAt(host, "CpuQuota")),
		CPUPeriod:                int64(numberAt(host, "CpuPeriod")),
		PidsLimit:                int64(numberAt(host, "PidsLimit")),
		CapAdd:                   stringSliceAt(host, "CapAdd"),
		SecurityOpt:              stringSliceAt(host, "SecurityOpt"),
		EnvironmentKeys:          dockerEnvironmentKeys(stringSliceAt(config, "Env")),
		Labels:                   labels,
		ComposeProject:           labels["com.docker.compose.project"],
		ComposeService:           labels["com.docker.compose.service"],
		ComposeWorkingDir:        labels["com.docker.compose.project.working_dir"],
		ComposeConfigFiles:       splitComposeFiles(labels["com.docker.compose.project.config_files"]),
	}
	item.Ports = dockerPorts(networkSettings)
	item.Mounts = dockerMounts(v)
	for _, mount := range item.Mounts {
		if dockerSocketPath(mount.Source) || dockerSocketPath(mount.Destination) {
			item.DockerSocketMounted = true
		}
	}
	item.Networks = dockerContainerNetworks(networkSettings)
	return item
}

func dockerContainerStatus(state map[string]any) string {
	status := stringAt(state, "Status")
	if health := stringAt(mapAt(state, "Health"), "Status"); health != "" {
		return strings.TrimSpace(status + " (" + health + ")")
	}
	return status
}

func dockerPorts(networkSettings map[string]any) []model.DockerPort {
	out := []model.DockerPort{}
	ports := mapAt(networkSettings, "Ports")
	keys := make([]string, 0, len(ports))
	for key := range ports {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		containerPort, proto := parseDockerPortKey(key)
		bindings, _ := ports[key].([]any)
		if len(bindings) == 0 {
			out = append(out, model.DockerPort{ContainerPort: containerPort, Protocol: proto})
			continue
		}
		for _, raw := range bindings {
			binding, _ := raw.(map[string]any)
			hostPort, _ := strconv.Atoi(strings.TrimSpace(stringAt(binding, "HostPort")))
			out = append(out, model.DockerPort{ContainerPort: containerPort, Protocol: proto, HostIP: stringAt(binding, "HostIp"), HostPort: hostPort})
		}
	}
	return out
}

func parseDockerPortKey(value string) (int, string) {
	parts := strings.SplitN(value, "/", 2)
	port, _ := strconv.Atoi(parts[0])
	proto := "tcp"
	if len(parts) == 2 && strings.TrimSpace(parts[1]) != "" {
		proto = parts[1]
	}
	return port, proto
}

func dockerMounts(v dockerInspectObject) []model.DockerMount {
	out := []model.DockerMount{}
	values, _ := v["Mounts"].([]any)
	for _, raw := range values {
		mount, _ := raw.(map[string]any)
		out = append(out, model.DockerMount{Type: stringAt(mount, "Type"), Name: stringAt(mount, "Name"), Source: stringAt(mount, "Source"), Destination: stringAt(mount, "Destination"), ReadOnly: !boolAt(mount, "RW")})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Destination < out[j].Destination })
	return out
}

func dockerContainerNetworks(networkSettings map[string]any) []model.DockerContainerNetwork {
	out := []model.DockerContainerNetwork{}
	networks := mapAt(networkSettings, "Networks")
	keys := make([]string, 0, len(networks))
	for key := range networks {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, name := range keys {
		value, _ := networks[name].(map[string]any)
		out = append(out, model.DockerContainerNetwork{Name: name, NetworkID: stringAt(value, "NetworkID"), IPAddress: stringAt(value, "IPAddress"), Gateway: stringAt(value, "Gateway"), MacAddress: stringAt(value, "MacAddress")})
	}
	return out
}

func parseDockerImage(v dockerInspectObject) model.DockerImage {
	return model.DockerImage{ID: stringAt(v, "Id"), RepoTags: stringSliceAt(v, "RepoTags"), RepoDigests: stringSliceAt(v, "RepoDigests"), CreatedAt: dockerTime(stringAt(v, "Created")), SizeBytes: int64(numberAt(v, "Size")), Architecture: stringAt(v, "Architecture"), OS: stringAt(v, "Os")}
}

func parseDockerNetwork(v dockerInspectObject) model.DockerNetwork {
	item := model.DockerNetwork{ID: stringAt(v, "Id"), Name: stringAt(v, "Name"), Driver: stringAt(v, "Driver"), Scope: stringAt(v, "Scope"), Internal: boolAt(v, "Internal"), Attachable: boolAt(v, "Attachable"), Ingress: boolAt(v, "Ingress"), Labels: safeDockerLabels(stringMapAt(v, "Labels"))}
	ipam := mapAt(v, "IPAM")
	configs, _ := ipam["Config"].([]any)
	for _, raw := range configs {
		cfg, _ := raw.(map[string]any)
		item.IPAM = append(item.IPAM, model.DockerIPAMConfig{Subnet: stringAt(cfg, "Subnet"), Gateway: stringAt(cfg, "Gateway")})
	}
	return item
}

func parseDockerVolume(v dockerInspectObject) model.DockerVolume {
	return model.DockerVolume{Name: stringAt(v, "Name"), Driver: stringAt(v, "Driver"), Mountpoint: stringAt(v, "Mountpoint"), Scope: stringAt(v, "Scope"), Labels: safeDockerLabels(stringMapAt(v, "Labels"))}
}

func dockerComposeProjects(containers []model.DockerContainer) []model.DockerComposeProject {
	type aggregate struct {
		workingDir string
		files      map[string]bool
		services   map[string]bool
		count      int
	}
	projects := map[string]*aggregate{}
	for _, container := range containers {
		name := strings.TrimSpace(container.ComposeProject)
		if name == "" {
			continue
		}
		item := projects[name]
		if item == nil {
			item = &aggregate{files: map[string]bool{}, services: map[string]bool{}}
			projects[name] = item
		}
		item.count++
		if item.workingDir == "" {
			item.workingDir = container.ComposeWorkingDir
		}
		for _, file := range container.ComposeConfigFiles {
			item.files[file] = true
		}
		if container.ComposeService != "" {
			item.services[container.ComposeService] = true
		}
	}
	keys := make([]string, 0, len(projects))
	for key := range projects {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	out := make([]model.DockerComposeProject, 0, len(keys))
	for _, key := range keys {
		agg := projects[key]
		out = append(out, model.DockerComposeProject{Name: key, WorkingDir: agg.workingDir, ConfigFiles: sortedMapKeys(agg.files), Services: sortedMapKeys(agg.services), ContainerCount: agg.count})
	}
	return out
}

func safeDockerLabels(values map[string]string) map[string]string {
	if len(values) == 0 {
		return nil
	}
	out := map[string]string{}
	for key, value := range values {
		key = strings.TrimSpace(key)
		if key == "" {
			continue
		}
		if dockerSensitiveKey(key) {
			out[key] = "[REDACTED]"
			continue
		}
		out[key] = truncateString(strings.TrimSpace(value), 2048)
	}
	return out
}

func dockerSensitiveKey(key string) bool {
	lower := strings.ToLower(key)
	for _, token := range []string{"password", "passwd", "secret", "token", "api_key", "apikey", "access_key", "private_key", "credential"} {
		if strings.Contains(lower, token) {
			return true
		}
	}
	return false
}

func dockerEnvironmentKeys(values []string) []string {
	out := make([]string, 0, len(values))
	for _, value := range values {
		key := strings.TrimSpace(strings.SplitN(value, "=", 2)[0])
		if key != "" {
			out = append(out, key)
		}
	}
	return uniqueSorted(out)
}

func dockerSocketPath(value string) bool {
	value = strings.TrimSpace(value)
	return value == "/var/run/docker.sock" || strings.HasSuffix(value, "/docker.sock")
}

func splitComposeFiles(value string) []string {
	value = strings.TrimSpace(value)
	if value == "" {
		return nil
	}
	parts := strings.FieldsFunc(value, func(r rune) bool { return r == ',' || r == ';' })
	return uniqueSorted(parts)
}

func normalizeDockerClientVersion(value string) string {
	value = strings.TrimSpace(value)
	if strings.HasPrefix(strings.ToLower(value), "docker version ") {
		value = strings.TrimSpace(strings.TrimPrefix(value, "Docker version "))
		value = strings.TrimSpace(strings.TrimPrefix(value, "docker version "))
	}
	if i := strings.Index(value, ","); i > 0 {
		value = value[:i]
	}
	return strings.TrimSpace(value)
}

func cleanDockerValue(value string) string {
	value = strings.TrimSpace(value)
	if value == "<no value>" {
		return ""
	}
	return value
}

func dockerImageLabel(image model.DockerImage) string {
	if len(image.RepoTags) > 0 {
		return strings.ToLower(image.RepoTags[0])
	}
	return strings.ToLower(image.ID)
}

func dockerTime(value string) *time.Time {
	value = strings.TrimSpace(value)
	if value == "" || strings.HasPrefix(value, "0001-01-01") {
		return nil
	}
	for _, layout := range []string{time.RFC3339Nano, time.RFC3339} {
		if parsed, err := time.Parse(layout, value); err == nil {
			parsed = parsed.UTC()
			return &parsed
		}
	}
	return nil
}

func mapAt(v map[string]any, key string) map[string]any {
	value, _ := v[key].(map[string]any)
	if value == nil {
		return map[string]any{}
	}
	return value
}

func stringAt(v map[string]any, key string) string {
	value, ok := v[key]
	if !ok || value == nil {
		return ""
	}
	if text, ok := value.(string); ok {
		return strings.TrimSpace(text)
	}
	return strings.TrimSpace(fmt.Sprint(value))
}

func boolAt(v map[string]any, key string) bool {
	value, _ := v[key].(bool)
	return value
}

func numberAt(v map[string]any, key string) float64 {
	switch value := v[key].(type) {
	case float64:
		return value
	case json.Number:
		result, _ := value.Float64()
		return result
	case int:
		return float64(value)
	case int64:
		return float64(value)
	case string:
		result, _ := strconv.ParseFloat(value, 64)
		return result
	default:
		return 0
	}
}

func stringSliceAt(v map[string]any, key string) []string {
	value := v[key]
	out := []string{}
	switch typed := value.(type) {
	case []any:
		for _, raw := range typed {
			if text := strings.TrimSpace(fmt.Sprint(raw)); text != "" && text != "<nil>" {
				out = append(out, text)
			}
		}
	case []string:
		out = append(out, typed...)
	}
	return uniqueSorted(out)
}

func stringMapAt(v map[string]any, key string) map[string]string {
	value, _ := v[key].(map[string]any)
	out := map[string]string{}
	for k, raw := range value {
		if raw == nil {
			continue
		}
		out[k] = strings.TrimSpace(fmt.Sprint(raw))
	}
	return out
}

func sortedMapKeys(values map[string]bool) []string {
	out := make([]string, 0, len(values))
	for key := range values {
		out = append(out, key)
	}
	sort.Strings(out)
	return out
}
