package collector

import (
	"testing"

	"vm-doc-agent/internal/model"
)

func TestParseDockerContainerSanitizesSecretsAndBuildsCompose(t *testing.T) {
	v := dockerInspectObject{
		"Id":      "abc123",
		"Name":    "/portal-app",
		"Image":   "sha256:img",
		"Created": "2026-09-05T05:00:00Z",
		"Config": map[string]any{
			"Image":      "registry.local/portal:2.8.1",
			"User":       "1000",
			"WorkingDir": "/app",
			"Env":        []any{"DB_HOST=db", "DB_PASSWORD=secret", "EMPTY"},
			"Labels": map[string]any{
				"com.docker.compose.project": "portal",
				"com.docker.compose.service": "app",
				"vm-doc.service":             "portal-intern",
				"api_token":                  "do-not-store",
			},
		},
		"HostConfig": map[string]any{
			"Privileged":     true,
			"ReadonlyRootfs": false,
			"NetworkMode":    "portal_backend",
			"RestartPolicy":  map[string]any{"Name": "unless-stopped", "MaximumRetryCount": float64(0)},
			"Memory":         float64(1073741824),
		},
		"State": map[string]any{"Status": "running", "StartedAt": "2026-09-05T05:01:00Z", "Health": map[string]any{"Status": "healthy"}},
		"NetworkSettings": map[string]any{
			"Ports":    map[string]any{"8080/tcp": []any{map[string]any{"HostIp": "0.0.0.0", "HostPort": "18080"}}},
			"Networks": map[string]any{"portal_backend": map[string]any{"NetworkID": "net1", "IPAddress": "172.19.0.4", "Gateway": "172.19.0.1"}},
		},
		"Mounts": []any{map[string]any{"Type": "bind", "Source": "/var/run/docker.sock", "Destination": "/var/run/docker.sock", "RW": true}},
	}
	got := parseDockerContainer(v)
	if got.Name != "portal-app" || got.ComposeProject != "portal" || got.ComposeService != "app" {
		t.Fatalf("unexpected identity: %#v", got)
	}
	if got.Labels["api_token"] != "[REDACTED]" {
		t.Fatalf("secret label was not redacted: %#v", got.Labels)
	}
	if len(got.EnvironmentKeys) != 3 || got.EnvironmentKeys[1] != "DB_PASSWORD" {
		t.Fatalf("environment keys unexpected: %#v", got.EnvironmentKeys)
	}
	if !got.DockerSocketMounted || !got.Privileged || got.Health != "healthy" {
		t.Fatalf("security/runtime metadata missing: %#v", got)
	}
	if len(got.Ports) != 1 || got.Ports[0].HostPort != 18080 {
		t.Fatalf("port mapping missing: %#v", got.Ports)
	}
}

func TestDockerComposeProjectsGroupsContainers(t *testing.T) {
	values := dockerComposeProjects([]model.DockerContainer{
		{Name: "a", ComposeProject: "portal", ComposeService: "app", ComposeWorkingDir: "/srv/portal", ComposeConfigFiles: []string{"compose.yml"}},
		{Name: "b", ComposeProject: "portal", ComposeService: "db", ComposeWorkingDir: "/srv/portal", ComposeConfigFiles: []string{"compose.yml"}},
	})
	if len(values) != 1 || values[0].ContainerCount != 2 || len(values[0].Services) != 2 {
		t.Fatalf("unexpected projects: %#v", values)
	}
}
