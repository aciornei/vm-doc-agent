package collector

import (
	"errors"
	"fmt"
	"os"
	"runtime"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
	"vm-doc-agent/internal/platform"
	"vm-doc-agent/internal/version"
)

const (
	AgentName     = "vm-doc-agent"
	SchemaVersion = "2.3"
)

type EnabledCollectors struct {
	System         bool
	Storage        bool
	Network        bool
	Proxy          bool
	Services       bool
	ListeningPorts bool
	Firewall       bool
	Accounts       bool
	SSSD           bool
	Integrations   bool
	Policies       bool
	Cron           bool
	NTP            bool
	Docker         bool
	Databases      bool
	Web            bool
}

type Limits struct {
	MaxPartitions        int
	MaxRoutes            int
	MaxServices          int
	MaxPorts             int
	MaxFirewallRules     int
	MaxFirewallZones     int
	MaxAccounts          int
	MaxCronEntries       int
	MaxCronScripts       int
	MaxPolicyFiles       int
	MaxInventoryBytes    int
	MaxDockerContainers  int
	MaxDockerImages      int
	MaxDockerNetworks    int
	MaxDockerVolumes     int
	MaxDatabaseInstances int
	MaxDatabaseCatalogs  int
	MaxWebServers        int
	MaxWebSites          int
}

type Options struct {
	StateDir          string
	PolicyPaths       []string
	Enabled           EnabledCollectors
	EnabledConfigured bool
	CollectorTimeout  time.Duration
	OutputTestTimeout time.Duration
	Limits            Limits
}

type timedResult[T any] struct {
	value    T
	warnings []string
	err      error
}

func Collect(options Options) (model.Inventory, error) {
	options = normalizeOptions(options)
	started := time.Now().UTC()
	statuses := map[string]model.CollectorStatus{}
	allWarnings := []string{}

	identityStarted := time.Now().UTC()
	hostname, err := os.Hostname()
	if err != nil {
		return model.Inventory{}, fmt.Errorf("read hostname: %w", err)
	}
	if strings.TrimSpace(options.StateDir) == "" {
		return model.Inventory{}, errors.New("state directory is required")
	}
	agentID, err := ensureAgentID(options.StateDir)
	if err != nil {
		return model.Inventory{}, err
	}
	productUUID, source := collectProductUUID()
	machineID := readMachineID()
	primary := chooseCorrelationUUID(productUUID, machineID, agentID)
	osInfo := platform.CollectOS("/")
	identityCompleted := time.Now().UTC()
	statuses["identity"] = model.CollectorStatus{
		Status: "success", StartedAt: timePointer(identityStarted), CollectedAt: timePointer(identityCompleted),
		DurationMS: identityCompleted.Sub(identityStarted).Milliseconds(),
	}

	systemInfo, systemStatus, systemWarnings := runCollector("system", options.Enabled.System, options.CollectorTimeout, collectSystem)
	statuses["system"] = systemStatus
	allWarnings = append(allWarnings, systemWarnings...)

	partitions, storageStatus, storageWarnings := runCollector("storage", options.Enabled.Storage, options.CollectorTimeout, collectPartitions)
	statuses["storage"] = storageStatus
	allWarnings = append(allWarnings, storageWarnings...)

	networkInfo, networkStatus, networkWarnings := runCollector("network", options.Enabled.Network, options.CollectorTimeout, collectNetwork)
	statuses["network"] = networkStatus
	allWarnings = append(allWarnings, networkWarnings...)

	proxyInfo, proxyStatus, proxyWarnings := runCollector("proxy", options.Enabled.Proxy, options.CollectorTimeout, collectProxy)
	statuses["proxy"] = proxyStatus
	allWarnings = append(allWarnings, proxyWarnings...)

	services, servicesStatus, servicesWarnings := runCollector("services", options.Enabled.Services, options.CollectorTimeout, func() ([]model.ServiceInfo, []string) {
		return collectServices(osInfo.InitSystem, osInfo.Family)
	})
	statuses["services"] = servicesStatus
	allWarnings = append(allWarnings, servicesWarnings...)

	listeningPorts, portsStatus, portsWarnings := runCollector("listening_ports", options.Enabled.ListeningPorts, options.CollectorTimeout, collectListeningPorts)
	statuses["listening_ports"] = portsStatus
	allWarnings = append(allWarnings, portsWarnings...)

	firewall, firewallStatus, firewallWarnings := runCollector("firewall", options.Enabled.Firewall, options.CollectorTimeout, collectFirewall)
	statuses["firewall"] = firewallStatus
	allWarnings = append(allWarnings, firewallWarnings...)

	accounts, accountsStatus, accountWarnings := runCollector("accounts", options.Enabled.Accounts, options.CollectorTimeout, collectAccounts)
	statuses["accounts"] = accountsStatus
	allWarnings = append(allWarnings, accountWarnings...)

	sssd, sssdStatus, sssdWarnings := runCollector("sssd", options.Enabled.SSSD, options.CollectorTimeout, func() (model.SSSDInfo, []string) {
		value, warnings := collectSSSD(services)
		if !options.Enabled.Services {
			warnings = append(warnings, "sssd: services collector is disabled; service state may be incomplete")
		}
		return value, warnings
	})
	statuses["sssd"] = sssdStatus
	allWarnings = append(allWarnings, sssdWarnings...)

	integrations, integrationsStatus, integrationWarnings := runCollector("integrations", options.Enabled.Integrations, options.CollectorTimeout, func() (model.IntegrationsInfo, []string) {
		value, warnings := collectIntegrations(services, listeningPorts, options.OutputTestTimeout)
		if !options.Enabled.Services {
			warnings = append(warnings, "integrations: services collector is disabled; service state may be incomplete")
		}
		if !options.Enabled.ListeningPorts {
			warnings = append(warnings, "integrations: listening_ports collector is disabled; Node Exporter endpoint discovery may be incomplete")
		}
		return value, warnings
	})
	statuses["integrations"] = integrationsStatus
	allWarnings = append(allWarnings, integrationWarnings...)

	policies, policiesStatus, policyWarnings := runCollector("policies", options.Enabled.Policies, options.CollectorTimeout, func() (model.PoliciesInfo, []string) {
		return collectPolicies(options.PolicyPaths)
	})
	statuses["policies"] = policiesStatus
	allWarnings = append(allWarnings, policyWarnings...)

	cronInfo, cronStatus, cronWarnings := runCollector("cron", options.Enabled.Cron, options.CollectorTimeout, collectCron)
	statuses["cron"] = cronStatus
	allWarnings = append(allWarnings, cronWarnings...)

	ntpInfo, ntpStatus, ntpWarnings := runCollector("ntp", options.Enabled.NTP, options.CollectorTimeout, func() (model.NTPInfo, []string) {
		value, warnings := collectNTP(services)
		if !options.Enabled.Services {
			warnings = append(warnings, "ntp: services collector is disabled; service state may be incomplete")
		}
		return value, warnings
	})
	statuses["ntp"] = ntpStatus
	allWarnings = append(allWarnings, ntpWarnings...)

	dockerInfo, dockerStatus, dockerWarnings := runCollector("docker", options.Enabled.Docker, options.CollectorTimeout, func() (model.DockerInfo, []string) {
		return collectDocker(options.Limits)
	})
	statuses["docker"] = dockerStatus
	allWarnings = append(allWarnings, dockerWarnings...)

	databaseInfo, databaseStatus, databaseWarnings := runCollector("databases", options.Enabled.Databases, options.CollectorTimeout, func() (model.DatabaseInfo, []string) {
		return collectDatabases(services, listeningPorts, options.Limits)
	})
	statuses["databases"] = databaseStatus
	allWarnings = append(allWarnings, databaseWarnings...)

	webInfo, webStatus, webWarnings := runCollector("web", options.Enabled.Web, options.CollectorTimeout, func() (model.WebInfo, []string) {
		return collectWeb(services, listeningPorts, options.Limits)
	})
	statuses["web"] = webStatus
	allWarnings = append(allWarnings, webWarnings...)

	completed := time.Now().UTC()
	inventory := model.Inventory{
		SchemaVersion: SchemaVersion,
		Agent:         model.AgentInfo{Name: AgentName, Version: version.Version, ID: agentID, Commit: version.Commit, BuildDate: version.BuildDate},
		CollectedAt:   completed,
		Collection: model.CollectionInfo{
			StartedAt: started, CompletedAt: completed, DurationMS: completed.Sub(started).Milliseconds(),
			Status: collectionStatus(statuses), Collectors: statuses,
		},
		Host: model.HostInfo{
			Hostname: hostname, FQDN: detectFQDN(hostname), MachineID: machineID,
			ProductUUID: productUUID, ProductUUIDSource: source,
			ProductName: readTrimmed("/sys/class/dmi/id/product_name"), ProductVendor: readTrimmed("/sys/class/dmi/id/sys_vendor"),
			SerialNumber: collectSerialNumber(), Virtualization: detectVirtualization(), CorrelationUUID: primary,
			Correlation: model.CorrelationInfo{Primary: primary, DMIProductUUID: productUUID, SMBIOSLegacyByteOrder: smbiosLegacyByteOrder(productUUID), MachineID: machineID, AgentID: agentID},
		},
		OS: osInfo, System: systemInfo,
		Storage: model.StorageInfo{Partitions: partitions}, Network: networkInfo, Proxy: proxyInfo,
		Services: services, ListeningPorts: listeningPorts, Firewall: firewall, Accounts: accounts,
		SSSD: sssd, Integrations: integrations, Policies: policies, Cron: cronInfo, NTP: ntpInfo, Docker: dockerInfo, Databases: databaseInfo, Web: webInfo,
		Truncations: map[string]model.TruncationInfo{}, CollectionWarnings: uniqueSorted(allWarnings),
	}
	applyLimits(&inventory, options.Limits)
	inventory.Collection.Status = collectionStatus(inventory.Collection.Collectors)
	return inventory, nil
}

func runCollector[T any](name string, enabled bool, timeout time.Duration, function func() (T, []string)) (T, model.CollectorStatus, []string) {
	var zero T
	if !enabled {
		return zero, model.CollectorStatus{Status: "disabled"}, nil
	}
	started := time.Now().UTC()
	channel := make(chan timedResult[T], 1)
	go func() {
		result := timedResult[T]{}
		defer func() {
			if recovered := recover(); recovered != nil {
				result.err = fmt.Errorf("panic: %v", recovered)
			}
			channel <- result
		}()
		result.value, result.warnings = function()
	}()

	select {
	case result := <-channel:
		completed := time.Now().UTC()
		status := model.CollectorStatus{StartedAt: timePointer(started), CollectedAt: timePointer(completed), DurationMS: completed.Sub(started).Milliseconds()}
		if result.err != nil {
			status.Status = "error"
			status.Error = result.err.Error()
			warning := fmt.Sprintf("%s: %v", name, result.err)
			return zero, status, []string{warning}
		}
		status.WarningCount = len(result.warnings)
		status.Warnings = firstStrings(result.warnings, 20)
		if len(result.warnings) > 0 {
			status.Status = "partial"
		} else {
			status.Status = "success"
		}
		return result.value, status, result.warnings
	case <-time.After(timeout):
		completed := time.Now().UTC()
		message := fmt.Sprintf("%s: collector timed out after %s", name, timeout)
		status := model.CollectorStatus{
			Status: "timeout", StartedAt: timePointer(started), CollectedAt: timePointer(completed),
			DurationMS: completed.Sub(started).Milliseconds(), Error: message,
		}
		return zero, status, []string{message}
	}
}

func normalizeOptions(options Options) Options {
	if options.CollectorTimeout <= 0 {
		options.CollectorTimeout = 20 * time.Second
	}
	if options.OutputTestTimeout <= 0 {
		options.OutputTestTimeout = 12 * time.Second
	}
	if !options.EnabledConfigured {
		options.Enabled = EnabledCollectors{System: true, Storage: true, Network: true, Proxy: true, Services: true, ListeningPorts: true, Firewall: true, Accounts: true, SSSD: true, Integrations: true, Policies: true, Cron: true, NTP: true, Docker: true, Databases: true, Web: true}
	}
	defaults := Limits{MaxPartitions: 1000, MaxRoutes: 5000, MaxServices: 5000, MaxPorts: 5000, MaxFirewallRules: 10000, MaxFirewallZones: 1000, MaxAccounts: 10000, MaxCronEntries: 5000, MaxCronScripts: 5000, MaxPolicyFiles: 10000, MaxInventoryBytes: 20 * 1024 * 1024, MaxDockerContainers: 2000, MaxDockerImages: 5000, MaxDockerNetworks: 1000, MaxDockerVolumes: 2000, MaxDatabaseInstances: 500, MaxDatabaseCatalogs: 2000, MaxWebServers: 100, MaxWebSites: 5000}
	if options.Limits.MaxPartitions <= 0 {
		options.Limits.MaxPartitions = defaults.MaxPartitions
	}
	if options.Limits.MaxRoutes <= 0 {
		options.Limits.MaxRoutes = defaults.MaxRoutes
	}
	if options.Limits.MaxServices <= 0 {
		options.Limits.MaxServices = defaults.MaxServices
	}
	if options.Limits.MaxPorts <= 0 {
		options.Limits.MaxPorts = defaults.MaxPorts
	}
	if options.Limits.MaxFirewallRules <= 0 {
		options.Limits.MaxFirewallRules = defaults.MaxFirewallRules
	}
	if options.Limits.MaxFirewallZones <= 0 {
		options.Limits.MaxFirewallZones = defaults.MaxFirewallZones
	}
	if options.Limits.MaxAccounts <= 0 {
		options.Limits.MaxAccounts = defaults.MaxAccounts
	}
	if options.Limits.MaxCronEntries <= 0 {
		options.Limits.MaxCronEntries = defaults.MaxCronEntries
	}
	if options.Limits.MaxCronScripts <= 0 {
		options.Limits.MaxCronScripts = defaults.MaxCronScripts
	}
	if options.Limits.MaxPolicyFiles <= 0 {
		options.Limits.MaxPolicyFiles = defaults.MaxPolicyFiles
	}
	if options.Limits.MaxInventoryBytes <= 0 {
		options.Limits.MaxInventoryBytes = defaults.MaxInventoryBytes
	}
	if options.Limits.MaxDockerContainers <= 0 {
		options.Limits.MaxDockerContainers = defaults.MaxDockerContainers
	}
	if options.Limits.MaxDockerImages <= 0 {
		options.Limits.MaxDockerImages = defaults.MaxDockerImages
	}
	if options.Limits.MaxDockerNetworks <= 0 {
		options.Limits.MaxDockerNetworks = defaults.MaxDockerNetworks
	}
	if options.Limits.MaxDockerVolumes <= 0 {
		options.Limits.MaxDockerVolumes = defaults.MaxDockerVolumes
	}
	if options.Limits.MaxDatabaseInstances <= 0 {
		options.Limits.MaxDatabaseInstances = defaults.MaxDatabaseInstances
	}
	if options.Limits.MaxDatabaseCatalogs <= 0 {
		options.Limits.MaxDatabaseCatalogs = defaults.MaxDatabaseCatalogs
	}
	if options.Limits.MaxWebServers <= 0 {
		options.Limits.MaxWebServers = defaults.MaxWebServers
	}
	if options.Limits.MaxWebSites <= 0 {
		options.Limits.MaxWebSites = defaults.MaxWebSites
	}
	return options
}

func collectionStatus(statuses map[string]model.CollectorStatus) string {
	for _, status := range statuses {
		switch status.Status {
		case "partial", "error", "timeout":
			return "partial"
		}
	}
	return "success"
}

func firstStrings(values []string, limit int) []string {
	if len(values) <= limit {
		return append([]string{}, values...)
	}
	return append([]string{}, values[:limit]...)
}

func timePointer(value time.Time) *time.Time { return &value }

func chooseCorrelationUUID(productUUID, machineID, agentID string) string {
	if value := normalizeUUID(productUUID); value != "" {
		return value
	}
	if value := strings.ToLower(strings.TrimSpace(machineID)); value != "" {
		return value
	}
	return agentID
}

func ValidatePlatform() error {
	if runtime.GOOS != "linux" {
		return errors.New("unsupported operating system: Linux is required")
	}
	return nil
}
