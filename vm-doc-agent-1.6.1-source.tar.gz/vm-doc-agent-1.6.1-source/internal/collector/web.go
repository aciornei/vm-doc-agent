package collector

import (
	"bufio"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"vm-doc-agent/internal/model"
)

type webDefinition struct {
	Engine        string
	Product       string
	Binaries      []string
	ProcessNames  []string
	ServiceHints  []string
	VersionArgs   []string
	CommonConfigs []string
}

var webDefinitions = []webDefinition{
	{Engine: "nginx", Product: "Nginx", Binaries: []string{"nginx"}, ProcessNames: []string{"nginx"}, ServiceHints: []string{"nginx"}, VersionArgs: []string{"-v"}, CommonConfigs: []string{"/etc/nginx/nginx.conf", "/etc/nginx/conf.d/*.conf", "/etc/nginx/sites-enabled/*"}},
	{Engine: "apache", Product: "Apache HTTP Server", Binaries: []string{"apache2", "httpd", "apachectl", "apache2ctl"}, ProcessNames: []string{"apache2", "httpd"}, ServiceHints: []string{"apache2", "httpd"}, VersionArgs: []string{"-v"}, CommonConfigs: []string{"/etc/apache2/apache2.conf", "/etc/apache2/sites-enabled/*.conf", "/etc/httpd/conf/httpd.conf", "/etc/httpd/conf.d/*.conf"}},
	{Engine: "haproxy", Product: "HAProxy", Binaries: []string{"haproxy"}, ProcessNames: []string{"haproxy"}, ServiceHints: []string{"haproxy"}, VersionArgs: []string{"-v"}, CommonConfigs: []string{"/etc/haproxy/haproxy.cfg", "/etc/haproxy/conf.d/*.cfg"}},
}

type procWeb struct {
	PID        int
	Name       string
	Executable string
	Args       []string
}

func collectWeb(services []model.ServiceInfo, sockets []model.ListeningSocket, limits Limits) (model.WebInfo, []string) {
	result := model.WebInfo{Servers: []model.WebServer{}, Sites: []model.WebSite{}}
	warnings := []string{}
	processes := webProcesses()

	for _, def := range webDefinitions {
		server := detectWebServer(def, services, processes)
		if !server.Installed {
			continue
		}
		configs := webConfigFiles(def, processes)
		server.ConfigFiles = configs
		result.Servers = append(result.Servers, server)
		var sites []model.WebSite
		var parseWarnings []string
		switch def.Engine {
		case "nginx":
			sites, parseWarnings = collectNginxSites(configs)
		case "apache":
			sites, parseWarnings = collectApacheSites(configs)
		case "haproxy":
			sites, parseWarnings = collectHAProxySites(configs)
		}
		warnings = append(warnings, parseWarnings...)
		result.Sites = append(result.Sites, sites...)
	}

	result.Sites = dedupeWebSites(result.Sites)
	if limits.MaxWebServers > 0 && len(result.Servers) > limits.MaxWebServers {
		detected := len(result.Servers)
		result.Servers = result.Servers[:limits.MaxWebServers]
		warnings = append(warnings, fmt.Sprintf("web: servers limited: detected=%d collected=%d", detected, len(result.Servers)))
	}
	if limits.MaxWebSites > 0 && len(result.Sites) > limits.MaxWebSites {
		detected := len(result.Sites)
		result.Sites = result.Sites[:limits.MaxWebSites]
		warnings = append(warnings, fmt.Sprintf("web: sites limited: detected=%d collected=%d", detected, len(result.Sites)))
	}
	sort.Slice(result.Servers, func(i, j int) bool { return result.Servers[i].Engine < result.Servers[j].Engine })
	sort.Slice(result.Sites, func(i, j int) bool {
		if result.Sites[i].Engine != result.Sites[j].Engine {
			return result.Sites[i].Engine < result.Sites[j].Engine
		}
		return strings.ToLower(result.Sites[i].Name) < strings.ToLower(result.Sites[j].Name)
	})
	return result, uniqueSorted(warnings)
}

func detectWebServer(def webDefinition, services []model.ServiceInfo, processes []procWeb) model.WebServer {
	v := model.WebServer{Engine: def.Engine, Product: def.Product, DetectionSources: []string{}}
	for _, binary := range def.Binaries {
		if path, err := exec.LookPath(binary); err == nil {
			v.Installed = true
			if v.Executable == "" {
				v.Executable = path
			}
			v.DetectionSources = append(v.DetectionSources, "binary:"+binary)
		}
	}
	processRunning := false
	for _, p := range processes {
		if webProcessMatches(p, def) {
			processRunning = true
			v.Installed = true
			if v.Executable == "" {
				v.Executable = p.Executable
			}
			v.DetectionSources = append(v.DetectionSources, "process:"+p.Name)
		}
	}
	bestService := ""
	bestState := ""
	for _, svc := range services {
		if !webServiceMatches(svc.Name, def) {
			continue
		}
		v.Installed = true
		v.DetectionSources = append(v.DetectionSources, "service:"+svc.Name)
		state := strings.ToLower(strings.TrimSpace(svc.ActiveState))
		if bestService == "" || state == "active" || state == "running" {
			bestService, bestState = svc.Name, svc.ActiveState
		}
		if state == "active" || state == "running" {
			break
		}
	}
	v.ServiceName = bestService
	if processRunning {
		v.Status = "running"
		if strings.EqualFold(bestState, "active") || strings.EqualFold(bestState, "running") {
			v.Status = bestState
		}
	} else if bestState != "" {
		v.Status = bestState
	}
	v.Version = webServerVersion(def, v.Executable)
	v.DetectionSources = uniqueSorted(v.DetectionSources)
	return v
}

func webProcesses() []procWeb {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	out := []procWeb{}
	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil || pid < 1 {
			continue
		}
		name := strings.TrimSpace(readFirstLine(filepath.Join("/proc", entry.Name(), "comm")))
		cmdline, _ := os.ReadFile(filepath.Join("/proc", entry.Name(), "cmdline"))
		args := splitNullStrings(cmdline)
		exe, _ := os.Readlink(filepath.Join("/proc", entry.Name(), "exe"))
		if name == "" && len(args) > 0 {
			name = filepath.Base(args[0])
		}
		out = append(out, procWeb{PID: pid, Name: name, Executable: exe, Args: args})
	}
	return out
}

func webProcessMatches(p procWeb, def webDefinition) bool {
	name := strings.ToLower(strings.TrimSpace(p.Name))
	base := strings.ToLower(filepath.Base(p.Executable))
	for _, candidate := range def.ProcessNames {
		candidate = strings.ToLower(candidate)
		if name == candidate || base == candidate {
			return true
		}
	}
	return false
}

func webServiceMatches(name string, def webDefinition) bool {
	name = strings.ToLower(strings.TrimSpace(name))
	for _, hint := range def.ServiceHints {
		if strings.Contains(name, strings.ToLower(hint)) {
			return true
		}
	}
	return false
}

func webServerVersion(def webDefinition, executable string) string {
	candidates := []string{}
	if executable != "" {
		candidates = append(candidates, executable)
	}
	candidates = append(candidates, def.Binaries...)
	seen := map[string]bool{}
	for _, candidate := range candidates {
		if candidate == "" || seen[candidate] {
			continue
		}
		seen[candidate] = true
		path := candidate
		if !strings.Contains(path, "/") {
			if p, err := exec.LookPath(candidate); err == nil {
				path = p
			} else {
				continue
			}
		}
		out, err := commandCombinedOutput(3*time.Second, path, def.VersionArgs...)
		if err == nil || strings.TrimSpace(out) != "" {
			line := strings.TrimSpace(strings.Split(out, "\n")[0])
			if len(line) > 240 {
				line = line[:240]
			}
			if line != "" {
				return line
			}
		}
	}
	return ""
}

func commandCombinedOutput(timeout time.Duration, binary string, args ...string) (string, error) {
	cmd := exec.Command(binary, args...)
	ch := make(chan struct {
		out []byte
		err error
	}, 1)
	go func() {
		out, err := cmd.CombinedOutput()
		ch <- struct {
			out []byte
			err error
		}{out, err}
	}()
	select {
	case v := <-ch:
		return string(v.out), v.err
	case <-time.After(timeout):
		if cmd.Process != nil {
			_ = cmd.Process.Kill()
		}
		return "", fmt.Errorf("command timeout")
	}
}

func webConfigFiles(def webDefinition, processes []procWeb) []string {
	values := []string{}
	type nginxRoot struct {
		Path   string
		Prefix string
	}
	nginxRoots := []nginxRoot{}
	for _, pattern := range def.CommonConfigs {
		matches, _ := filepath.Glob(pattern)
		if len(matches) == 0 && !strings.ContainsAny(pattern, "*?[") {
			matches = []string{pattern}
		}
		for _, m := range matches {
			if regularReadableFile(m) {
				values = append(values, m)
				if def.Engine == "nginx" {
					nginxRoots = append(nginxRoots, nginxRoot{Path: m, Prefix: nginxPrefixFromConfigPath(m)})
				}
			}
		}
	}
	for _, proc := range processes {
		if !webProcessMatches(proc, def) {
			continue
		}
		for i := 0; i < len(proc.Args); i++ {
			a := proc.Args[i]
			if def.Engine == "haproxy" && a == "-f" && i+1 < len(proc.Args) {
				path := proc.Args[i+1]
				if info, err := os.Stat(path); err == nil && info.IsDir() {
					matches, _ := filepath.Glob(filepath.Join(path, "*.cfg"))
					values = append(values, matches...)
				} else {
					values = append(values, path)
				}
			}
		}
		if def.Engine == "nginx" {
			prefix, conf := nginxProcessPaths(proc.Args)
			compiledPrefix, compiledConf := nginxCompiledPaths(proc.Executable)
			if prefix == "" {
				prefix = compiledPrefix
			}
			if prefix == "" {
				prefix = nginxPrefixFromExecutable(proc.Executable)
			}
			if conf == "" {
				conf = compiledConf
			}
			if conf == "" && prefix != "" {
				conf = filepath.Join(prefix, "conf", "nginx.conf")
			}
			conf = resolveNginxPath(conf, prefix)
			if regularReadableFile(conf) {
				values = append(values, conf)
				nginxRoots = append(nginxRoots, nginxRoot{Path: conf, Prefix: prefix})
			}
		}
	}
	if def.Engine == "nginx" {
		for _, root := range nginxRoots {
			values = append(values, expandNginxConfigIncludes(root.Path, root.Prefix, 512)...)
		}
	}
	out := []string{}
	seen := map[string]bool{}
	for _, v := range values {
		v = strings.TrimSpace(v)
		if v == "" || !regularReadableFile(v) {
			continue
		}
		real := v
		if resolved, err := filepath.EvalSymlinks(v); err == nil {
			real = resolved
		}
		key := real
		if seen[key] {
			continue
		}
		seen[key] = true
		out = append(out, v)
	}
	sort.Strings(out)
	return out
}

func nginxProcessPaths(args []string) (prefix, conf string) {
	for i := 0; i < len(args); i++ {
		a := strings.TrimSpace(args[i])
		switch {
		case a == "-p" && i+1 < len(args):
			prefix = strings.TrimSpace(args[i+1])
		case strings.HasPrefix(a, "-p") && len(a) > 2:
			prefix = strings.TrimSpace(strings.TrimPrefix(a, "-p"))
		case a == "-c" && i+1 < len(args):
			conf = strings.TrimSpace(args[i+1])
		case strings.HasPrefix(a, "-c") && len(a) > 2:
			conf = strings.TrimSpace(strings.TrimPrefix(a, "-c"))
		}
	}
	prefix = strings.Trim(prefix, "\"'")
	conf = strings.Trim(conf, "\"'")
	return prefix, conf
}

func nginxCompiledPaths(executable string) (prefix, conf string) {
	if strings.TrimSpace(executable) == "" || !regularExecutable(executable) {
		return "", ""
	}
	out, err := commandCombinedOutput(3*time.Second, executable, "-V")
	if err != nil && strings.TrimSpace(out) == "" {
		return "", ""
	}
	return nginxPathsFromVersionOutput(out)
}

func nginxPathsFromVersionOutput(out string) (prefix, conf string) {
	for _, token := range strings.Fields(out) {
		token = strings.Trim(token, "\"' ")
		if strings.HasPrefix(token, "--prefix=") {
			prefix = strings.Trim(strings.TrimPrefix(token, "--prefix="), "\"'")
		}
		if strings.HasPrefix(token, "--conf-path=") {
			conf = strings.Trim(strings.TrimPrefix(token, "--conf-path="), "\"'")
		}
	}
	return prefix, conf
}

func regularExecutable(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.Mode().IsRegular() && info.Mode().Perm()&0111 != 0
}

func nginxPrefixFromExecutable(executable string) string {
	clean := filepath.Clean(strings.TrimSpace(executable))
	if clean == "." || clean == "/" || clean == "" {
		return ""
	}
	dir := filepath.Dir(clean)
	base := strings.ToLower(filepath.Base(dir))
	if base == "sbin" || base == "bin" {
		return filepath.Dir(dir)
	}
	return dir
}

func nginxPrefixFromConfigPath(path string) string {
	clean := filepath.Clean(path)
	if filepath.Base(clean) != "nginx.conf" {
		return filepath.Dir(clean)
	}
	dir := filepath.Dir(clean)
	if strings.EqualFold(filepath.Base(dir), "conf") {
		return filepath.Dir(dir)
	}
	return dir
}

func resolveNginxPath(path, prefix string) string {
	path = strings.Trim(strings.TrimSpace(path), "\"'")
	if path == "" {
		return ""
	}
	if filepath.IsAbs(path) {
		return filepath.Clean(path)
	}
	if strings.TrimSpace(prefix) != "" {
		return filepath.Clean(filepath.Join(prefix, path))
	}
	return filepath.Clean(path)
}

var nginxIncludeDirective = regexp.MustCompile(`(?i)\binclude\s+([^;{}]+);`)

func expandNginxConfigIncludes(root, prefix string, limit int) []string {
	if limit <= 0 {
		limit = 512
	}
	root = resolveNginxPath(root, prefix)
	if !regularReadableFile(root) {
		return nil
	}
	queue := []string{root}
	seen := map[string]bool{}
	out := []string{}
	for len(queue) > 0 && len(out) < limit {
		path := queue[0]
		queue = queue[1:]
		real := path
		if resolved, err := filepath.EvalSymlinks(path); err == nil {
			real = resolved
		}
		if seen[real] || !regularReadableFile(path) {
			continue
		}
		seen[real] = true
		out = append(out, path)
		raw, err := safeReadConfig(path)
		if err != nil {
			continue
		}
		clean := stripConfigComments(raw)
		for _, match := range nginxIncludeDirective.FindAllStringSubmatch(clean, -1) {
			if len(match) < 2 {
				continue
			}
			pattern := strings.Trim(strings.TrimSpace(match[1]), "\"'")
			if pattern == "" || strings.Contains(pattern, "$") {
				continue
			}
			if !filepath.IsAbs(pattern) {
				base := prefix
				if strings.TrimSpace(base) == "" {
					base = filepath.Dir(path)
				}
				pattern = filepath.Join(base, pattern)
			}
			matches, _ := filepath.Glob(pattern)
			if len(matches) == 0 && !strings.ContainsAny(pattern, "*?[") {
				matches = []string{pattern}
			}
			for _, child := range matches {
				if regularReadableFile(child) {
					queue = append(queue, child)
				}
			}
		}
	}
	return out
}

func stripConfigComments(raw string) string {
	var out strings.Builder
	scanner := bufio.NewScanner(strings.NewReader(raw))
	for scanner.Scan() {
		out.WriteString(stripConfigComment(scanner.Text()))
		out.WriteByte('\n')
	}
	return out.String()
}

func regularReadableFile(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.Mode().IsRegular()
}

func safeReadConfig(path string) (string, error) {
	info, err := os.Stat(path)
	if err != nil {
		return "", err
	}
	if info.Size() > 4<<20 {
		return "", fmt.Errorf("config too large")
	}
	raw, err := os.ReadFile(path)
	return string(raw), err
}

var nginxServerStart = regexp.MustCompile(`(?im)^\s*server\s*\{`)
var apacheVHostStart = regexp.MustCompile(`(?im)<VirtualHost\s+([^>]+)>`)

func collectNginxSites(files []string) ([]model.WebSite, []string) {
	out := []model.WebSite{}
	warnings := []string{}
	for _, file := range files {
		raw, err := safeReadConfig(file)
		if err != nil {
			warnings = append(warnings, "web nginx: "+file+": "+err.Error())
			continue
		}
		blocks := extractBraceBlocks(raw, nginxServerStart)
		for index, block := range blocks {
			d := parseSemicolonDirectives(block)
			names := sanitizeHostNames(d["server_name"])
			bindings := []model.WebBinding{}
			isDefault := false
			for _, listen := range d["listen"] {
				b, def := parseNginxListen(listen)
				if b.Port > 0 || b.Address != "" {
					bindings = append(bindings, b)
				}
				isDefault = isDefault || def
			}
			if len(bindings) == 0 {
				bindings = []model.WebBinding{{Port: 80, Protocol: "http", Wildcard: true}}
			}
			root := firstDirectiveValue(d["root"])
			proxies := append([]string{}, d["proxy_pass"]...)
			proxies = append(proxies, d["fastcgi_pass"]...)
			proxies = safeTargets(proxies)
			name := firstPublicName(names)
			if name == "" {
				name = fmt.Sprintf("%s#%d", filepath.Base(file), index+1)
			}
			if webContainsString(names, "_") {
				isDefault = true
			}
			out = append(out, model.WebSite{Engine: "nginx", Product: "Nginx", SiteType: "server", Name: name, ServerNames: names, Bindings: bindings, DocumentRoot: root, ProxyTargets: proxies, ConfigFile: file, Enabled: true, Default: isDefault, DetectionSources: []string{"config"}})
		}
	}
	return out, warnings
}

func extractBraceBlocks(raw string, start *regexp.Regexp) []string {
	matches := start.FindAllStringIndex(raw, -1)
	out := []string{}
	for _, m := range matches {
		open := strings.Index(raw[m[0]:m[1]], "{") + m[0]
		if open < m[0] {
			continue
		}
		depth := 0
		quote := byte(0)
		escaped := false
		for i := open; i < len(raw); i++ {
			c := raw[i]
			if escaped {
				escaped = false
				continue
			}
			if quote != 0 {
				if c == '\\' {
					escaped = true
				} else if c == quote {
					quote = 0
				}
				continue
			}
			if c == '\'' || c == '"' {
				quote = c
				continue
			}
			if c == '#' {
				if j := strings.IndexByte(raw[i:], '\n'); j >= 0 {
					i += j - 1
					continue
				}
			}
			if c == '{' {
				depth++
			} else if c == '}' {
				depth--
				if depth == 0 {
					out = append(out, raw[open+1:i])
					break
				}
			}
		}
	}
	return out
}

func parseSemicolonDirectives(block string) map[string][]string {
	result := map[string][]string{}
	var current strings.Builder
	scanner := bufio.NewScanner(strings.NewReader(block))
	for scanner.Scan() {
		line := stripConfigComment(scanner.Text())
		if line == "" {
			continue
		}
		current.WriteString(" ")
		current.WriteString(line)
		text := current.String()
		for {
			idx := strings.Index(text, ";")
			if idx < 0 {
				break
			}
			statement := strings.TrimSpace(text[:idx])
			text = text[idx+1:]
			fields := strings.Fields(statement)
			if len(fields) >= 2 {
				key := strings.ToLower(fields[0])
				result[key] = append(result[key], strings.TrimSpace(strings.Join(fields[1:], " ")))
			}
		}
		current.Reset()
		current.WriteString(text)
	}
	return result
}

func stripConfigComment(line string) string {
	quote := rune(0)
	escaped := false
	for i, r := range line {
		if escaped {
			escaped = false
			continue
		}
		if quote != 0 {
			if r == '\\' {
				escaped = true
			} else if r == quote {
				quote = 0
			}
			continue
		}
		if r == '\'' || r == '"' {
			quote = r
			continue
		}
		if r == '#' {
			return strings.TrimSpace(line[:i])
		}
	}
	return strings.TrimSpace(line)
}

func parseNginxListen(value string) (model.WebBinding, bool) {
	fields := strings.Fields(value)
	b := model.WebBinding{Protocol: "http"}
	def := false
	for _, f := range fields {
		lf := strings.ToLower(f)
		if lf == "ssl" {
			b.TLS = true
			b.Protocol = "https"
		}
		if lf == "default_server" || lf == "default" {
			def = true
		}
	}
	if len(fields) == 0 {
		return b, def
	}
	addr, port, wild := parseHostPortLoose(fields[0], 80)
	b.Address = addr
	b.Port = port
	b.Wildcard = wild
	if port == 443 {
		b.TLS = true
		b.Protocol = "https"
	}
	return b, def
}

func collectApacheSites(files []string) ([]model.WebSite, []string) {
	out := []model.WebSite{}
	warnings := []string{}
	for _, file := range files {
		raw, err := safeReadConfig(file)
		if err != nil {
			warnings = append(warnings, "web apache: "+file+": "+err.Error())
			continue
		}
		matches := apacheVHostStart.FindAllStringSubmatchIndex(raw, -1)
		for index, m := range matches {
			if len(m) < 4 {
				continue
			}
			endTag := strings.Index(strings.ToLower(raw[m[1]:]), "</virtualhost>")
			if endTag < 0 {
				continue
			}
			body := raw[m[1] : m[1]+endTag]
			header := raw[m[2]:m[3]]
			dirs := parseApacheDirectives(body)
			names := []string{}
			if v := firstDirectiveValue(dirs["servername"]); v != "" {
				names = append(names, v)
			}
			names = append(names, splitDirectiveWords(dirs["serveralias"])...)
			names = sanitizeHostNames(names)
			bindings := []model.WebBinding{}
			for _, token := range strings.Fields(header) {
				addr, port, wild := parseHostPortLoose(token, 80)
				tls := port == 443
				proto := "http"
				if tls {
					proto = "https"
				}
				bindings = append(bindings, model.WebBinding{Address: addr, Port: port, Wildcard: wild, TLS: tls, Protocol: proto})
			}
			root := firstDirectiveValue(dirs["documentroot"])
			proxies := []string{}
			for _, v := range dirs["proxypass"] {
				f := strings.Fields(v)
				if len(f) >= 2 {
					proxies = append(proxies, f[1])
				}
			}
			proxies = safeTargets(proxies)
			if strings.EqualFold(firstDirectiveValue(dirs["sslengine"]), "on") {
				for i := range bindings {
					bindings[i].TLS = true
					bindings[i].Protocol = "https"
				}
			}
			name := firstPublicName(names)
			if name == "" {
				name = fmt.Sprintf("%s#%d", filepath.Base(file), index+1)
			}
			out = append(out, model.WebSite{Engine: "apache", Product: "Apache HTTP Server", SiteType: "virtual_host", Name: name, ServerNames: names, Bindings: bindings, DocumentRoot: strings.Trim(root, "\"'"), ProxyTargets: proxies, ConfigFile: file, Enabled: true, DetectionSources: []string{"config"}})
		}
	}
	return out, warnings
}

func parseApacheDirectives(body string) map[string][]string {
	result := map[string][]string{}
	scanner := bufio.NewScanner(strings.NewReader(body))
	for scanner.Scan() {
		line := stripConfigComment(scanner.Text())
		if line == "" || strings.HasPrefix(line, "<") {
			continue
		}
		f := strings.Fields(line)
		if len(f) >= 2 {
			key := strings.ToLower(f[0])
			result[key] = append(result[key], strings.TrimSpace(strings.Join(f[1:], " ")))
		}
	}
	return result
}
func splitDirectiveWords(values []string) []string {
	out := []string{}
	for _, v := range values {
		out = append(out, strings.Fields(v)...)
	}
	return out
}

func collectHAProxySites(files []string) ([]model.WebSite, []string) {
	out := []model.WebSite{}
	warnings := []string{}
	for _, file := range files {
		raw, err := safeReadConfig(file)
		if err != nil {
			warnings = append(warnings, "web haproxy: "+file+": "+err.Error())
			continue
		}
		scanner := bufio.NewScanner(strings.NewReader(raw))
		var current *model.WebSite
		flush := func() {
			if current != nil {
				current.ServerNames = sanitizeHostNames(current.ServerNames)
				current.Backends = uniqueSorted(current.Backends)
				current.ProxyTargets = safeTargets(current.ProxyTargets)
				out = append(out, *current)
				current = nil
			}
		}
		for scanner.Scan() {
			line := stripConfigComment(scanner.Text())
			if line == "" {
				continue
			}
			f := strings.Fields(line)
			if len(f) == 0 {
				continue
			}
			key := strings.ToLower(f[0])
			if key == "frontend" || key == "listen" {
				flush()
				if len(f) < 2 {
					continue
				}
				current = &model.WebSite{Engine: "haproxy", Product: "HAProxy", SiteType: key, Name: f[1], ConfigFile: file, Enabled: true, DetectionSources: []string{"config"}}
				continue
			}
			if key == "backend" || key == "defaults" || key == "global" {
				flush()
				continue
			}
			if current == nil {
				continue
			}
			switch key {
			case "bind":
				if len(f) >= 2 {
					for _, token := range strings.Split(f[1], ",") {
						addr, port, wild := parseHostPortLoose(token, 0)
						tls := containsFold(f[2:], "ssl") || port == 443
						proto := "tcp"
						if current.Mode == "http" {
							proto = "http"
							if tls {
								proto = "https"
							}
						}
						current.Bindings = append(current.Bindings, model.WebBinding{Address: addr, Port: port, Wildcard: wild, TLS: tls, Protocol: proto})
					}
				}
			case "mode":
				if len(f) >= 2 {
					current.Mode = strings.ToLower(f[1])
					for i := range current.Bindings {
						if current.Mode == "http" {
							current.Bindings[i].Protocol = "http"
							if current.Bindings[i].TLS {
								current.Bindings[i].Protocol = "https"
							}
						}
					}
				}
			case "default_backend":
				if len(f) >= 2 {
					current.Backends = append(current.Backends, f[1])
				}
			case "use_backend":
				if len(f) >= 2 {
					current.Backends = append(current.Backends, f[1])
				}
			case "acl":
				current.ServerNames = append(current.ServerNames, haproxyHostACLValues(f)...)
			}
		}
		flush()
	}
	return out, warnings
}

func haproxyHostACLValues(fields []string) []string {
	if len(fields) < 4 {
		return nil
	}
	joined := strings.ToLower(strings.Join(fields, " "))
	if !strings.Contains(joined, "hdr(host)") && !strings.Contains(joined, "hdr_dom(host)") && !strings.Contains(joined, "hdr_end(host)") {
		return nil
	}
	out := []string{}
	for i := 3; i < len(fields); i++ {
		v := fields[i]
		if strings.HasPrefix(v, "-") {
			if v == "-i" {
				continue
			}
			continue
		}
		if strings.ContainsAny(v, "{}[]()") || strings.HasPrefix(v, "var(") {
			continue
		}
		out = append(out, strings.Trim(v, "\"'"))
	}
	return out
}

func parseHostPortLoose(value string, defaultPort uint16) (string, uint16, bool) {
	value = strings.TrimSpace(strings.Trim(value, "\"'"))
	if value == "" {
		return "", defaultPort, true
	}
	if strings.HasPrefix(value, "unix:") {
		return value, 0, false
	}
	if strings.HasPrefix(value, "[") {
		if idx := strings.LastIndex(value, "]:"); idx > 0 {
			p, _ := strconv.Atoi(value[idx+2:])
			addr := value[1:idx]
			return addr, uint16(p), addr == "::"
		}
	}
	if strings.Count(value, ":") == 1 {
		parts := strings.SplitN(value, ":", 2)
		p, _ := strconv.Atoi(parts[1])
		addr := parts[0]
		if addr == "*" {
			addr = ""
		}
		return addr, uint16(p), addr == "" || addr == "0.0.0.0"
	}
	if p, err := strconv.Atoi(value); err == nil && p > 0 && p <= 65535 {
		return "", uint16(p), true
	}
	return value, defaultPort, value == "*" || value == "0.0.0.0" || value == "::"
}

func firstDirectiveValue(values []string) string {
	if len(values) == 0 {
		return ""
	}
	return strings.TrimSpace(values[0])
}
func sanitizeHostNames(values []string) []string {
	out := []string{}
	for _, v := range values {
		for _, f := range strings.Fields(v) {
			f = strings.TrimSpace(strings.Trim(f, "\"';"))
			if f == "" {
				continue
			}
			if strings.HasPrefix(f, "$") {
				continue
			}
			out = append(out, f)
		}
	}
	return uniqueSorted(out)
}
func firstPublicName(values []string) string {
	for _, v := range values {
		if v != "_" && v != "*" && v != "default" {
			return v
		}
	}
	return ""
}
func webContainsString(values []string, target string) bool {
	for _, v := range values {
		if v == target {
			return true
		}
	}
	return false
}
func containsFold(values []string, target string) bool {
	for _, v := range values {
		if strings.EqualFold(v, target) {
			return true
		}
	}
	return false
}
func safeTargets(values []string) []string {
	out := []string{}
	for _, v := range values {
		v = strings.TrimSpace(strings.Trim(v, "\"';"))
		if v == "" {
			continue
		}
		lower := strings.ToLower(v)
		if strings.Contains(lower, "password") || strings.Contains(lower, "token=") || strings.Contains(lower, "secret=") {
			continue
		}
		if at := strings.Index(v, "@"); at >= 0 && strings.Contains(v[:at], "://") {
			continue
		}
		out = append(out, v)
	}
	return uniqueSorted(out)
}

func webSiteIdentity(v model.WebSite) string {
	bindings := []string{}
	for _, b := range v.Bindings {
		bindings = append(bindings, fmt.Sprintf("%s:%d:%t", b.Address, b.Port, b.TLS))
	}
	sort.Strings(bindings)
	names := append([]string{}, v.ServerNames...)
	sort.Strings(names)
	return strings.ToLower(strings.Join([]string{v.Engine, v.SiteType, v.Name, strings.Join(names, ","), strings.Join(bindings, ","), v.ConfigFile}, "|"))
}
func dedupeWebSites(values []model.WebSite) []model.WebSite {
	out := []model.WebSite{}
	seen := map[string]bool{}
	for _, v := range values {
		k := webSiteIdentity(v)
		if seen[k] {
			continue
		}
		seen[k] = true
		out = append(out, v)
	}
	return out
}
