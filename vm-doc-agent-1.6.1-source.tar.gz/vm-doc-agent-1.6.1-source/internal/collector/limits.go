package collector

import (
	"encoding/json"
	"fmt"

	"vm-doc-agent/internal/model"
)

func applyLimits(inventory *model.Inventory, limits Limits) {
	truncatePartitionList(inventory, limits.MaxPartitions)
	truncateRouteList(inventory, limits.MaxRoutes)
	truncateServiceList(inventory, limits.MaxServices)
	truncatePortList(inventory, limits.MaxPorts)
	truncateFirewall(inventory, limits.MaxFirewallRules, limits.MaxFirewallZones)
	truncateAccounts(inventory, limits.MaxAccounts)
	truncateCron(inventory, limits.MaxCronEntries, limits.MaxCronScripts)
	truncatePolicies(inventory, limits.MaxPolicyFiles)
	truncateDocker(inventory, limits)
	truncateDatabases(inventory, limits)
	truncateWeb(inventory, limits)
	truncateLongStrings(inventory)
	shrinkToInventoryLimit(inventory, limits.MaxInventoryBytes)
	if len(inventory.Truncations) == 0 {
		inventory.Truncations = nil
	}
}

func truncatePartitionList(inventory *model.Inventory, limit int) {
	if len(inventory.Storage.Partitions) <= limit {
		return
	}
	total := len(inventory.Storage.Partitions)
	inventory.Storage.Partitions = inventory.Storage.Partitions[:limit]
	markTruncated(inventory, "storage", "storage.partitions", total, limit, limit, "configured item limit")
}

func truncateRouteList(inventory *model.Inventory, limit int) {
	if len(inventory.Network.Routes) <= limit {
		return
	}
	total := len(inventory.Network.Routes)
	inventory.Network.Routes = inventory.Network.Routes[:limit]
	markTruncated(inventory, "network", "network.routes", total, limit, limit, "configured item limit")
}

func truncateServiceList(inventory *model.Inventory, limit int) {
	if len(inventory.Services) <= limit {
		return
	}
	total := len(inventory.Services)
	inventory.Services = inventory.Services[:limit]
	markTruncated(inventory, "services", "services", total, limit, limit, "configured item limit")
}

func truncatePortList(inventory *model.Inventory, limit int) {
	if len(inventory.ListeningPorts) <= limit {
		return
	}
	total := len(inventory.ListeningPorts)
	inventory.ListeningPorts = inventory.ListeningPorts[:limit]
	markTruncated(inventory, "listening_ports", "listening_ports", total, limit, limit, "configured item limit")
}

func truncateFirewall(inventory *model.Inventory, ruleLimit, zoneLimit int) {
	if len(inventory.Firewall.Rules) > ruleLimit {
		total := len(inventory.Firewall.Rules)
		inventory.Firewall.Rules = inventory.Firewall.Rules[:ruleLimit]
		markTruncated(inventory, "firewall", "firewall.rules", total, ruleLimit, ruleLimit, "configured item limit")
	}
	if len(inventory.Firewall.Zones) > zoneLimit {
		total := len(inventory.Firewall.Zones)
		inventory.Firewall.Zones = inventory.Firewall.Zones[:zoneLimit]
		markTruncated(inventory, "firewall", "firewall.zones", total, zoneLimit, zoneLimit, "configured item limit")
	}
}

func truncateAccounts(inventory *model.Inventory, limit int) {
	if len(inventory.Accounts.LocalUsers) <= limit {
		return
	}
	total := len(inventory.Accounts.LocalUsers)
	inventory.Accounts.LocalUsers = inventory.Accounts.LocalUsers[:limit]
	markTruncated(inventory, "accounts", "accounts.local_users", total, limit, limit, "configured item limit")
}

func truncateCron(inventory *model.Inventory, entryLimit, scriptLimit int) {
	if len(inventory.Cron.Entries) > entryLimit {
		total := len(inventory.Cron.Entries)
		inventory.Cron.Entries = inventory.Cron.Entries[:entryLimit]
		markTruncated(inventory, "cron", "cron.entries", total, entryLimit, entryLimit, "configured item limit")
	}
	if len(inventory.Cron.PeriodicScripts) > scriptLimit {
		total := len(inventory.Cron.PeriodicScripts)
		inventory.Cron.PeriodicScripts = inventory.Cron.PeriodicScripts[:scriptLimit]
		markTruncated(inventory, "cron", "cron.periodic_scripts", total, scriptLimit, scriptLimit, "configured item limit")
	}
}

func truncatePolicies(inventory *model.Inventory, limit int) {
	remaining := limit
	groups := []struct {
		name   string
		values *[]model.PolicyFileInfo
	}{
		{"policies.audit_rules", &inventory.Policies.AuditRules},
		{"policies.sudoers", &inventory.Policies.Sudoers},
		{"policies.limits", &inventory.Policies.Limits},
		{"policies.sysctl", &inventory.Policies.Sysctl},
		{"policies.custom_markers", &inventory.Policies.CustomMarkers},
	}
	totalAll := 0
	for _, group := range groups {
		totalAll += len(*group.values)
	}
	if totalAll <= limit {
		return
	}
	for _, group := range groups {
		values := *group.values
		keep := len(values)
		if keep > remaining {
			keep = remaining
		}
		if keep < 0 {
			keep = 0
		}
		*group.values = values[:keep]
		remaining -= keep
		if remaining < 0 {
			remaining = 0
		}
	}
	markTruncated(inventory, "policies", "policies.files", totalAll, limit, limit, "configured aggregate item limit")
}

func truncateDocker(inventory *model.Inventory, limits Limits) {
	if len(inventory.Docker.Containers) > limits.MaxDockerContainers {
		total := len(inventory.Docker.Containers)
		inventory.Docker.Containers = inventory.Docker.Containers[:limits.MaxDockerContainers]
		markTruncated(inventory, "docker", "docker.containers", total, limits.MaxDockerContainers, limits.MaxDockerContainers, "configured item limit")
	}
	if len(inventory.Docker.Images) > limits.MaxDockerImages {
		total := len(inventory.Docker.Images)
		inventory.Docker.Images = inventory.Docker.Images[:limits.MaxDockerImages]
		markTruncated(inventory, "docker", "docker.images", total, limits.MaxDockerImages, limits.MaxDockerImages, "configured item limit")
	}
	if len(inventory.Docker.Networks) > limits.MaxDockerNetworks {
		total := len(inventory.Docker.Networks)
		inventory.Docker.Networks = inventory.Docker.Networks[:limits.MaxDockerNetworks]
		markTruncated(inventory, "docker", "docker.networks", total, limits.MaxDockerNetworks, limits.MaxDockerNetworks, "configured item limit")
	}
	if len(inventory.Docker.Volumes) > limits.MaxDockerVolumes {
		total := len(inventory.Docker.Volumes)
		inventory.Docker.Volumes = inventory.Docker.Volumes[:limits.MaxDockerVolumes]
		markTruncated(inventory, "docker", "docker.volumes", total, limits.MaxDockerVolumes, limits.MaxDockerVolumes, "configured item limit")
	}
}

func truncateDatabases(inventory *model.Inventory, limits Limits) {
	if limits.MaxDatabaseInstances > 0 && len(inventory.Databases.Instances) > limits.MaxDatabaseInstances {
		total := len(inventory.Databases.Instances)
		inventory.Databases.Instances = inventory.Databases.Instances[:limits.MaxDatabaseInstances]
		markTruncated(inventory, "databases", "databases.instances", total, limits.MaxDatabaseInstances, limits.MaxDatabaseInstances, "configured item limit")
	}
	if limits.MaxDatabaseCatalogs <= 0 {
		return
	}
	total := 0
	for i := range inventory.Databases.Instances {
		total += len(inventory.Databases.Instances[i].Catalogs)
	}
	if total <= limits.MaxDatabaseCatalogs {
		return
	}
	remaining := limits.MaxDatabaseCatalogs
	for i := range inventory.Databases.Instances {
		values := inventory.Databases.Instances[i].Catalogs
		keep := len(values)
		if keep > remaining {
			keep = remaining
		}
		if keep < 0 {
			keep = 0
		}
		inventory.Databases.Instances[i].Catalogs = values[:keep]
		remaining -= keep
		if remaining <= 0 {
			remaining = 0
		}
	}
	markTruncated(inventory, "databases", "databases.catalogs", total, limits.MaxDatabaseCatalogs, limits.MaxDatabaseCatalogs, "configured aggregate item limit")
}

func truncateWeb(inventory *model.Inventory, limits Limits) {
	if limits.MaxWebServers > 0 && len(inventory.Web.Servers) > limits.MaxWebServers {
		total := len(inventory.Web.Servers)
		inventory.Web.Servers = inventory.Web.Servers[:limits.MaxWebServers]
		markTruncated(inventory, "web", "web.servers", total, limits.MaxWebServers, limits.MaxWebServers, "configured item limit")
	}
	if limits.MaxWebSites > 0 && len(inventory.Web.Sites) > limits.MaxWebSites {
		total := len(inventory.Web.Sites)
		inventory.Web.Sites = inventory.Web.Sites[:limits.MaxWebSites]
		markTruncated(inventory, "web", "web.sites", total, limits.MaxWebSites, limits.MaxWebSites, "configured item limit")
	}
}

func truncateLongStrings(inventory *model.Inventory) {
	for index := range inventory.Services {
		inventory.Services[index].Description = truncateString(inventory.Services[index].Description, 1024)
	}
	for index := range inventory.Firewall.Rules {
		inventory.Firewall.Rules[index].Rule = truncateString(inventory.Firewall.Rules[index].Rule, 4096)
	}
	for index := range inventory.Cron.Entries {
		inventory.Cron.Entries[index].Command = truncateString(inventory.Cron.Entries[index].Command, 4096)
	}
	for index := range inventory.Docker.Containers {
		inventory.Docker.Containers[index].Name = truncateString(inventory.Docker.Containers[index].Name, 255)
		inventory.Docker.Containers[index].Image = truncateString(inventory.Docker.Containers[index].Image, 1024)
	}
	for index := range inventory.Web.Servers {
		server := &inventory.Web.Servers[index]
		server.Version = truncateString(server.Version, 255)
		server.Executable = truncateString(server.Executable, 1024)
		server.ServiceName = truncateString(server.ServiceName, 255)
	}
	for index := range inventory.Web.Sites {
		site := &inventory.Web.Sites[index]
		site.Name = truncateString(site.Name, 512)
		site.DocumentRoot = truncateString(site.DocumentRoot, 2048)
		site.ConfigFile = truncateString(site.ConfigFile, 2048)
		site.Mode = truncateString(site.Mode, 64)
	}
	for index := range inventory.Databases.Instances {
		instance := &inventory.Databases.Instances[index]
		instance.InstanceName = truncateString(instance.InstanceName, 255)
		instance.Version = truncateString(instance.Version, 255)
		instance.Edition = truncateString(instance.Edition, 255)
		instance.ServiceName = truncateString(instance.ServiceName, 255)
		instance.Executable = truncateString(instance.Executable, 1024)
		instance.DataDir = truncateString(instance.DataDir, 2048)
		for catalogIndex := range instance.Catalogs {
			instance.Catalogs[catalogIndex].Name = truncateString(instance.Catalogs[catalogIndex].Name, 512)
		}
	}
}

func shrinkToInventoryLimit(inventory *model.Inventory, maxBytes int) {
	if maxBytes <= 0 {
		return
	}
	for attempts := 0; attempts < 24; attempts++ {
		data, err := json.Marshal(inventory)
		if err != nil || len(data) <= maxBytes {
			return
		}
		name, collectorName, detected, returned, changed := shrinkLargestCollection(inventory)
		if !changed {
			inventory.CollectionWarnings = firstStrings(inventory.CollectionWarnings, 100)
			return
		}
		markTruncated(inventory, collectorName, name, detected, returned, maxBytes, "maximum inventory byte size")
	}
}

func shrinkLargestCollection(inventory *model.Inventory) (string, string, int, int, bool) {
	type candidate struct {
		name, collector string
		length          int
		shrink          func(int)
	}
	candidates := []candidate{
		{"firewall.rules", "firewall", len(inventory.Firewall.Rules), func(n int) { inventory.Firewall.Rules = inventory.Firewall.Rules[:n] }},
		{"cron.entries", "cron", len(inventory.Cron.Entries), func(n int) { inventory.Cron.Entries = inventory.Cron.Entries[:n] }},
		{"services", "services", len(inventory.Services), func(n int) { inventory.Services = inventory.Services[:n] }},
		{"listening_ports", "listening_ports", len(inventory.ListeningPorts), func(n int) { inventory.ListeningPorts = inventory.ListeningPorts[:n] }},
		{"accounts.local_users", "accounts", len(inventory.Accounts.LocalUsers), func(n int) { inventory.Accounts.LocalUsers = inventory.Accounts.LocalUsers[:n] }},
		{"network.routes", "network", len(inventory.Network.Routes), func(n int) { inventory.Network.Routes = inventory.Network.Routes[:n] }},
		{"docker.containers", "docker", len(inventory.Docker.Containers), func(n int) { inventory.Docker.Containers = inventory.Docker.Containers[:n] }},
		{"docker.images", "docker", len(inventory.Docker.Images), func(n int) { inventory.Docker.Images = inventory.Docker.Images[:n] }},
		{"databases.instances", "databases", len(inventory.Databases.Instances), func(n int) { inventory.Databases.Instances = inventory.Databases.Instances[:n] }},
	}
	largest := candidate{}
	for _, item := range candidates {
		if item.length > largest.length {
			largest = item
		}
	}
	if largest.length <= 1 {
		return "", "", 0, 0, false
	}
	returned := largest.length / 2
	largest.shrink(returned)
	return largest.name, largest.collector, largest.length, returned, true
}

func markTruncated(inventory *model.Inventory, collectorName, path string, detected, returned, limit int, reason string) {
	if inventory.Truncations == nil {
		inventory.Truncations = map[string]model.TruncationInfo{}
	}
	inventory.Truncations[path] = model.TruncationInfo{Detected: detected, Returned: returned, Limit: limit, Reason: reason}
	status := inventory.Collection.Collectors[collectorName]
	status.Truncated = true
	if status.Status == "success" {
		status.Status = "partial"
	}
	status.WarningCount++
	warning := fmt.Sprintf("%s truncated: detected=%d returned=%d", path, detected, returned)
	if len(status.Warnings) < 20 {
		status.Warnings = append(status.Warnings, warning)
	}
	inventory.Collection.Collectors[collectorName] = status
	inventory.CollectionWarnings = append(inventory.CollectionWarnings, warning)
}
