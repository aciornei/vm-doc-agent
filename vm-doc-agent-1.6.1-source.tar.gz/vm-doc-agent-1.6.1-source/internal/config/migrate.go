package config

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
)

// MigrationResult describes a safe on-disk configuration schema migration.
// Existing values are never overwritten; only keys missing from the current
// config are copied from the current schema defaults.
type MigrationResult struct {
	Changed    bool     `json:"changed"`
	AddedPaths []string `json:"added_paths,omitempty"`
}

// MigrateFile updates an existing JSON configuration with keys introduced by
// newer agent versions while preserving every existing configured value.
//
// The migration is intentionally additive. It does not remove keys and it does
// not replace user values with package defaults. A candidate file is validated
// with the current agent before it replaces the original file.
func MigrateFile(path string) (MigrationResult, error) {
	path = filepath.Clean(path)
	if path == "." || path == "" {
		return MigrationResult{}, fmt.Errorf("configuration path is empty")
	}

	original, err := os.ReadFile(path)
	if err != nil {
		return MigrationResult{}, fmt.Errorf("read configuration: %w", err)
	}

	// Validate the source using the current schema first. Missing fields are
	// valid because Load() applies runtime defaults; unknown/invalid fields are
	// rejected exactly as they are during normal agent startup.
	if _, err := Load(path); err != nil {
		return MigrationResult{}, err
	}

	var current map[string]any
	if err := json.Unmarshal(original, &current); err != nil {
		return MigrationResult{}, fmt.Errorf("decode configuration for migration: %w", err)
	}
	if current == nil {
		return MigrationResult{}, fmt.Errorf("configuration root must be a JSON object")
	}

	defaults := migrationSchemaDefaults()
	if centralEnabledInRaw(current) {
		defaults["updates"].(map[string]any)["enabled"] = true
	}
	added := make([]string, 0, 16)
	mergeMissing(current, defaults, "", &added)
	if len(added) == 0 {
		return MigrationResult{Changed: false}, nil
	}
	sort.Strings(added)

	rendered, err := json.MarshalIndent(current, "", "  ")
	if err != nil {
		return MigrationResult{}, fmt.Errorf("encode migrated configuration: %w", err)
	}
	rendered = append(rendered, '\n')

	stat, err := os.Stat(path)
	if err != nil {
		return MigrationResult{}, fmt.Errorf("stat configuration: %w", err)
	}
	mode := stat.Mode().Perm()
	if mode == 0 {
		mode = 0640
	}

	dir := filepath.Dir(path)
	tmp, err := os.CreateTemp(dir, ".vm-doc-agent-config-*.tmp")
	if err != nil {
		return MigrationResult{}, fmt.Errorf("create temporary configuration: %w", err)
	}
	tmpPath := tmp.Name()
	cleanup := func() { _ = os.Remove(tmpPath) }
	defer cleanup()

	if err := tmp.Chmod(mode); err != nil {
		_ = tmp.Close()
		return MigrationResult{}, fmt.Errorf("chmod temporary configuration: %w", err)
	}
	if _, err := tmp.Write(rendered); err != nil {
		_ = tmp.Close()
		return MigrationResult{}, fmt.Errorf("write temporary configuration: %w", err)
	}
	if err := tmp.Sync(); err != nil {
		_ = tmp.Close()
		return MigrationResult{}, fmt.Errorf("sync temporary configuration: %w", err)
	}
	if err := tmp.Close(); err != nil {
		return MigrationResult{}, fmt.Errorf("close temporary configuration: %w", err)
	}

	// Validate the exact bytes that are about to become active.
	if _, err := Load(tmpPath); err != nil {
		return MigrationResult{}, fmt.Errorf("validate migrated configuration: %w", err)
	}

	// Portable replacement: keep the old file next to the target until the
	// candidate is in place. This also works on platforms where Rename cannot
	// replace an existing file directly.
	oldPath := path + ".migrate-old"
	_ = os.Remove(oldPath)
	if err := os.Rename(path, oldPath); err != nil {
		return MigrationResult{}, fmt.Errorf("stage existing configuration: %w", err)
	}
	if err := os.Rename(tmpPath, path); err != nil {
		_ = os.Rename(oldPath, path)
		return MigrationResult{}, fmt.Errorf("activate migrated configuration: %w", err)
	}
	if err := os.Remove(oldPath); err != nil && !os.IsNotExist(err) {
		// The new config is already active and valid. Do not fail the migration
		// merely because cleanup of the temporary old copy was not possible.
	}

	return MigrationResult{Changed: true, AddedPaths: added}, nil
}

func mergeMissing(dst, src map[string]any, prefix string, added *[]string) {
	for key, srcValue := range src {
		path := key
		if prefix != "" {
			path = prefix + "." + key
		}
		dstValue, exists := dst[key]
		if !exists {
			dst[key] = deepCopyJSONValue(srcValue)
			*added = append(*added, path)
			continue
		}
		srcMap, srcOK := srcValue.(map[string]any)
		dstMap, dstOK := dstValue.(map[string]any)
		if srcOK && dstOK {
			mergeMissing(dstMap, srcMap, path, added)
		}
	}
}

func centralEnabledInRaw(current map[string]any) bool {
	central, ok := current["central"].(map[string]any)
	if !ok {
		return false
	}
	enabled, _ := central["enabled"].(bool)
	return enabled
}

func deepCopyJSONValue(v any) any {
	switch x := v.(type) {
	case map[string]any:
		out := make(map[string]any, len(x))
		for k, value := range x {
			out[k] = deepCopyJSONValue(value)
		}
		return out
	case []any:
		out := make([]any, len(x))
		for i := range x {
			out[i] = deepCopyJSONValue(x[i])
		}
		return out
	default:
		return x
	}
}

// migrationSchemaDefaults is the canonical on-disk schema skeleton. Values are
// safe runtime defaults. Existing values always win during migration.
func migrationSchemaDefaults() map[string]any {
	return map[string]any{
		"listen":              "0.0.0.0:9078",
		"output_file":         "/var/lib/vm-doc-agent/inventory.json",
		"state_dir":           "/var/lib/vm-doc-agent",
		"refresh_interval":    "24h",
		"auth_token_file":     "/etc/vm-doc-agent/token",
		"collector_timeout":   "20s",
		"output_test_timeout": "12s",
		"collectors": map[string]any{
			"system": true, "storage": true, "network": true, "proxy": true,
			"services": true, "listening_ports": true, "firewall": true,
			"accounts": true, "sssd": true, "integrations": true,
			"policies": true, "cron": true, "ntp": true, "docker": true, "databases": true, "web": true,
		},
		"limits": map[string]any{
			"max_partitions": 1000, "max_routes": 5000, "max_services": 5000,
			"max_ports": 5000, "max_firewall_rules": 10000, "max_firewall_zones": 1000,
			"max_accounts": 10000, "max_cron_entries": 5000, "max_cron_scripts": 5000,
			"max_policy_files": 10000, "max_inventory_bytes": 20971520,
			"max_docker_containers": 2000, "max_docker_images": 5000,
			"max_docker_networks": 1000, "max_docker_volumes": 2000,
			"max_database_instances": 500, "max_database_catalogs": 2000,
			"max_web_servers": 100, "max_web_sites": 5000,
		},
		"policy_paths": []any{},
		"central": map[string]any{
			"enabled":                 false,
			"url":                     "",
			"registration_token_file": "/etc/vm-doc-agent/central-registration-token",
			"heartbeat_interval":      "5m",
			"retry_interval":          "1m",
			"request_timeout":         "60s",
			"advertise_url":           "",
			"exclude_advertise_ips":   []any{},
			"ca_file":                 "",
			"tls_server_name":         "",
			"insecure_skip_verify":    false,
			"allow_http":              false,
		},
		"updates": map[string]any{
			"enabled":            false,
			"channel":            "stable",
			"check_interval":     "6h",
			"auto_install":       true,
			"endpoint":           "/api/v1/agent-updates/latest",
			"download_dir":       "",
			"health_timeout":     "45s",
			"max_download_bytes": 67108864,
		},
	}
}
