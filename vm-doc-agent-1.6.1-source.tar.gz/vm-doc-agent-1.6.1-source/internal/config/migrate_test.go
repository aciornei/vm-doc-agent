package config

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

func TestMigrateFileAddsDockerWithoutOverwritingExistingValues(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	old := `{
  "listen": "0.0.0.0:9078",
  "refresh_interval": "12h",
  "collectors": {
    "system": true,
    "ntp": false
  },
  "limits": {
    "max_partitions": 123
  },
  "central": {
    "enabled": true,
    "url": "http://10.20.30.40:9080",
    "allow_http": true
  },
  "updates": {
    "enabled": true,
    "channel": "testing",
    "auto_install": false
  }
}`
	if err := os.WriteFile(path, []byte(old), 0640); err != nil {
		t.Fatal(err)
	}

	result, err := MigrateFile(path)
	if err != nil {
		t.Fatalf("MigrateFile: %v", err)
	}
	if !result.Changed {
		t.Fatal("expected migration to change config")
	}
	wantAdded := map[string]bool{
		"collectors.docker":             true,
		"limits.max_docker_containers":  true,
		"limits.max_docker_images":      true,
		"limits.max_docker_networks":    true,
		"limits.max_docker_volumes":     true,
		"collectors.databases":          true,
		"limits.max_database_instances": true,
		"limits.max_database_catalogs":  true,
		"collectors.web":                true,
		"limits.max_web_servers":        true,
		"limits.max_web_sites":          true,
	}
	for _, p := range result.AddedPaths {
		delete(wantAdded, p)
	}
	if len(wantAdded) != 0 {
		t.Fatalf("missing expected added paths: %#v; got %#v", wantAdded, result.AddedPaths)
	}

	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var got map[string]any
	if err := json.Unmarshal(raw, &got); err != nil {
		t.Fatal(err)
	}
	if got["refresh_interval"] != "12h" {
		t.Fatalf("refresh_interval overwritten: %#v", got["refresh_interval"])
	}
	collectors := got["collectors"].(map[string]any)
	if collectors["ntp"] != false || collectors["docker"] != true || collectors["databases"] != true || collectors["web"] != true {
		t.Fatalf("collector values not preserved/added: %#v", collectors)
	}
	limits := got["limits"].(map[string]any)
	if limits["max_partitions"] != float64(123) || limits["max_docker_containers"] != float64(2000) || limits["max_database_instances"] != float64(500) || limits["max_database_catalogs"] != float64(2000) || limits["max_web_servers"] != float64(100) || limits["max_web_sites"] != float64(5000) {
		t.Fatalf("limits not preserved/added: %#v", limits)
	}
	central := got["central"].(map[string]any)
	if central["url"] != "http://10.20.30.40:9080" || central["enabled"] != true || central["allow_http"] != true {
		t.Fatalf("central settings overwritten: %#v", central)
	}
	updates := got["updates"].(map[string]any)
	if updates["channel"] != "testing" || updates["auto_install"] != false {
		t.Fatalf("update settings overwritten: %#v", updates)
	}

	if _, err := Load(path); err != nil {
		t.Fatalf("migrated config should load: %v", err)
	}
}

func TestMigrateFileIsIdempotent(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	data, err := json.MarshalIndent(migrationSchemaDefaults(), "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	data = append(data, '\n')
	if err := os.WriteFile(path, data, 0640); err != nil {
		t.Fatal(err)
	}
	before, _ := os.ReadFile(path)
	result, err := MigrateFile(path)
	if err != nil {
		t.Fatalf("MigrateFile: %v", err)
	}
	if result.Changed || len(result.AddedPaths) != 0 {
		t.Fatalf("expected no change, got %#v", result)
	}
	after, _ := os.ReadFile(path)
	if !reflect.DeepEqual(before, after) {
		t.Fatal("idempotent migration rewrote file")
	}
}

func TestMigrateFileInvalidConfigIsUntouched(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.json")
	original := []byte(`{"listen":"0.0.0.0:9078","unknown_future_typo":true}`)
	if err := os.WriteFile(path, original, 0640); err != nil {
		t.Fatal(err)
	}
	if _, err := MigrateFile(path); err == nil {
		t.Fatal("expected migration error")
	}
	after, _ := os.ReadFile(path)
	if !reflect.DeepEqual(original, after) {
		t.Fatal("invalid config was modified")
	}
}
