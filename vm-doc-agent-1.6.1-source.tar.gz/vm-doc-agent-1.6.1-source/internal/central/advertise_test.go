package central

import (
	"testing"

	"vm-doc-agent/internal/model"
)

func TestDefaultRouteSourceIPWinsAndVIPCanBeExcluded(t *testing.T) {
	inventory := model.Inventory{Network: model.NetworkInfo{
		Routes:          []model.RouteInfo{{Family: "ipv4", Default: true, Interface: "eth0", Source: "172.20.1.31"}},
		DefaultGateways: []model.GatewayInfo{{Family: "ipv4", Interface: "eth0", Address: "172.20.1.1"}},
		Interfaces:      []model.NetworkInterface{{Name: "eth0", Addresses: []model.IPAddress{{Address: "172.20.1.20", Family: "ipv4"}, {Address: "172.20.1.31", Family: "ipv4"}}}},
	}}
	excluded := newAdvertiseExclusions([]string{"172.20.1.20"})
	if got := defaultRouteSourceIP(inventory, excluded); got != "172.20.1.31" {
		t.Fatalf("got %q", got)
	}
	if got := primaryInventoryIPWithExclusions(inventory, excluded); got != "172.20.1.31" {
		t.Fatalf("fallback got %q", got)
	}
}

func TestAdvertiseExclusionsSupportCIDR(t *testing.T) {
	excluded := newAdvertiseExclusions([]string{"10.0.0.0/8", "172.20.1.20"})
	if !excluded("10.2.3.4") || !excluded("172.20.1.20") || excluded("172.20.1.31") {
		t.Fatal("unexpected exclusion matching")
	}
}
