package model

// WebInfo contains secret-safe metadata for host-level web servers and the
// virtual sites/frontends they expose. Raw configuration text, credentials,
// private keys and header values are never included in the inventory.
type WebInfo struct {
	Servers []WebServer `json:"servers"`
	Sites   []WebSite   `json:"sites"`
}

type WebServer struct {
	Engine           string   `json:"engine"`
	Product          string   `json:"product"`
	Installed        bool     `json:"installed"`
	Version          string   `json:"version,omitempty"`
	Executable       string   `json:"executable,omitempty"`
	ServiceName      string   `json:"service_name,omitempty"`
	Status           string   `json:"status,omitempty"`
	ConfigFiles      []string `json:"config_files,omitempty"`
	DetectionSources []string `json:"detection_sources,omitempty"`
}

type WebBinding struct {
	Address  string `json:"address,omitempty"`
	Port     uint16 `json:"port,omitempty"`
	Protocol string `json:"protocol,omitempty"`
	TLS      bool   `json:"tls"`
	Wildcard bool   `json:"wildcard,omitempty"`
}

type WebSite struct {
	Engine           string       `json:"engine"`
	Product          string       `json:"product"`
	SiteType         string       `json:"site_type"` // virtual_host | server | frontend | listen
	Name             string       `json:"name"`
	ServerNames      []string     `json:"server_names,omitempty"`
	Bindings         []WebBinding `json:"bindings,omitempty"`
	DocumentRoot     string       `json:"document_root,omitempty"`
	ProxyTargets     []string     `json:"proxy_targets,omitempty"`
	Backends         []string     `json:"backends,omitempty"`
	Mode             string       `json:"mode,omitempty"`
	ConfigFile       string       `json:"config_file,omitempty"`
	Enabled          bool         `json:"enabled"`
	Default          bool         `json:"default,omitempty"`
	DetectionSources []string     `json:"detection_sources,omitempty"`
}
