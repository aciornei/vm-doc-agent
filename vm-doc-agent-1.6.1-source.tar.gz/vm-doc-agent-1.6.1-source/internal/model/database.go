package model

// DatabaseInfo is a secret-safe inventory of database engines and instances
// detected on the VM. It contains runtime/topology metadata and, when local
// passwordless discovery is possible, logical database names. It never stores
// passwords, connection strings, query text, table data, or arbitrary process
// environment values.
type DatabaseInfo struct {
	Engines   []DatabaseEngine   `json:"engines"`
	Instances []DatabaseInstance `json:"instances"`
}

type DatabaseEngine struct {
	Engine     string   `json:"engine"`
	Product    string   `json:"product"`
	Installed  bool     `json:"installed"`
	Executable string   `json:"executable,omitempty"`
	Version    string   `json:"version,omitempty"`
	Sources    []string `json:"sources,omitempty"`
}

type DatabaseEndpoint struct {
	Protocol string `json:"protocol,omitempty"`
	Address  string `json:"address,omitempty"`
	Port     uint16 `json:"port,omitempty"`
	Wildcard bool   `json:"wildcard,omitempty"`
}

type DatabaseCatalog struct {
	Name   string `json:"name"`
	Kind   string `json:"kind,omitempty"`
	System bool   `json:"system"`
}

type DatabaseInstance struct {
	Engine                 string             `json:"engine"`
	Product                string             `json:"product"`
	InstanceName           string             `json:"instance_name,omitempty"`
	Version                string             `json:"version,omitempty"`
	Edition                string             `json:"edition,omitempty"`
	Status                 string             `json:"status,omitempty"`
	ServiceName            string             `json:"service_name,omitempty"`
	PID                    int                `json:"pid,omitempty"`
	Executable             string             `json:"executable,omitempty"`
	DataDir                string             `json:"data_dir,omitempty"`
	ConfigFiles            []string           `json:"config_files,omitempty"`
	Endpoints              []DatabaseEndpoint `json:"endpoints,omitempty"`
	SocketPaths            []string           `json:"socket_paths,omitempty"`
	Catalogs               []DatabaseCatalog  `json:"catalogs,omitempty"`
	CatalogDiscoveryStatus string             `json:"catalog_discovery_status,omitempty"`
	DetectionSources       []string           `json:"detection_sources,omitempty"`
}
