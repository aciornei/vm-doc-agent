package model

import "time"

// DockerInfo is a structured, secret-safe inventory of a Docker Engine running
// on the VM. It intentionally contains topology and runtime metadata, not
// container logs, secret values or environment-variable values.
type DockerInfo struct {
	Installed       bool                   `json:"installed"`
	Available       bool                   `json:"available"`
	Executable      string                 `json:"executable,omitempty"`
	ServiceState    string                 `json:"service_state,omitempty"`
	Version         string                 `json:"version,omitempty"`
	APIVersion      string                 `json:"api_version,omitempty"`
	OS              string                 `json:"os,omitempty"`
	Architecture    string                 `json:"architecture,omitempty"`
	StorageDriver   string                 `json:"storage_driver,omitempty"`
	LoggingDriver   string                 `json:"logging_driver,omitempty"`
	CgroupDriver    string                 `json:"cgroup_driver,omitempty"`
	CgroupVersion   string                 `json:"cgroup_version,omitempty"`
	DockerRootDir   string                 `json:"docker_root_dir,omitempty"`
	Containers      []DockerContainer      `json:"containers,omitempty"`
	Images          []DockerImage          `json:"images,omitempty"`
	Networks        []DockerNetwork        `json:"networks,omitempty"`
	Volumes         []DockerVolume         `json:"volumes,omitempty"`
	ComposeProjects []DockerComposeProject `json:"compose_projects,omitempty"`
}

type DockerContainer struct {
	ID                       string                   `json:"id"`
	Name                     string                   `json:"name"`
	Image                    string                   `json:"image,omitempty"`
	ImageID                  string                   `json:"image_id,omitempty"`
	State                    string                   `json:"state,omitempty"`
	Status                   string                   `json:"status,omitempty"`
	Health                   string                   `json:"health,omitempty"`
	CreatedAt                *time.Time               `json:"created_at,omitempty"`
	StartedAt                *time.Time               `json:"started_at,omitempty"`
	FinishedAt               *time.Time               `json:"finished_at,omitempty"`
	RestartPolicy            string                   `json:"restart_policy,omitempty"`
	RestartMaximumRetryCount int                      `json:"restart_maximum_retry_count,omitempty"`
	Privileged               bool                     `json:"privileged"`
	ReadonlyRootFS           bool                     `json:"readonly_rootfs"`
	NetworkMode              string                   `json:"network_mode,omitempty"`
	User                     string                   `json:"user,omitempty"`
	WorkingDir               string                   `json:"working_dir,omitempty"`
	MemoryLimitBytes         int64                    `json:"memory_limit_bytes,omitempty"`
	NanoCPUs                 int64                    `json:"nano_cpus,omitempty"`
	CPUQuota                 int64                    `json:"cpu_quota,omitempty"`
	CPUPeriod                int64                    `json:"cpu_period,omitempty"`
	PidsLimit                int64                    `json:"pids_limit,omitempty"`
	DockerSocketMounted      bool                     `json:"docker_socket_mounted"`
	CapAdd                   []string                 `json:"cap_add,omitempty"`
	SecurityOpt              []string                 `json:"security_opt,omitempty"`
	EnvironmentKeys          []string                 `json:"environment_keys,omitempty"`
	Labels                   map[string]string        `json:"labels,omitempty"`
	ComposeProject           string                   `json:"compose_project,omitempty"`
	ComposeService           string                   `json:"compose_service,omitempty"`
	ComposeWorkingDir        string                   `json:"compose_working_dir,omitempty"`
	ComposeConfigFiles       []string                 `json:"compose_config_files,omitempty"`
	Ports                    []DockerPort             `json:"ports,omitempty"`
	Mounts                   []DockerMount            `json:"mounts,omitempty"`
	Networks                 []DockerContainerNetwork `json:"networks,omitempty"`
}

type DockerPort struct {
	ContainerPort int    `json:"container_port"`
	Protocol      string `json:"protocol"`
	HostIP        string `json:"host_ip,omitempty"`
	HostPort      int    `json:"host_port,omitempty"`
}

type DockerMount struct {
	Type        string `json:"type,omitempty"`
	Name        string `json:"name,omitempty"`
	Source      string `json:"source,omitempty"`
	Destination string `json:"destination"`
	ReadOnly    bool   `json:"read_only"`
}

type DockerContainerNetwork struct {
	Name       string `json:"name"`
	NetworkID  string `json:"network_id,omitempty"`
	IPAddress  string `json:"ip_address,omitempty"`
	Gateway    string `json:"gateway,omitempty"`
	MacAddress string `json:"mac_address,omitempty"`
}

type DockerImage struct {
	ID           string     `json:"id"`
	RepoTags     []string   `json:"repo_tags,omitempty"`
	RepoDigests  []string   `json:"repo_digests,omitempty"`
	CreatedAt    *time.Time `json:"created_at,omitempty"`
	SizeBytes    int64      `json:"size_bytes,omitempty"`
	Architecture string     `json:"architecture,omitempty"`
	OS           string     `json:"os,omitempty"`
}

type DockerNetwork struct {
	ID         string             `json:"id"`
	Name       string             `json:"name"`
	Driver     string             `json:"driver,omitempty"`
	Scope      string             `json:"scope,omitempty"`
	Internal   bool               `json:"internal"`
	Attachable bool               `json:"attachable"`
	Ingress    bool               `json:"ingress"`
	IPAM       []DockerIPAMConfig `json:"ipam,omitempty"`
	Labels     map[string]string  `json:"labels,omitempty"`
}

type DockerIPAMConfig struct {
	Subnet  string `json:"subnet,omitempty"`
	Gateway string `json:"gateway,omitempty"`
}

type DockerVolume struct {
	Name       string            `json:"name"`
	Driver     string            `json:"driver,omitempty"`
	Mountpoint string            `json:"mountpoint,omitempty"`
	Scope      string            `json:"scope,omitempty"`
	Labels     map[string]string `json:"labels,omitempty"`
}

type DockerComposeProject struct {
	Name           string   `json:"name"`
	WorkingDir     string   `json:"working_dir,omitempty"`
	ConfigFiles    []string `json:"config_files,omitempty"`
	Services       []string `json:"services,omitempty"`
	ContainerCount int      `json:"container_count"`
}
