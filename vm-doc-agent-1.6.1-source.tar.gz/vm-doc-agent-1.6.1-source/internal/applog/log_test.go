package applog

import (
	"log"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSetupWritesLogFile(t *testing.T) {
	oldWriter := log.Writer()
	oldFlags := log.Flags()
	defer func() {
		log.SetOutput(oldWriter)
		log.SetFlags(oldFlags)
	}()

	path := filepath.Join(t.TempDir(), "logs", "agent.log")
	f, err := Setup(path)
	if err != nil {
		t.Fatalf("Setup() error = %v", err)
	}
	log.Printf("level=info event=test_file_logging")
	if err := f.Close(); err != nil {
		t.Fatalf("close log file: %v", err)
	}

	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("ReadFile() error = %v", err)
	}
	if !strings.Contains(string(data), "event=test_file_logging") {
		t.Fatalf("log file does not contain test event: %q", string(data))
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatalf("Stat() error = %v", err)
	}
	if got := info.Mode().Perm(); got != 0640 {
		t.Fatalf("mode = %o, want 640", got)
	}
}
