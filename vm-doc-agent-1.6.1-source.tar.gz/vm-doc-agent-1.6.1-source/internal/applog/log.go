package applog

import (
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
)

const DefaultPath = "/var/log/vm-doc-agent.log"

// Setup configures the process-wide standard logger to always append to path.
// When stderr is not already redirected to the same file, logs are mirrored to
// stderr as well so systemd/journald and interactive execution keep working.
// The returned file must be closed by the caller when the process exits.
func Setup(path string) (*os.File, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		path = DefaultPath
	}
	if err := os.MkdirAll(filepath.Dir(path), 0750); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0640)
	if err != nil {
		return nil, err
	}
	if err := os.Chmod(path, 0640); err != nil {
		_ = f.Close()
		return nil, err
	}

	var output io.Writer = f
	if !sameFile(os.Stderr, f) {
		output = io.MultiWriter(os.Stderr, f)
	}
	log.SetOutput(output)
	log.SetFlags(log.LstdFlags | log.LUTC)
	return f, nil
}

func sameFile(a, b *os.File) bool {
	if a == nil || b == nil {
		return false
	}
	aInfo, aErr := a.Stat()
	bInfo, bErr := b.Stat()
	if aErr != nil || bErr != nil {
		return false
	}
	return os.SameFile(aInfo, bInfo)
}
