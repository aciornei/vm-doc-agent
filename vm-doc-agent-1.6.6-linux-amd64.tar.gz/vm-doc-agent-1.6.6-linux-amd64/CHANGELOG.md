# Changelog

## 1.6.6

- pentru MySQL/MariaDB preferă clientul `mysql`, cu fallback la `mariadb`, pentru compatibilitate cu instalările MariaDB 10 mai vechi;
- dacă există userul Linux `vm-doc-inventory`, enumerarea bazelor rulează prin `runuser -u vm-doc-inventory` și autentificare locală prin socket, fără parolă stocată;
- trimite explicit userul DB `vm-doc-inventory` și, când este detectată, calea reală a socket-ului instanței;
- dacă userul dedicat există dar autentificarea eșuează, nu reîncearcă drept root; dacă userul nu există, păstrează fallback-ul legacy pentru compatibilitate.

## 1.6.5

- adaugă `catalog_discovery_reason` pentru instanțele DB atunci când catalogul nu poate fi enumerat fără credențiale;
- clasifică motivele în coduri secret-safe: autentificare, permisiuni, socket/server indisponibil, client lipsă, timeout, utilizator OS lipsă sau query eșuat;
- nu trimite stderr brut și continuă să nu citească/stocheze parole sau connection strings.

## 1.6.4

- extinde collectorul Web pentru Apache HTTP Server astfel încât să pornească din configurația principală și să urmărească recursiv directivele `Include` și `IncludeOptional`;
- detectează configurația Apache și din argumentele procesului `-d` / `-f`, respectiv din `httpd/apache2 -V` (`HTTPD_ROOT` și `SERVER_CONFIG_FILE`);
- rezolvă include-urile relative față de `ServerRoot`, inclusiv glob-uri și directoare, cu deduplicare și protecție la bucle;
- inventariază astfel automat VirtualHost-uri din layout-uri precum `/etc/httpd/vhosts.d`, dar și din directoare custom definite de configurația Apache;
- nu modifică schema inventarului și nu necesită upgrade de server peste vm-doc-server 0.19.6.

## 1.6.3

- adaugă colectorul `hosts` pentru `/etc/hosts`;
- raportează structurat `hosts.entries[].ip` și `hosts.entries[].names`;
- ignoră loopback, comentarii, linii invalide și duplicate;
- schema inventarului devine `2.5`;
- colectorul este activ implicit și este adăugat automat în config la upgrade.


## 1.6.2

- corectează identitatea FQDN a VM-ului atunci când `hostname -f` urmărește un CNAME de serviciu și întoarce alt nume canonic decât hostname-ul mașinii;
- construiește FQDN-ul VM din hostname-ul local și domeniul de căutare DNS care rezolvă numele, păstrând ordinea configurată în resolver;
- păstrează separat rezultatul canonic DNS în `host.canonical_dns_name`, iar `host.fqdn_source` indică metoda folosită;
- exemplu: `hostname=kestra`, `kestra.xxx.ro CNAME nginx.xxx.ro` devine `fqdn=kestra.xxx.ro`, `canonical_dns_name=nginx.xxx.ro`;
- schema inventarului devine `2.4`; nu sunt necesare chei noi în `config.json`.

## 1.6.1

- extinde detecția Nginx pentru instalări custom, inclusiv sub `/opt`, folosind executabilul procesului, opțiunile `-p` / `-c` și căile compilate raportate de `nginx -V`;
- urmărește recursiv directivele `include` din configurația Nginx, inclusiv glob-uri relative la prefix, astfel încât virtual host-urile din layout-uri non-standard să fie inventariate;
- păstrează fixul PostgreSQL din 1.6.0: un proces `postgres` activ nu este degradat la `inactive` de unitatea generică `postgresql.service`.

## 1.6.0

- adaugă collectorul `web` pentru Nginx, Apache HTTP Server și HAProxy;
- colectează metadate despre site-uri, virtual hosts și frontends: nume publice, bind-uri, porturi, TLS, document root, backend-uri și ținte proxy;
- nu colectează conținut brut de configurație, parole, chei private, valori de headere sau alte secrete;
- adaugă limitele `max_web_servers` și `max_web_sites`, completate automat în `config.json` prin migrarea aditivă;
- corectează detecția stării PostgreSQL: un proces activ rămâne `running`, iar unitățile active de cluster sunt preferate în fața unității generice `postgresql.service` inactive.

## 1.5.0

- adaugă collectorul `databases` pentru PostgreSQL, MySQL, MariaDB, MongoDB, Oracle, Microsoft SQL Server, IBM Db2, Redis, Firebird și CockroachDB;
- colectează engine, versiune, instanțe, procese, servicii, directoare/config cunoscute și endpoint-uri fără parole sau connection strings;
- pentru PostgreSQL/MySQL/MariaDB/MongoDB încearcă best-effort enumerarea numelor bazelor doar prin acces local fără credențiale; dacă autentificarea nu permite, păstrează metadata instanței;
- `config.json` primește automat `collectors.databases` și limitele noi prin migrarea aditivă introdusă în 1.4.1.

## 1.4.1

- adaugă migrare aditivă a `config.json`: cheile noi sunt completate automat, fără suprascrierea valorilor existente;
- auto-updaterul rulează migrarea cu binarul nou înainte de pornirea serviciului;
- păstrează `/etc/vm-doc-agent/config.json.previous` înainte de update;
- rollback-ul de update restaurează acum atât binarul anterior, cât și configurația anterioară;
- `install.sh` și `update.sh` folosesc aceeași migrare de configurație;
- noua comandă `-migrate-config` poate fi folosită și manual pentru verificare/remediere;
- rezolvă cazul 1.3.x → 1.4.x în care `docker` și noile limite Docker nu apăreau fizic în fișierul existent.

## 1.4.0

- colector Docker nou pentru engine, containere, Compose projects, images, networks și volumes;
- colectează indicatori utili de securitate fără a prelua secrete: privileged, read-only rootfs, network mode, docker.sock mount, capabilities și resource limits;
- variabilele de mediu sunt inventariate numai prin nume, fără valori; valorile label-urilor sensibile sunt mascate;
- limite separate pentru obiectele Docker în inventar;
- păstrează selecția de IP de management introdusă în 1.3.7 și suportă `central.exclude_advertise_ips` cu IP-uri sau CIDR-uri.


## 1.3.6

- Adaugă log persistent propriu în `/var/log/vm-doc-agent.log` pentru procesul agentului.
- Păstrează în paralel logarea către stderr, deci pe systemd mesajele rămân disponibile și prin `journalctl`.
- Evită dublarea mesajelor pe SysV atunci când stderr este deja redirecționat către același fișier.
- Updaterul scrie în același log evenimentele `update_started`, `update_completed` și `update_failed`, util pentru depanarea auto-update-ului pe sisteme vechi.
- Păstrează compatibilitatea cu configurația logrotate existentă pentru `/var/log/vm-doc-agent.log`.

## 1.3.5

- Release de test pentru validarea auto-update-ului prin vm-doc-server.
- Fără modificări funcționale față de 1.3.4; doar incrementarea versiunii de build/release.

## 1.3.4

- repară auto-update-ul pe CentOS 7 / systemd 219 și alte versiuni systemd vechi;
- `systemd-run` folosește acum detectarea capabilităților din `--help`, fără a presupune că `--no-block` sau `--collect` există;
- elimină `Type=exec` din unitatea tranzitorie de update pentru compatibilitate cu systemd vechi;
- păstrează izolarea helperului de update într-o unitate systemd separată, astfel încât acesta să supraviețuiască opririi agentului;
- corectează versiunea implicită din `scripts/package-source.sh`.

## 1.3.3

- repară popularea versiunilor în `services[]`;
- adaugă detecție explicită pentru `vm-doc-agent.service`;
- adaugă fallback generic la pachetul care deține unitatea systemd / scriptul SysV;
- completează `package_name`, `package_version`, `version` și `version_source=package` pentru serviciile unde versiunea produsului nu poate fi detectată direct;
- interogările Debian sunt făcute în batch pentru a menține colectarea rapidă;
- mecanismul de auto-update 1.3.x rămâne neschimbat.

## 1.3.2

- detecție mai robustă a versiunilor pentru serviciile software principale;
- rezolvare explicită a executabilelor și din directoarele sbin;
- detecția versiunilor rulează concurent pentru a evita timeout-ul colectorului de servicii;
- păstrează integral mecanismul de auto-update din 1.3.0+.

## 1.3.1

- metadate software/version pentru serviciile colectate;
- detecție Postfix/Dovecot și alte produse uzuale pe Linux;
- ProductVersion/FileVersion pentru servicii active pe Windows;
- compatibilitate păstrată cu schema de inventar existentă.


## 1.3.0

### Adăugat

- auto-update centralizat prin `vm-doc-server`;
- canale `stable` / `testing`;
- verificare periodică implicită la `6h`;
- validare SHA-256, dimensiune și versiune pentru executabilele descărcate;
- helper separat `vm-doc-updater`;
- backup al binarului anterior și rollback automat dacă noua versiune nu trece health check-ul;
- endpoint-uri locale `GET /v1/update` și `POST /v1/update/check`;
- protecție same-origin pentru download-urile de update.

### Păstrat

- `refresh_interval=24h`;
- heartbeat central `5m`;
- schema inventarului `2.0`;
- central implicit `http://172.20.1.20:9080`, cu `allow_http=true`.

## 1.1.2

### Modificat

- `refresh_interval` implicit pentru instalările noi este `24h` în loc de `15m`;
- heartbeat-ul central rămâne la `5m`;
- refresh-ul manual continuă să declanșeze imediat colectarea și push-ul inventarului;
- configurația centrală implicită rămâne activă către `http://172.20.1.20:9080`, cu `allow_http=true`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- `update.sh` păstrează configurația existentă, deci un agent deja instalat cu `15m` nu este schimbat automat la `24h`.

## 1.1.1

### Modificat

- autoînregistrarea este activată implicit pentru instalările noi;
- endpoint central implicit: `http://172.20.1.20:9080`;
- `central.allow_http=true` pentru profilul intern curent;
- installerul acceptă un token comun inclus în pachet sau furnizat prin `VM_DOC_CENTRAL_REGISTRATION_TOKEN`;
- pachetul intern poate instala automat `/etc/vm-doc-agent/central-registration-token` cu permisiuni `0600`.

### Compatibilitate

- schema inventarului rămâne `2.0`;
- protocolul central rămâne versiunea `1`;
- configurațiile existente sunt păstrate la update.

## 1.1.0

### Adăugat

- autoînregistrare la `vm-doc-server 0.2.2`;
- heartbeat periodic;
- push automat al inventarului după colectare;
- retry automat la indisponibilitatea serverului central;
- configurare TLS/CA și `advertise_url`;
- token de înregistrare separat de tokenul API local.

### Compatibilitate

- configurațiile 1.0.0 fără secțiunea `central` rămân valide;
- API-ul local și schema inventarului `2.0` nu se schimbă.


## 1.0.0

Prima versiune stabilă a agentului.

### Adăugat

- status individual pentru fiecare colector: `success`, `partial`, `timeout`, `error`, `disabled`;
- endpoint `GET /v1/status`;
- comenzi `-check-config`, `-collect-once`, `-print-inventory`, `-diagnostics`;
- activare/dezactivare individuală a colectoarelor;
- timeout global pentru colectoare și timeout separat pentru testarea output-urilor Beats;
- DNS, rute, gateway-uri, proxy, timezone, boot time și uptime;
- păstrarea atomică a `inventory.json.previous`;
- limite configurabile și metadata de truncare;
- loguri structurate și logrotate pentru SysV;
- documentație completă în `docs/`.

### Modificat

- schema JSON a trecut la `2.0`;
- installerul și updaterul validează configurația înainte de pornire;
- updaterul actualizează și fișierele de serviciu/logrotate;
- API-ul adaugă `Cache-Control: no-store` și jurnalizare cu status HTTP.

### Compatibilitate

Configurațiile 0.5.x fără câmpurile noi sunt acceptate și primesc valorile implicite din 1.0.0.
