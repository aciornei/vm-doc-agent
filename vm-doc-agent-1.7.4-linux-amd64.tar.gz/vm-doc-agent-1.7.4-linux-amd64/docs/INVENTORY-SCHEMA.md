# Schema inventarului

Versiunea schemei din 1.0.0 este:

```json
"schema_version": "2.0"
```

Versiunea schemei este separată de versiunea agentului.

## Structură principală

```text
schema_version
agent
collected_at
collection
host
os
system
storage
network
proxy
services
listening_ports
firewall
accounts
sssd
integrations
policies
cron
ntp
truncations
collection_warnings
```

## Statusul colectoarelor

```json
{
  "collection": {
    "status": "partial",
    "collectors": {
      "network": {
        "status": "success",
        "duration_ms": 4
      },
      "integrations": {
        "status": "partial",
        "warning_count": 1,
        "warnings": ["filebeat: output validation failed"]
      }
    }
  }
}
```

Valori posibile:

- `success`;
- `partial`;
- `timeout`;
- `error`;
- `disabled`.

## Truncare

Dacă o limită este atinsă:

```json
{
  "truncations": {
    "firewall.rules": {
      "detected": 14832,
      "returned": 10000,
      "limit": 10000,
      "reason": "configured item limit"
    }
  }
}
```

## Corelare

Câmpurile principale pentru vCenter și GLPI sunt:

```text
host.correlation.dmi_product_uuid
host.correlation.smbios_legacy_byte_order
host.correlation.machine_id
host.correlation.agent_id
```


## Metadate de versiune pentru servicii (1.3.1+)

Elementele din `services` pot include opțional:

```json
{
  "name": "postfix.service",
  "software_name": "Postfix",
  "version": "3.8.6",
  "package_name": "postfix",
  "package_version": "3.8.6-1ubuntu0.3",
  "version_source": "postconf -h mail_version"
}
```

Câmpurile sunt opționale pentru compatibilitate cu agenții anteriori. `version` reprezintă versiunea produsului când poate fi determinată, iar `package_version` versiunea pachetului instalat.

## Web inventory · schema 2.3

Câmpul `web` conține `servers` și `sites`. `servers` descrie Nginx/Apache/HAProxy instalat sau activ, iar `sites` descrie virtual hosts, blocuri Nginx `server` și frontend/listen HAProxy. Sunt păstrate numai metadate secret-safe; configurația brută și secretele nu sunt incluse.


## Identitate host · schema 2.4

Câmpurile de identitate DNS sunt separate pentru a evita confundarea VM-ului cu ținta unui CNAME de serviciu:

```json
{
  "host": {
    "hostname": "kestra",
    "fqdn": "kestra.xxx.ro",
    "canonical_dns_name": "nginx.xxx.ro",
    "fqdn_source": "dns-search"
  }
}
```

`host.fqdn` reprezintă numele VM-ului construit din hostname și domeniul de căutare care rezolvă. `host.canonical_dns_name` păstrează separat numele canonic raportat de resolver/`hostname -f` atunci când este diferit. Valorile posibile uzuale pentru `fqdn_source` sunt `hostname`, `dns-search`, `dns-search-from-canonical`, `dns-search-single` și `hostname-f-fallback`.


## Hosts local (1.6.3)

Colectorul `hosts` citește `/etc/hosts` și publică mapări structurate `IP -> names`. Colectorul este activ implicit prin `collectors.hosts=true`. Adresele loopback și duplicatele nu sunt raportate.

### Apache Include/IncludeOptional (1.6.4+)

Collectorul Web urmărește recursiv configurația Apache pornind din fișierul principal și rezolvă `Include` / `IncludeOptional` față de `ServerRoot`. VirtualHost-urile pot fi păstrate în orice director referit de configurație; nu este necesară configurarea unei liste fixe de directoare în agent.


## Database catalog discovery · 1.6.5

`databases.instances[].catalog_discovery_reason` explică secret-safe de ce `catalog_discovery_status=metadata_only`. Valori cunoscute: `authentication_required`, `permission_denied`, `socket_unavailable`, `server_unavailable`, `client_not_found`, `timeout`, `os_user_unavailable`, `query_failed`, `unsupported_engine`, `maintenance_database_missing`, `user_switch_unavailable`. La `discovered`, câmpul este omis.
## Clasificarea serviciilor · schema 2.6

Elementele din `services` includ opțional:

```json
{
  "name": "tomcat.service",
  "classification": "application",
  "classification_reason": "known_application_service"
}
```

`classification` poate fi `system`, `application` sau `unknown`. Clasificarea este intenționat conservatoare: un serviciu incert rămâne `unknown` și nu este eliminat din inventar. `classification_reason` este un cod stabil precum `known_application_service`, `known_system_service`, `custom_systemd_unit`, `system_package` sau `unclassified`.



## PostgreSQL multi-instance și scheduled jobs · schema 2.7

Pentru fiecare element PostgreSQL din `databases.instances`, agentul păstrează identitatea instanței (executabil, data directory, endpoint/port și socket-uri) și poate adăuga:

```json
{
  "scheduled_jobs": [
    {
      "scheduler": "pgagent",
      "job_id": "12",
      "name": "maintenance",
      "enabled": true,
      "schedule": "nightly",
      "source_database": "postgres"
    }
  ],
  "scheduled_job_discovery_status": "discovered",
  "scheduled_job_discovery_reason": ""
}
```

Scheduler-ele cunoscute sunt `pgagent` și `pg_cron`. Se colectează numai identificatori/nume, programare, DB/user și starea/timpii disponibili. **Nu se colectează coloana `command`, pașii pgAgent, SQL-ul sau scripturile joburilor.** Statusul poate fi `discovered`, `not_detected`, `partial` sau `metadata_only`.

## Microsoft SQL Server pe Windows · schema 2.8 / agent 1.7.1

Pe Windows, o instanță SQL Server poate raporta versiunea, ediția și cataloagele vizibile prin autentificare Windows integrată. Nu sunt adăugate câmpuri noi față de schema 2.8; sunt populate câmpurile existente:

```json
{
  "engine": "mssql",
  "product": "Microsoft SQL Server",
  "instance_name": "MSSQLSERVER",
  "version": "16.0.1000.6",
  "edition": "Standard Edition (64-bit)",
  "catalog_discovery_status": "discovered",
  "catalogs": [
    {"name":"master","kind":"database","system":true},
    {"name":"appdb","kind":"database","system":false}
  ]
}
```

Instanța este detectată din Registry/Windows Services. Discovery-ul catalogului folosește ADO.NET cu `Integrated Security=SSPI` sub identitatea procesului agentului. În instalarea Windows standard aceasta este `NT AUTHORITY\\SYSTEM`. `master`, `model`, `msdb` și `tempdb` sunt marcate `system=true`. Dacă loginul Windows lipsește, motivul este `authentication_required`; dacă loginul se poate conecta dar nu are `VIEW ANY DATABASE`, statusul este `partial` și motivul `permission_denied`.


## Software instalat (schema 2.9+)

Pe Windows, `software.items[]` inventariază aplicațiile desktop din Registry x64/x86, aplicațiile per-user vizibile în hive-urile încărcate, AppX/MSIX și Windows Features/Roles. Câmpurile includ `name`, `version`, `publisher`, `architecture`, `scope`, `kind`, `source`, `install_date`, `install_location`, `state` și `system`. Agentul nu folosește `Win32_Product`.
