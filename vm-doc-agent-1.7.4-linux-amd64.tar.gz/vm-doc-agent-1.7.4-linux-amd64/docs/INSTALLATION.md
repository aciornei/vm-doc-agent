# Instalare și update

## Instalare nouă

```bash
# pachet universal pentru x86_64 și i386/i686
tar -xzf vm-doc-agent-1.6.11-linux-multiarch.tar.gz
cd vm-doc-agent-1.6.11-linux-multiarch
sudo ./install.sh
```

Installerul detectează automat arhitectura (`amd64` sau `386`) și systemd/SysV. Pachetele `linux-amd64` și `linux-386` pot fi folosite separat; dacă arhitectura pachetului nu corespunde hostului, instalarea se oprește înainte de a înlocui binarul existent.

Pachetul intern 1.3.0 poate include tokenul comun de autoînregistrare. `install.sh` îl instalează automat în `/etc/vm-doc-agent/central-registration-token` cu modul `0600`. Dacă tokenul nu este inclus în pachet, poate fi furnizat prin `VM_DOC_CENTRAL_REGISTRATION_TOKEN`.

## Verificare systemd

```bash
systemctl status vm-doc-agent
journalctl -u vm-doc-agent -f
```

## Verificare SysV

```bash
/etc/init.d/vm-doc-agent status
tail -f /var/log/vm-doc-agent.log
```

## Update

```bash
sudo ./update.sh
```

Updaterul:

1. validează configurația cu noul binar;
2. oprește serviciul;
3. salvează binarul anterior ca `vm-doc-agent.previous`;
4. actualizează binarul, serviciul și logrotate;
5. pornește serviciul;
6. revine la binarul anterior dacă pornirea eșuează.

## Dezinstalare

Păstrează configurația și datele:

```bash
sudo ./uninstall.sh
```

Șterge și configurația, tokenul, inventarul, logurile și identitatea agentului:

```bash
sudo ./uninstall.sh --purge
```


### Log propriu (1.3.6+)

Agentul și updaterul scriu direct în `/var/log/vm-doc-agent.log`. Pe systemd mesajele sunt păstrate și în journal. Pentru urmărire în timp real: `tail -f /var/log/vm-doc-agent.log`.

## Windows x64 · installer nativ 1.7.4+

Începând cu 1.7.4, instalarea Windows nu mai depinde de PowerShell și nu necesită modificarea `ExecutionPolicy`. Dintr-un terminal elevat se rulează direct:

```text
vm-doc-agent.exe install --central-url http://vm-doc-server:9080
```

Dacă tokenul de înregistrare nu există, installerul îl solicită interactiv fără echo. Pentru deployment neinteractiv este preferat un fișier protejat prin ACL:

```text
vm-doc-agent.exe install --central-url http://vm-doc-server:9080 --registration-token-file C:\Secure\vm-doc-registration-token.txt --firewall-remote 172.20.0.0/16 --quiet
```

Binarele sunt instalate în `C:\Program Files\VM-Doc\Agent`, iar configurația și starea rămân în `C:\ProgramData\VM-Doc\Agent`. O instalare 1.7.0-1.7.3 este migrată automat și păstrează `config.json` și `central-registration-token`.

Comenzi de administrare:

```text
vm-doc-agent.exe status
vm-doc-agent.exe repair
vm-doc-agent.exe uninstall
vm-doc-agent.exe uninstall --purge
```

Pachetul MSI x64 folosește același installer nativ și nu lansează PowerShell pe hostul țintă. La o instalare MSI nouă, `CENTRALURL` și fie `REGISTRATIONTOKEN`, fie `REGISTRATIONTOKENFILE` trebuie furnizate prin proprietăți MSI.
